// JNI glue between app.zetaphii.editor.NativeEngine (Kotlin) and native_engine.cpp.
// Bitmaps are locked with <android/bitmap.h>; only ARGB_8888 (RGBA_8888 byte order,
// premultiplied) non-hardware bitmaps are accepted.
#include <jni.h>
#include <android/bitmap.h>

#include <vector>

#include "native_engine.h"

namespace {

struct Locked {
  JNIEnv* env = nullptr;
  jobject bmp = nullptr;
  zeta::Surface s{nullptr, 0, 0, 0};
  bool ok = false;

  Locked() = default;
  Locked(JNIEnv* e, jobject b) { lock(e, b); }
  ~Locked() { unlock(); }
  Locked(const Locked&) = delete;
  Locked& operator=(const Locked&) = delete;

  bool lock(JNIEnv* e, jobject b) {
    env = e;
    bmp = b;
    ok = false;
    if (!b) return false;
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(e, b, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return false;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return false;
    void* p = nullptr;
    if (AndroidBitmap_lockPixels(e, b, &p) != ANDROID_BITMAP_RESULT_SUCCESS || !p) return false;
    s.px = static_cast<uint8_t*>(p);
    s.w = (int)info.width;
    s.h = (int)info.height;
    s.stride = (int)info.stride;
    ok = true;
    return true;
  }
  void unlock() {
    if (ok) {
      AndroidBitmap_unlockPixels(env, bmp);
      ok = false;
    }
  }
  zeta::ConstSurface cs() const { return zeta::ConstSurface{s.px, s.w, s.h, s.stride}; }
};

}  // namespace

#define JNI_FN(name) extern "C" JNIEXPORT jint JNICALL Java_app_zetaphii_editor_NativeEngine_##name

JNI_FN(nativeSelfTest)(JNIEnv*, jclass) { return zeta::selfTest(); }

JNI_FN(nativeComposite)(JNIEnv* env, jclass, jobjectArray layers, jfloatArray params, jint count, jobject out,
                        jfloat blurScale) {
  if (!layers || !params || count < 0) return zeta::kErrArgs;
  if (env->GetArrayLength(layers) < count) return zeta::kErrArgs;
  if (env->GetArrayLength(params) < count * zeta::kLayerFloats) return zeta::kErrArgs;
  Locked o(env, out);
  if (!o.ok) return zeta::kErrArgs;
  std::vector<Locked> locks((size_t)count);
  std::vector<zeta::ConstSurface> surfaces((size_t)count, zeta::ConstSurface{nullptr, 0, 0, 0});
  for (jint i = 0; i < count; ++i) {
    jobject b = env->GetObjectArrayElement(layers, i);
    if (b && locks[(size_t)i].lock(env, b)) surfaces[(size_t)i] = locks[(size_t)i].cs();
    if (b) env->DeleteLocalRef(b);
  }
  jfloat* p = env->GetFloatArrayElements(params, nullptr);
  if (!p) return zeta::kErrAlloc;
  int rc = zeta::compositeLayers(surfaces.data(), p, (int)count, o.s, blurScale);
  env->ReleaseFloatArrayElements(params, p, JNI_ABORT);
  return rc;
}

JNI_FN(nativeRenderSingle)(JNIEnv* env, jclass, jobject layer, jfloatArray params, jobject out, jfloat blurScale) {
  if (!params || env->GetArrayLength(params) < zeta::kLayerFloats) return zeta::kErrArgs;
  Locked l(env, layer), o(env, out);
  if (!l.ok || !o.ok) return zeta::kErrArgs;
  jfloat* p = env->GetFloatArrayElements(params, nullptr);
  if (!p) return zeta::kErrAlloc;
  int rc = zeta::renderSingleLayer(l.cs(), p, o.s, blurScale);
  env->ReleaseFloatArrayElements(params, p, JNI_ABORT);
  return rc;
}

JNI_FN(nativeResize)(JNIEnv* env, jclass, jobject src, jobject dst) {
  Locked s(env, src), d(env, dst);
  if (!s.ok || !d.ok) return zeta::kErrArgs;
  return zeta::resizeSurface(s.cs(), d.s);
}

JNI_FN(nativeRotate90)(JNIEnv* env, jclass, jobject src, jobject dst, jboolean cw) {
  Locked s(env, src), d(env, dst);
  if (!s.ok || !d.ok) return zeta::kErrArgs;
  return zeta::rotate90(s.cs(), d.s, cw == JNI_TRUE);
}

JNI_FN(nativeFlip)(JNIEnv* env, jclass, jobject src, jobject dst, jboolean horizontal) {
  Locked s(env, src), d(env, dst);
  if (!s.ok || !d.ok) return zeta::kErrArgs;
  return zeta::flipSurface(s.cs(), d.s, horizontal == JNI_TRUE);
}

JNI_FN(nativeCrop)(JNIEnv* env, jclass, jobject src, jobject dst, jint x, jint y) {
  Locked s(env, src), d(env, dst);
  if (!s.ok || !d.ok) return zeta::kErrArgs;
  return zeta::cropSurface(s.cs(), d.s, x, y);
}

// 1 = something selected afterwards, 0 = nothing, <0 error
JNI_FN(nativeInvertMask)(JNIEnv* env, jclass, jobject mask) {
  Locked m(env, mask);
  if (!m.ok) return zeta::kErrArgs;
  return zeta::invertMask(m.s) ? 1 : 0;
}

JNI_FN(nativeAlphaBounds)(JNIEnv* env, jclass, jobject bmp, jint thr, jintArray outBox) {
  if (!outBox || env->GetArrayLength(outBox) < 4) return zeta::kErrArgs;
  Locked b(env, bmp);
  if (!b.ok) return zeta::kErrArgs;
  int box[4] = {0, 0, 0, 0};
  bool found = zeta::alphaBounds(b.cs(), thr, box);
  if (found) env->SetIntArrayRegion(outBox, 0, 4, reinterpret_cast<const jint*>(box));
  return found ? 1 : 0;
}

JNI_FN(nativeDestinationIn)(JNIEnv* env, jclass, jobject dst, jobject mask) {
  Locked d(env, dst), m(env, mask);
  if (!d.ok || !m.ok) return zeta::kErrArgs;
  return zeta::destinationIn(d.s, m.cs());
}

JNI_FN(nativeDestinationOut)(JNIEnv* env, jclass, jobject dst, jobject src) {
  Locked d(env, dst), s(env, src);
  if (!d.ok || !s.ok) return zeta::kErrArgs;
  return zeta::destinationOut(d.s, s.cs());
}

JNI_FN(nativeSourceOver)(JNIEnv* env, jclass, jobject dst, jobject src) {
  Locked d(env, dst), s(env, src);
  if (!d.ok || !s.ok) return zeta::kErrArgs;
  return zeta::sourceOver(d.s, s.cs());
}

JNI_FN(nativeTintMask)(JNIEnv* env, jclass, jobject dst, jobject mask, jint r, jint g, jint b, jint aScale) {
  Locked d(env, dst), m(env, mask);
  if (!d.ok || !m.ok) return zeta::kErrArgs;
  return zeta::tintMask(d.s, m.cs(), (uint8_t)r, (uint8_t)g, (uint8_t)b, (uint8_t)aScale);
}

JNI_FN(nativeEffectRegion)(JNIEnv* env, jclass, jobject snap, jint x0, jint y0, jint bw, jint bh, jint key, jfloat p,
                           jobject out) {
  Locked s(env, snap), o(env, out);
  if (!s.ok || !o.ok) return zeta::kErrArgs;
  return zeta::effectRegion(s.cs(), x0, y0, bw, bh, key, p, o.s);
}
