// Zetaphii native engine implementation.
// Ported 1:1 from the original ADJUST / BLUR / BLEND fragment shaders and the
// Canvas-based pixel helpers in the TypeScript sources (04-shaders.ts, 06-renderer.ts,
// 08-image-loading-transforms.ts, 16-import.ts, 22-drawing-*.ts).
#include "native_engine.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <new>
#include <thread>
#include <vector>

namespace zeta {
namespace {

// ---------------------------------------------------------------- helpers ---
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float fractf(float x) { return x - std::floor(x); }
inline float mixf(float a, float b, float t) { return a * (1.f - t) + b * t; }
inline float smoothstepf(float e0, float e1, float x) {
  float t = clampf((x - e0) / (e1 - e0), 0.f, 1.f);
  return t * t * (3.f - 2.f * t);
}
inline uint8_t to8(float v) {
  if (!(v > 0.f)) return 0;  // also catches NaN
  if (v >= 1.f) return 255;
  return (uint8_t)(v * 255.f + 0.5f);
}

int workerCount() {
  unsigned n = std::thread::hardware_concurrency();
  if (n == 0) n = 1;
  if (n > 4) n = 4;  // keep headroom for the UI thread on mid-range devices
  return (int)n;
}

// Splits [0,rows) into contiguous bands and runs fn(y0,y1) on each.
template <class F>
void parallelRows(int rows, F&& fn) {
  int nt = workerCount();
  if (nt <= 1 || rows < 64) {
    fn(0, rows);
    return;
  }
  int per = (rows + nt - 1) / nt;
  std::vector<std::thread> ts;
  ts.reserve((size_t)nt);
  for (int t = 1; t < nt; ++t) {
    int a = t * per, b = std::min(rows, a + per);
    if (a >= b) break;
    ts.emplace_back([&fn, a, b]() { fn(a, b); });
  }
  fn(0, std::min(rows, per));
  for (auto& th : ts) th.join();
}

inline void unpremul(const uint8_t* s, uint8_t* d) {
  uint8_t a = s[3];
  if (a == 255) {
    std::memcpy(d, s, 4);
  } else if (a == 0) {
    d[0] = d[1] = d[2] = 0;
    d[3] = 0;
  } else {
    d[0] = (uint8_t)std::min(255, ((int)s[0] * 255 + a / 2) / a);
    d[1] = (uint8_t)std::min(255, ((int)s[1] * 255 + a / 2) / a);
    d[2] = (uint8_t)std::min(255, ((int)s[2] * 255 + a / 2) / a);
    d[3] = a;
  }
}
inline void premulPx(const uint8_t* s, uint8_t* d) {
  uint8_t a = s[3];
  if (a == 255) {
    std::memcpy(d, s, 4);
  } else {
    d[0] = (uint8_t)(((int)s[0] * a + 127) / 255);
    d[1] = (uint8_t)(((int)s[1] * a + 127) / 255);
    d[2] = (uint8_t)(((int)s[2] * a + 127) / 255);
    d[3] = a;
  }
}

// Bilinear sample of a tightly packed straight-alpha RGBA8 buffer at normalized (u,v),
// LINEAR filter + CLAMP_TO_EDGE (texel centers at (i+0.5)/w).
inline void sampleStraight(const uint8_t* buf, int w, int h, float u, float v, float out[4]) {
  float tx = u * (float)w - 0.5f, ty = v * (float)h - 0.5f;
  float fx0 = std::floor(tx), fy0 = std::floor(ty);
  float fx = tx - fx0, fy = ty - fy0;
  int x0 = (int)fx0, y0 = (int)fy0;
  int x1 = x0 + 1, y1 = y0 + 1;
  x0 = x0 < 0 ? 0 : (x0 >= w ? w - 1 : x0);
  x1 = x1 < 0 ? 0 : (x1 >= w ? w - 1 : x1);
  y0 = y0 < 0 ? 0 : (y0 >= h ? h - 1 : y0);
  y1 = y1 < 0 ? 0 : (y1 >= h ? h - 1 : y1);
  const uint8_t* p00 = buf + ((size_t)y0 * w + x0) * 4;
  const uint8_t* p10 = buf + ((size_t)y0 * w + x1) * 4;
  const uint8_t* p01 = buf + ((size_t)y1 * w + x0) * 4;
  const uint8_t* p11 = buf + ((size_t)y1 * w + x1) * 4;
  for (int c = 0; c < 4; ++c) {
    float top = mixf((float)p00[c], (float)p10[c], fx);
    float bot = mixf((float)p01[c], (float)p11[c], fx);
    out[c] = mixf(top, bot, fy) * (1.f / 255.f);
  }
}

// ------------------------------------------------------------- resampling ---
// Premultiplied RGBA8, tightly packed vector-backed image.
struct Pm {
  int w = 0, h = 0;
  std::vector<uint8_t> d;
};

bool halve(const uint8_t* src, int sw, int sh, int sstride, bool hx, bool hy, Pm& out) {
  int dw = hx ? (sw + 1) / 2 : sw;
  int dh = hy ? (sh + 1) / 2 : sh;
  try {
    out.d.resize((size_t)dw * dh * 4);
  } catch (const std::bad_alloc&) {
    return false;
  }
  out.w = dw;
  out.h = dh;
  parallelRows(dh, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      int sy0 = hy ? y * 2 : y;
      int sy1 = hy ? std::min(sh - 1, sy0 + 1) : sy0;
      for (int x = 0; x < dw; ++x) {
        int sx0 = hx ? x * 2 : x;
        int sx1 = hx ? std::min(sw - 1, sx0 + 1) : sx0;
        const uint8_t* a = src + (size_t)sy0 * sstride + (size_t)sx0 * 4;
        const uint8_t* b = src + (size_t)sy0 * sstride + (size_t)sx1 * 4;
        const uint8_t* c = src + (size_t)sy1 * sstride + (size_t)sx0 * 4;
        const uint8_t* e = src + (size_t)sy1 * sstride + (size_t)sx1 * 4;
        uint8_t* o = out.d.data() + ((size_t)y * dw + x) * 4;
        for (int k = 0; k < 4; ++k) o[k] = (uint8_t)(((int)a[k] + b[k] + c[k] + e[k] + 2) >> 2);
      }
    }
  });
  return true;
}

void bilinearPremul(const uint8_t* src, int sw, int sh, int sstride, Surface dst) {
  float sx = (float)sw / (float)dst.w, sy = (float)sh / (float)dst.h;
  parallelRows(dst.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      float fy = ((float)y + 0.5f) * sy - 0.5f;
      float fy0 = std::floor(fy);
      float wy = fy - fy0;
      int ya = (int)fy0, yb = ya + 1;
      ya = ya < 0 ? 0 : (ya >= sh ? sh - 1 : ya);
      yb = yb < 0 ? 0 : (yb >= sh ? sh - 1 : yb);
      uint8_t* orow = dst.px + (size_t)y * dst.stride;
      for (int x = 0; x < dst.w; ++x) {
        float fx = ((float)x + 0.5f) * sx - 0.5f;
        float fx0 = std::floor(fx);
        float wx = fx - fx0;
        int xa = (int)fx0, xb = xa + 1;
        xa = xa < 0 ? 0 : (xa >= sw ? sw - 1 : xa);
        xb = xb < 0 ? 0 : (xb >= sw ? sw - 1 : xb);
        const uint8_t* p00 = src + (size_t)ya * sstride + (size_t)xa * 4;
        const uint8_t* p10 = src + (size_t)ya * sstride + (size_t)xb * 4;
        const uint8_t* p01 = src + (size_t)yb * sstride + (size_t)xa * 4;
        const uint8_t* p11 = src + (size_t)yb * sstride + (size_t)xb * 4;
        uint8_t* o = orow + (size_t)x * 4;
        for (int k = 0; k < 4; ++k) {
          float t = mixf((float)p00[k], (float)p10[k], wx);
          float b = mixf((float)p01[k], (float)p11[k], wx);
          float v = mixf(t, b, wy);
          o[k] = (uint8_t)(v + 0.5f);
        }
      }
    }
  });
}

// High-quality resample (repeated 2x box reduction, then bilinear) — the native
// counterpart of canvas drawImage + imageSmoothingQuality='high'.
int resamplePremul(const ConstSurface& src, Surface dst) {
  if (!src.px || !dst.px || src.w < 1 || src.h < 1 || dst.w < 1 || dst.h < 1) return kErrArgs;
  if (src.w == dst.w && src.h == dst.h) {
    for (int y = 0; y < dst.h; ++y)
      std::memcpy(dst.px + (size_t)y * dst.stride, src.px + (size_t)y * src.stride, (size_t)dst.w * 4);
    return kOk;
  }
  const uint8_t* cur = src.px;
  int cw = src.w, ch = src.h, cs = src.stride;
  Pm a, b;
  Pm* tgt = &a;
  Pm* other = &b;
  for (;;) {
    bool hx = cw >= 2 * dst.w, hy = ch >= 2 * dst.h;
    if (!hx && !hy) break;
    if (!halve(cur, cw, ch, cs, hx, hy, *tgt)) return kErrAlloc;
    cur = tgt->d.data();
    cw = tgt->w;
    ch = tgt->h;
    cs = cw * 4;
    std::swap(tgt, other);
  }
  bilinearPremul(cur, cw, ch, cs, dst);
  return kOk;
}

// ------------------------------------------------------------- blur / adjust ---
// One separable pass of the 9-tap Gaussian from BLUR_FRAG_SRC. Taps sit at
// k*radius texels from the pixel centre and are bilinearly filtered (LINEAR),
// exactly like the shader. dirX selects horizontal (true) or vertical (false).
void blurPass(const uint8_t* src, uint8_t* dst, int w, int h, float radius, bool dirX) {
  static const float W0 = 0.227027f;
  static const float WK[4] = {0.1945946f, 0.1216216f, 0.0540540f, 0.0162162f};
  parallelRows(h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      for (int x = 0; x < w; ++x) {
        float acc[4];
        const uint8_t* c = src + ((size_t)y * w + x) * 4;
        for (int k = 0; k < 4; ++k) acc[k] = (float)c[k] * W0;
        for (int t = 1; t <= 4; ++t) {
          float off = radius * (float)t;
          for (int sgn = -1; sgn <= 1; sgn += 2) {
            float fpos = (dirX ? (float)x : (float)y) + (float)sgn * off;
            float f0 = std::floor(fpos);
            float fr = fpos - f0;
            int i0 = (int)f0, i1 = i0 + 1;
            int lim = dirX ? w : h;
            i0 = i0 < 0 ? 0 : (i0 >= lim ? lim - 1 : i0);
            i1 = i1 < 0 ? 0 : (i1 >= lim ? lim - 1 : i1);
            const uint8_t* p0 = dirX ? src + ((size_t)y * w + i0) * 4 : src + ((size_t)i0 * w + x) * 4;
            const uint8_t* p1 = dirX ? src + ((size_t)y * w + i1) * 4 : src + ((size_t)i1 * w + x) * 4;
            float wk = WK[t - 1];
            for (int k = 0; k < 4; ++k) acc[k] += mixf((float)p0[k], (float)p1[k], fr) * wk;
          }
        }
        uint8_t* o = dst + ((size_t)y * w + x) * 4;
        for (int k = 0; k < 4; ++k) o[k] = to8(acc[k] * (1.f / 255.f));
      }
    }
  });
}

inline float hash12(float px, float py) {
  float a = fractf(px * 0.1031f), b = fractf(py * 0.1031f), c = fractf(px * 0.1031f);
  // p3 = fract(vec3(p.xyx) * 0.1031)   -> (a, b, c) with c == a
  float d = a * (b + 33.33f) + b * (c + 33.33f) + c * (a + 33.33f);  // dot(p3, p3.yzx + 33.33)
  a += d;
  b += d;
  c += d;
  return fractf((a + b) * c);
}

inline void hueRotate(float c[3], float deg) {
  float a = deg * 0.017453292519943295f;
  float cosA = std::cos(a), sinA = std::sin(a);
  const float k = 0.57735026919f;
  float cx = k * c[2] - k * c[1];
  float cy = k * c[0] - k * c[2];
  float cz = k * c[1] - k * c[0];
  float dot = k * c[0] + k * c[1] + k * c[2];
  float m = k * dot * (1.f - cosA);
  float r0 = c[0] * cosA + cx * sinA + m;
  float r1 = c[1] * cosA + cy * sinA + m;
  float r2 = c[2] * cosA + cz * sinA + m;
  c[0] = r0;
  c[1] = r1;
  c[2] = r2;
}

// ADJUST_FRAG_SRC.  src/dst are straight-alpha RGBA8, tightly packed, w*h.
void adjustPass(const uint8_t* src, uint8_t* dst, int w, int h, const float* p) {
  const float brightness = p[LF_BRIGHTNESS], contrast = p[LF_CONTRAST], saturation = p[LF_SATURATION];
  const float vibrance = p[LF_VIBRANCE], exposure = p[LF_EXPOSURE], highlights = p[LF_HIGHLIGHTS];
  const float shadows = p[LF_SHADOWS], temperature = p[LF_TEMPERATURE], tint = p[LF_TINT];
  const float sharpness = p[LF_SHARPNESS], opacity = p[LF_OPACITY], posterize = p[LF_POSTERIZE];
  const float pixelate = p[LF_PIXELATE], grain = p[LF_GRAIN], vignette = p[LF_VIGNETTE];
  const float invert = p[LF_INVERT], hue = p[LF_HUE];
  const float expMul = std::pow(2.f, exposure);
  const float blocksX = pixelate;
  const float blocksY = std::max(1.f, pixelate * (float)h / (float)w);  // uTexel.x / uTexel.y == h / w

  parallelRows(h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      for (int x = 0; x < w; ++x) {
        const uint8_t* sp = src + ((size_t)y * w + x) * 4;
        float u = ((float)x + 0.5f) / (float)w, v = ((float)y + 0.5f) / (float)h;
        float s[4] = {sp[0] * (1.f / 255.f), sp[1] * (1.f / 255.f), sp[2] * (1.f / 255.f), sp[3] * (1.f / 255.f)};
        if (pixelate >= 2.f) {
          float gx = std::floor(u * blocksX), gy = std::floor(v * blocksY);
          sampleStraight(src, w, h, (gx + 0.5f) / blocksX, (gy + 0.5f) / blocksY, s);
        }
        float c0 = s[0], c1 = s[1], c2 = s[2];
        c0 += temperature + tint * 0.5f;
        c1 -= tint;
        c2 += -temperature + tint * 0.5f;
        c0 *= expMul;
        c1 *= expMul;
        c2 *= expMul;
        c0 += brightness;
        c1 += brightness;
        c2 += brightness;
        c0 = (c0 - 0.5f) * contrast + 0.5f;
        c1 = (c1 - 0.5f) * contrast + 0.5f;
        c2 = (c2 - 0.5f) * contrast + 0.5f;
        float luma = clampf(c0, 0.f, 1.f) * 0.299f + clampf(c1, 0.f, 1.f) * 0.587f + clampf(c2, 0.f, 1.f) * 0.114f;
        float hMask = smoothstepf(0.25f, 1.0f, luma);
        float sMask = 1.f - smoothstepf(0.0f, 0.75f, luma);
        float hl = highlights * hMask * 0.6f, sh = shadows * sMask * 0.6f;
        c0 += hl;
        c1 += hl;
        c2 += hl;
        c0 += sh;
        c1 += sh;
        c2 += sh;
        float mx = std::max(std::max(c0, c1), c2), mn = std::min(std::min(c0, c1), c2);
        float sat = mx - mn;
        float lumaV = c0 * 0.299f + c1 * 0.587f + c2 * 0.114f;
        float vf = 1.f + vibrance * (1.f - sat);
        c0 = mixf(lumaV, c0, vf);
        c1 = mixf(lumaV, c1, vf);
        c2 = mixf(lumaV, c2, vf);
        float lumaS = c0 * 0.299f + c1 * 0.587f + c2 * 0.114f;
        c0 = mixf(lumaS, c0, saturation);
        c1 = mixf(lumaS, c1, saturation);
        c2 = mixf(lumaS, c2, saturation);
        if (sharpness > 0.001f || sharpness < -0.001f) {
          int xl = x > 0 ? x - 1 : 0, xr = x < w - 1 ? x + 1 : w - 1;
          int yu = y > 0 ? y - 1 : 0, yd = y < h - 1 ? y + 1 : h - 1;
          const uint8_t* pr = src + ((size_t)y * w + xr) * 4;
          const uint8_t* pl = src + ((size_t)y * w + xl) * 4;
          const uint8_t* pd = src + ((size_t)yd * w + x) * 4;
          const uint8_t* pu = src + ((size_t)yu * w + x) * 4;
          float n0 = (pr[0] + pl[0] + pd[0] + pu[0]) * (0.25f / 255.f);
          float n1 = (pr[1] + pl[1] + pd[1] + pu[1]) * (0.25f / 255.f);
          float n2 = (pr[2] + pl[2] + pd[2] + pu[2]) * (0.25f / 255.f);
          c0 += (s[0] - n0) * sharpness;
          c1 += (s[1] - n1) * sharpness;
          c2 += (s[2] - n2) * sharpness;
        }
        if (std::fabs(hue) > 0.001f) {
          float cc[3] = {c0, c1, c2};
          hueRotate(cc, hue);
          c0 = cc[0];
          c1 = cc[1];
          c2 = cc[2];
        }
        float inv = clampf(invert, 0.f, 1.f);
        c0 = mixf(c0, 1.f - c0, inv);
        c1 = mixf(c1, 1.f - c1, inv);
        c2 = mixf(c2, 1.f - c2, inv);
        if (posterize >= 2.f) {
          float levels = posterize - 1.f;
          c0 = std::floor(c0 * levels + 0.5f) / levels;
          c1 = std::floor(c1 * levels + 0.5f) / levels;
          c2 = std::floor(c2 * levels + 0.5f) / levels;
        }
        if (grain > 0.001f) {
          // gl_FragCoord.xy: pixel centre, origin bottom-left (rows are stored top-down here)
          float n = (hash12((float)x + 0.5f, (float)(h - 1 - y) + 0.5f) - 0.5f) * grain;
          c0 += n;
          c1 += n;
          c2 += n;
        }
        if (vignette > 0.001f) {
          float dx = u - 0.5f, dy = v - 0.5f;
          float d = std::sqrt(dx * dx + dy * dy);
          float f = 1.f - vignette * smoothstepf(0.35f, 0.95f, d);
          c0 *= f;
          c1 *= f;
          c2 *= f;
        }
        uint8_t* o = dst + ((size_t)y * w + x) * 4;
        o[0] = to8(c0);
        o[1] = to8(c1);
        o[2] = to8(c2);
        o[3] = to8(s[3] * opacity);
      }
    }
  });
}

// ------------------------------------------------------------------ blend ---
inline float lumF(const float c[3]) { return c[0] * 0.3f + c[1] * 0.59f + c[2] * 0.11f; }
inline void clipColor(float c[3]) {
  float l = lumF(c);
  float n = std::min(std::min(c[0], c[1]), c[2]);
  float x = std::max(std::max(c[0], c[1]), c[2]);
  if (n < 0.f) {
    float f = l / std::max(l - n, 0.0001f);
    for (int i = 0; i < 3; ++i) c[i] = l + (c[i] - l) * f;
  }
  if (x > 1.f) {
    float f = (1.f - l) / std::max(x - l, 0.0001f);
    for (int i = 0; i < 3; ++i) c[i] = l + (c[i] - l) * f;
  }
}
inline void setLum(const float c[3], float l, float out[3]) {
  float d = l - lumF(c);
  out[0] = c[0] + d;
  out[1] = c[1] + d;
  out[2] = c[2] + d;
  clipColor(out);
}
inline float satF(const float c[3]) {
  return std::max(std::max(c[0], c[1]), c[2]) - std::min(std::min(c[0], c[1]), c[2]);
}
inline void setSat(const float c[3], float s, float out[3]) {
  float cmax = std::max(std::max(c[0], c[1]), c[2]);
  float cmin = std::min(std::min(c[0], c[1]), c[2]);
  if (cmax > cmin) {
    for (int i = 0; i < 3; ++i) out[i] = (c[i] - cmin) * s / (cmax - cmin);
  } else {
    out[0] = out[1] = out[2] = 0.f;
  }
}

inline void blendRGB(const float b[3], const float s[3], int mode, float r[3]) {
  switch (mode) {
    case 0:
      r[0] = s[0], r[1] = s[1], r[2] = s[2];
      return;
    case 1:
      for (int i = 0; i < 3; ++i) r[i] = b[i] * s[i];
      return;
    case 2:
      for (int i = 0; i < 3; ++i) r[i] = b[i] + s[i] - b[i] * s[i];
      return;
    case 3:  // overlay
      for (int i = 0; i < 3; ++i)
        r[i] = b[i] <= 0.5f ? 2.f * b[i] * s[i] : 1.f - 2.f * (1.f - b[i]) * (1.f - s[i]);
      return;
    case 4:  // soft light
      for (int i = 0; i < 3; ++i) {
        float d = b[i] <= 0.25f ? ((16.f * b[i] - 12.f) * b[i] + 4.f) * b[i] : std::sqrt(b[i]);
        r[i] = s[i] <= 0.5f ? b[i] - (1.f - 2.f * s[i]) * b[i] * (1.f - b[i])
                            : b[i] + (2.f * s[i] - 1.f) * (d - b[i]);
      }
      return;
    case 5:  // hard light
      for (int i = 0; i < 3; ++i)
        r[i] = s[i] <= 0.5f ? 2.f * b[i] * s[i] : 1.f - 2.f * (1.f - b[i]) * (1.f - s[i]);
      return;
    case 6:  // color burn
      for (int i = 0; i < 3; ++i) r[i] = s[i] <= 0.f ? 0.f : 1.f - std::min(1.f, (1.f - b[i]) / s[i]);
      return;
    case 7:
      for (int i = 0; i < 3; ++i) r[i] = clampf(b[i] + s[i] - 1.f, 0.f, 1.f);
      return;
    case 8:  // color dodge
      for (int i = 0; i < 3; ++i) r[i] = s[i] >= 1.f ? 1.f : std::min(1.f, b[i] / (1.f - s[i]));
      return;
    case 9:
      for (int i = 0; i < 3; ++i) r[i] = clampf(b[i] + s[i], 0.f, 1.f);
      return;
    case 10:
      for (int i = 0; i < 3; ++i) r[i] = std::fabs(b[i] - s[i]);
      return;
    case 11:
      for (int i = 0; i < 3; ++i) r[i] = b[i] + s[i] - 2.f * b[i] * s[i];
      return;
    case 12:  // hard mix
      for (int i = 0; i < 3; ++i) r[i] = (b[i] + s[i]) < 1.f ? 0.f : 1.f;
      return;
    case 13:  // divide
      for (int i = 0; i < 3; ++i) r[i] = clampf(b[i] / std::max(s[i], 0.003f), 0.f, 1.f);
      return;
    case 14:  // subtract
      for (int i = 0; i < 3; ++i) r[i] = clampf(b[i] - s[i], 0.f, 1.f);
      return;
    case 15: {  // hue
      float t[3];
      setSat(s, satF(b), t);
      setLum(t, lumF(b), r);
      return;
    }
    case 16: {  // saturation
      float t[3];
      setSat(b, satF(s), t);
      setLum(t, lumF(b), r);
      return;
    }
    case 17:  // color
      setLum(s, lumF(b), r);
      return;
    case 18:  // luminosity
      setLum(b, lumF(s), r);
      return;
    default:
      r[0] = s[0], r[1] = s[1], r[2] = s[2];
      return;
  }
}

// BLEND_FRAG_SRC: accum (straight RGBA8) <- blend(accum, src).
void blendPass(uint8_t* accum, const uint8_t* src, int w, int h, int mode) {
  parallelRows(h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      for (int x = 0; x < w; ++x) {
        size_t i = ((size_t)y * w + x) * 4;
        const uint8_t* bp = accum + i;
        const uint8_t* sp = src + i;
        float b[3] = {bp[0] * (1.f / 255.f), bp[1] * (1.f / 255.f), bp[2] * (1.f / 255.f)};
        float s[3] = {sp[0] * (1.f / 255.f), sp[1] * (1.f / 255.f), sp[2] * (1.f / 255.f)};
        float ba = bp[3] * (1.f / 255.f), sa = sp[3] * (1.f / 255.f);
        float bl[3];
        blendRGB(b, s, mode, bl);
        float outA = sa + ba * (1.f - sa);
        uint8_t* o = accum + i;
        o[0] = to8(mixf(b[0], bl[0], sa));
        o[1] = to8(mixf(b[1], bl[1], sa));
        o[2] = to8(mixf(b[2], bl[2], sa));
        o[3] = to8(outA);
      }
    }
  });
}

// Layer (premultiplied, any size) -> straight-alpha RGBA8 buffer of exactly w*h.
// `scratch` must hold w*h*4 bytes (used when the layer needs resampling).
int loadStraight(const ConstSurface& layer, uint8_t* dst, int w, int h, uint8_t* scratch) {
  if (layer.w == w && layer.h == h) {
    parallelRows(h, [&](int y0, int y1) {
      for (int y = y0; y < y1; ++y) {
        const uint8_t* s = layer.px + (size_t)y * layer.stride;
        uint8_t* d = dst + (size_t)y * w * 4;
        for (int x = 0; x < w; ++x) unpremul(s + (size_t)x * 4, d + (size_t)x * 4);
      }
    });
    return kOk;
  }
  Surface tmp{scratch, w, h, w * 4};
  int rc = resamplePremul(layer, tmp);
  if (rc != kOk) return rc;
  parallelRows(h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      const uint8_t* s = scratch + (size_t)y * w * 4;
      uint8_t* d = dst + (size_t)y * w * 4;
      for (int x = 0; x < w; ++x) unpremul(s + (size_t)x * 4, d + (size_t)x * 4);
    }
  });
  return kOk;
}

void storePremul(const uint8_t* straight, Surface out) {
  parallelRows(out.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      const uint8_t* s = straight + (size_t)y * out.w * 4;
      uint8_t* d = out.px + (size_t)y * out.stride;
      for (int x = 0; x < out.w; ++x) premulPx(s + (size_t)x * 4, d + (size_t)x * 4);
    }
  });
}

}  // namespace

// ============================================================ public API ====

bool isIdentityAdjust(const float* lf) {
  return lf[LF_BRIGHTNESS] == 0.f && lf[LF_CONTRAST] == 1.f && lf[LF_SATURATION] == 1.f &&
         lf[LF_VIBRANCE] == 0.f && lf[LF_EXPOSURE] == 0.f && lf[LF_HIGHLIGHTS] == 0.f &&
         lf[LF_SHADOWS] == 0.f && lf[LF_TEMPERATURE] == 0.f && lf[LF_TINT] == 0.f &&
         (lf[LF_SHARPNESS] == 0.f || std::fabs(lf[LF_SHARPNESS]) < 0.0001f) && lf[LF_OPACITY] == 1.f &&
         (lf[LF_POSTERIZE] == 0.f || lf[LF_POSTERIZE] < 2.f) &&
         (lf[LF_PIXELATE] == 0.f || lf[LF_PIXELATE] < 2.f) &&
         (lf[LF_GRAIN] == 0.f || lf[LF_GRAIN] < 0.001f) &&
         (lf[LF_VIGNETTE] == 0.f || lf[LF_VIGNETTE] < 0.001f) &&
         (lf[LF_INVERT] == 0.f || lf[LF_INVERT] < 0.001f) &&
         (lf[LF_HUE] == 0.f || std::fabs(lf[LF_HUE]) < 0.001f);
}

int compositeLayers(const ConstSurface* layers, const float* params, int n, Surface out, float blurScale) {
  if (!out.px || out.w < 1 || out.h < 1 || n < 0) return kErrArgs;
  std::vector<int> vis;
  for (int i = 0; i < n; ++i)
    if (params[i * kLayerFloats + LF_VISIBLE] > 0.5f && layers[i].px) vis.push_back(i);
  if (vis.empty()) {
    for (int y = 0; y < out.h; ++y) std::memset(out.px + (size_t)y * out.stride, 0, (size_t)out.w * 4);
    return kOk;
  }
  const int W = out.w, H = out.h;
  const size_t N = (size_t)W * H * 4;
  std::vector<uint8_t> A, B, C;
  try {
    A.resize(N);
    B.resize(N);
    C.resize(N);
  } catch (const std::bad_alloc&) {
    return kErrAlloc;
  }
  bool first = true;
  for (int idx : vis) {
    const float* p = params + (size_t)idx * kLayerFloats;
    int rc = loadStraight(layers[idx], B.data(), W, H, C.data());
    if (rc != kOk) return rc;
    const uint8_t* cur = B.data();
    float blur = p[LF_BLUR];
    if (blur > 0.01f) {
      blurPass(B.data(), C.data(), W, H, blur * blurScale, true);
      blurPass(C.data(), B.data(), W, H, blur * blurScale, false);
    }
    if (!isIdentityAdjust(p)) {
      adjustPass(B.data(), C.data(), W, H, p);
      cur = C.data();
    }
    if (first) {
      std::memcpy(A.data(), cur, N);
      first = false;
    } else {
      blendPass(A.data(), cur, W, H, (int)p[LF_BLEND]);
    }
  }
  storePremul(A.data(), out);
  return kOk;
}

int renderSingleLayer(const ConstSurface& layer, const float* lf, Surface out, float blurScale) {
  float tmp[kLayerFloats];
  std::memcpy(tmp, lf, sizeof(tmp));
  tmp[LF_VISIBLE] = 1.f;
  tmp[LF_BLEND] = 0.f;
  return compositeLayers(&layer, tmp, 1, out, blurScale);
}

int resizeSurface(const ConstSurface& src, Surface dst) { return resamplePremul(src, dst); }

int rotate90(const ConstSurface& src, Surface dst, bool cw) {
  if (!src.px || !dst.px || dst.w != src.h || dst.h != src.w) return kErrArgs;
  parallelRows(src.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      const uint8_t* s = src.px + (size_t)y * src.stride;
      for (int x = 0; x < src.w; ++x) {
        int dx = cw ? (src.h - 1 - y) : y;
        int dy = cw ? x : (src.w - 1 - x);
        std::memcpy(dst.px + (size_t)dy * dst.stride + (size_t)dx * 4, s + (size_t)x * 4, 4);
      }
    }
  });
  return kOk;
}

int flipSurface(const ConstSurface& src, Surface dst, bool horizontal) {
  if (!src.px || !dst.px || dst.w != src.w || dst.h != src.h) return kErrArgs;
  for (int y = 0; y < src.h; ++y) {
    const uint8_t* s = src.px + (size_t)y * src.stride;
    uint8_t* d = dst.px + (size_t)(horizontal ? y : src.h - 1 - y) * dst.stride;
    if (horizontal) {
      for (int x = 0; x < src.w; ++x) std::memcpy(d + (size_t)(src.w - 1 - x) * 4, s + (size_t)x * 4, 4);
    } else {
      std::memcpy(d, s, (size_t)src.w * 4);
    }
  }
  return kOk;
}

int cropSurface(const ConstSurface& src, Surface dst, int x, int y) {
  if (!src.px || !dst.px || x < 0 || y < 0 || x + dst.w > src.w || y + dst.h > src.h) return kErrArgs;
  for (int r = 0; r < dst.h; ++r)
    std::memcpy(dst.px + (size_t)r * dst.stride, src.px + (size_t)(y + r) * src.stride + (size_t)x * 4,
                (size_t)dst.w * 4);
  return kOk;
}

bool invertMask(Surface m) {
  bool any = false;
  for (int y = 0; y < m.h; ++y) {
    uint8_t* r = m.px + (size_t)y * m.stride;
    for (int x = 0; x < m.w; ++x) {
      uint8_t* p = r + (size_t)x * 4;
      if (p[3] > 8) {
        p[0] = p[1] = p[2] = p[3] = 0;
      } else {
        p[0] = p[1] = p[2] = p[3] = 255;
        any = true;
      }
    }
  }
  return any;
}

bool alphaBounds(const ConstSurface& s, int thr, int* box) {
  int minX = s.w, minY = s.h, maxX = -1, maxY = -1;
  for (int y = 0; y < s.h; ++y) {
    const uint8_t* r = s.px + (size_t)y * s.stride;
    for (int x = 0; x < s.w; ++x) {
      if (r[(size_t)x * 4 + 3] > thr) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return false;
  box[0] = minX;
  box[1] = minY;
  box[2] = maxX - minX + 1;
  box[3] = maxY - minY + 1;
  return true;
}

int destinationIn(Surface dst, const ConstSurface& mask) {
  if (dst.w != mask.w || dst.h != mask.h) return kErrArgs;
  parallelRows(dst.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      uint8_t* d = dst.px + (size_t)y * dst.stride;
      const uint8_t* m = mask.px + (size_t)y * mask.stride;
      for (int x = 0; x < dst.w; ++x) {
        int a = m[(size_t)x * 4 + 3];
        uint8_t* p = d + (size_t)x * 4;
        if (a == 255) continue;
        for (int k = 0; k < 4; ++k) p[k] = (uint8_t)(((int)p[k] * a + 127) / 255);
      }
    }
  });
  return kOk;
}

int destinationOut(Surface dst, const ConstSurface& src) {
  if (dst.w != src.w || dst.h != src.h) return kErrArgs;
  parallelRows(dst.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      uint8_t* d = dst.px + (size_t)y * dst.stride;
      const uint8_t* m = src.px + (size_t)y * src.stride;
      for (int x = 0; x < dst.w; ++x) {
        int a = 255 - m[(size_t)x * 4 + 3];
        uint8_t* p = d + (size_t)x * 4;
        if (a == 255) continue;
        for (int k = 0; k < 4; ++k) p[k] = (uint8_t)(((int)p[k] * a + 127) / 255);
      }
    }
  });
  return kOk;
}

int sourceOver(Surface dst, const ConstSurface& src) {
  if (dst.w != src.w || dst.h != src.h) return kErrArgs;
  parallelRows(dst.h, [&](int y0, int y1) {
    for (int y = y0; y < y1; ++y) {
      uint8_t* d = dst.px + (size_t)y * dst.stride;
      const uint8_t* s = src.px + (size_t)y * src.stride;
      for (int x = 0; x < dst.w; ++x) {
        const uint8_t* sp = s + (size_t)x * 4;
        uint8_t* dp = d + (size_t)x * 4;
        int sa = sp[3];
        if (sa == 0) continue;
        if (sa == 255) {
          std::memcpy(dp, sp, 4);
          continue;
        }
        int inv = 255 - sa;
        for (int k = 0; k < 4; ++k) dp[k] = (uint8_t)std::min(255, (int)sp[k] + ((int)dp[k] * inv + 127) / 255);
      }
    }
  });
  return kOk;
}

int tintMask(Surface dst, const ConstSurface& mask, uint8_t r, uint8_t g, uint8_t b, uint8_t aScale) {
  if (dst.w != mask.w || dst.h != mask.h) return kErrArgs;
  for (int y = 0; y < dst.h; ++y) {
    uint8_t* d = dst.px + (size_t)y * dst.stride;
    const uint8_t* m = mask.px + (size_t)y * mask.stride;
    for (int x = 0; x < dst.w; ++x) {
      int a = ((int)m[(size_t)x * 4 + 3] * aScale + 127) / 255;
      uint8_t* p = d + (size_t)x * 4;
      p[0] = (uint8_t)(((int)r * a + 127) / 255);
      p[1] = (uint8_t)(((int)g * a + 127) / 255);
      p[2] = (uint8_t)(((int)b * a + 127) / 255);
      p[3] = (uint8_t)a;
    }
  }
  return kOk;
}

// ------------------------------------------------------------ effect brush ---
// Port of fxApplyRegion (22-drawing-*.ts). Works on straight RGBA values of the
// pre-stroke snapshot, alpha untouched, result premultiplied into `out`.
int effectRegion(const ConstSurface& snap, int x0, int y0, int bw, int bh, int key, float p, Surface out) {
  if (!snap.px || !out.px || bw < 1 || bh < 1 || out.w != bw || out.h != bh) return kErrArgs;
  if (x0 < 0 || y0 < 0 || x0 + bw > snap.w || y0 + bh > snap.h) return kErrArgs;
  const int W = snap.w, H = snap.h;
  auto rd = [&](int x, int y, uint8_t s[4]) {
    unpremul(snap.px + (size_t)y * snap.stride + (size_t)x * 4, s);
  };
  auto wr = [&](int x, int y, float r, float g, float b, uint8_t a) {
    uint8_t st[4] = {to8(r), to8(g), to8(b), a};
    premulPx(st, out.px + (size_t)y * out.stride + (size_t)x * 4);
  };
  uint8_t s[4];

  if (key == FX_PIXELATE) {
    float blocksX = std::max(2.f, p);
    float blocksY = std::max(1.f, p * (float)H / (float)W);
    for (int py = 0; py < bh; ++py) {
      float gy = std::floor(((float)(y0 + py) + 0.5f) / (float)H * blocksY);
      int sy = std::min(H - 1, (int)std::floor((gy + 0.5f) / blocksY * (float)H));
      for (int px = 0; px < bw; ++px) {
        float gx = std::floor(((float)(x0 + px) + 0.5f) / (float)W * blocksX);
        int sx = std::min(W - 1, (int)std::floor((gx + 0.5f) / blocksX * (float)W));
        rd(sx, sy, s);
        uint8_t a[4];
        rd(x0 + px, y0 + py, a);
        wr(px, py, s[0] / 255.f, s[1] / 255.f, s[2] / 255.f, a[3]);
      }
    }
    return kOk;
  }
  if (key == FX_BLUR) {
    int rad = std::max(1, (int)std::lround(p / 3.f));
    size_t cnt3 = (size_t)bw * bh * 3;
    std::vector<float> tmp, mid;
    try {
      tmp.resize(cnt3);
      mid.resize(cnt3);
    } catch (const std::bad_alloc&) {
      return kErrAlloc;
    }
    for (int py = 0; py < bh; ++py)
      for (int px = 0; px < bw; ++px) {
        rd(x0 + px, y0 + py, s);
        size_t di = ((size_t)py * bw + px) * 3;
        tmp[di] = s[0];
        tmp[di + 1] = s[1];
        tmp[di + 2] = s[2];
      }
    for (int pass = 0; pass < 3; ++pass) {
      for (int py = 0; py < bh; ++py)
        for (int px = 0; px < bw; ++px) {
          float a0 = 0, a1 = 0, a2 = 0;
          int cnt = 0;
          for (int k = -rad; k <= rad; ++k) {
            int xx = px + k;
            xx = xx < 0 ? 0 : (xx >= bw ? bw - 1 : xx);
            size_t ti = ((size_t)py * bw + xx) * 3;
            a0 += tmp[ti];
            a1 += tmp[ti + 1];
            a2 += tmp[ti + 2];
            ++cnt;
          }
          size_t mi = ((size_t)py * bw + px) * 3;
          mid[mi] = a0 / cnt;
          mid[mi + 1] = a1 / cnt;
          mid[mi + 2] = a2 / cnt;
        }
      for (int py = 0; py < bh; ++py)
        for (int px = 0; px < bw; ++px) {
          float a0 = 0, a1 = 0, a2 = 0;
          int cnt = 0;
          for (int k = -rad; k <= rad; ++k) {
            int yy = py + k;
            yy = yy < 0 ? 0 : (yy >= bh ? bh - 1 : yy);
            size_t mi = ((size_t)yy * bw + px) * 3;
            a0 += mid[mi];
            a1 += mid[mi + 1];
            a2 += mid[mi + 2];
            ++cnt;
          }
          size_t ti = ((size_t)py * bw + px) * 3;
          tmp[ti] = a0 / cnt;
          tmp[ti + 1] = a1 / cnt;
          tmp[ti + 2] = a2 / cnt;
        }
    }
    for (int py = 0; py < bh; ++py)
      for (int px = 0; px < bw; ++px) {
        size_t ti = ((size_t)py * bw + px) * 3;
        uint8_t a[4];
        rd(x0 + px, y0 + py, a);
        wr(px, py, tmp[ti] / 255.f, tmp[ti + 1] / 255.f, tmp[ti + 2] / 255.f, a[3]);
      }
    return kOk;
  }

  for (int py = 0; py < bh; ++py) {
    for (int px = 0; px < bw; ++px) {
      rd(x0 + px, y0 + py, s);
      float r = s[0] / 255.f, g = s[1] / 255.f, b = s[2] / 255.f;
      switch (key) {
        case FX_TEMPERATURE:
          r += p;
          b += -p;
          break;
        case FX_EXPOSURE: {
          float em = std::pow(2.f, p);
          r *= em;
          g *= em;
          b *= em;
          break;
        }
        case FX_BRIGHTNESS:
          r += p;
          g += p;
          b += p;
          break;
        case FX_CONTRAST:
          r = (r - 0.5f) * p + 0.5f;
          g = (g - 0.5f) * p + 0.5f;
          b = (b - 0.5f) * p + 0.5f;
          break;
        case FX_SATURATION: {
          float l = r * 0.299f + g * 0.587f + b * 0.114f;
          r = l + (r - l) * p;
          g = l + (g - l) * p;
          b = l + (b - l) * p;
          break;
        }
        case FX_HUE: {
          float c3[3] = {r, g, b};
          hueRotate(c3, p);
          r = c3[0];
          g = c3[1];
          b = c3[2];
          break;
        }
        case FX_INVERT: {
          float inv = clampf(p, 0.f, 1.f);
          r = r + (1.f - r - r) * inv;
          g = g + (1.f - g - g) * inv;
          b = b + (1.f - b - b) * inv;
          break;
        }
        case FX_POSTERIZE: {
          float levels = std::max(1.f, p - 1.f);
          r = std::floor(r * levels + 0.5f) / levels;
          g = std::floor(g * levels + 0.5f) / levels;
          b = std::floor(b * levels + 0.5f) / levels;
          break;
        }
        case FX_GRAIN: {
          float n = hash12((float)(x0 + px), (float)(H - 1 - (y0 + py))) - 0.5f;
          r += n * p;
          g += n * p;
          b += n * p;
          break;
        }
        case FX_VIGNETTE: {
          float vx = ((float)(x0 + px) + 0.5f) / (float)W - 0.5f;
          float vy = ((float)(y0 + py) + 0.5f) / (float)H - 0.5f;
          float d = std::sqrt(vx * vx + vy * vy);
          float f = 1.f - p * smoothstepf(0.35f, 0.95f, d);
          r *= f;
          g *= f;
          b *= f;
          break;
        }
        default:
          break;
      }
      wr(px, py, r, g, b, s[3]);
    }
  }
  return kOk;
}

int selfTest() {
  // 2x2 opaque layer through an identity composite must be returned unchanged.
  uint8_t src[16] = {10, 20, 30, 255, 40, 50, 60, 255, 70, 80, 90, 255, 100, 110, 120, 255};
  uint8_t dst[16] = {0};
  ConstSurface layer{src, 2, 2, 8};
  float lf[kLayerFloats] = {0};
  lf[LF_VISIBLE] = 1;
  lf[LF_CONTRAST] = 1;
  lf[LF_SATURATION] = 1;
  lf[LF_OPACITY] = 1;
  Surface out{dst, 2, 2, 8};
  if (compositeLayers(&layer, lf, 1, out, 1.f) != kOk) return 1;
  if (std::memcmp(src, dst, 16) != 0) return 2;
  return 0;
}

}  // namespace zeta
