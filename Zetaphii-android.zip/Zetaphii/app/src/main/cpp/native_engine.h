// Zetaphii native engine — pixel pipeline ported from the original WebGL/Canvas code.
//
// All Surface buffers are RGBA8, byte order R,G,B,A, *premultiplied* alpha
// (exactly what Android's ARGB_8888 Bitmap exposes through AndroidBitmap_lockPixels).
// Internally the compositor works in straight-alpha RGBA8 to mirror the original
// WebGL pipeline (texture upload without premultiply, 8-bit FBO ping-pong).
#pragma once
#include <cstddef>
#include <cstdint>

namespace zeta {

struct Surface {
  uint8_t* px;
  int w, h;
  int stride;  // bytes per row
};
struct ConstSurface {
  const uint8_t* px;
  int w, h;
  int stride;
};

// ---- Per-layer parameter block passed from Kotlin (20 floats per layer) -----
constexpr int kLayerFloats = 20;
enum LayerFloat {
  LF_VISIBLE = 0,
  LF_BLEND = 1,
  LF_BLUR = 2,
  LF_BRIGHTNESS = 3,
  LF_CONTRAST = 4,
  LF_SATURATION = 5,
  LF_VIBRANCE = 6,
  LF_EXPOSURE = 7,
  LF_HIGHLIGHTS = 8,
  LF_SHADOWS = 9,
  LF_TEMPERATURE = 10,
  LF_TINT = 11,
  LF_SHARPNESS = 12,
  LF_OPACITY = 13,
  LF_POSTERIZE = 14,
  LF_PIXELATE = 15,
  LF_GRAIN = 16,
  LF_VIGNETTE = 17,
  LF_INVERT = 18,
  LF_HUE = 19
};

// Result codes: 0 = ok, <0 = error
constexpr int kOk = 0;
constexpr int kErrAlloc = -1;
constexpr int kErrArgs = -2;

// True when the adjust pass would be a pure pass-through (mirrors Renderer.isIdentityAdjust).
bool isIdentityAdjust(const float* lf);

// Composite all visible layers (bottom -> top) into `out` (premultiplied).
// Layers whose size differs from `out` are stretched to it, like the original
// (every layer texture is sampled over the full canvas quad).
// blurScale scales the blur radius when `out` is a reduced-size preview.
int compositeLayers(const ConstSurface* layers, const float* params, int n,
                    Surface out, float blurScale);

// Render one layer alone (blur + adjust, ignoring its visible flag) — "Bake into layer pixels".
int renderSingleLayer(const ConstSurface& layer, const float* lf, Surface out, float blurScale);

// ---- Bitmap operations (premultiplied in/out) ------------------------------
int resizeSurface(const ConstSurface& src, Surface dst);
int rotate90(const ConstSurface& src, Surface dst, bool clockwise);  // dst is src.h x src.w
int flipSurface(const ConstSurface& src, Surface dst, bool horizontal);
int cropSurface(const ConstSurface& src, Surface dst, int x, int y);  // dst size = crop size

// ---- Mask / stroke helpers (use the alpha channel) -------------------------
// Selection invert: a>8 -> transparent, else opaque white. Returns true if anything is selected.
bool invertMask(Surface m);
// Bounding box of pixels with alpha > thr. box = {x,y,w,h}. Returns false if none.
bool alphaBounds(const ConstSurface& s, int thr, int* box);
// dst *= mask.alpha  (canvas 'destination-in'); sizes must match.
int destinationIn(Surface dst, const ConstSurface& mask);
// dst *= (1 - src.alpha)  (canvas 'destination-out'); sizes must match.
int destinationOut(Surface dst, const ConstSurface& src);
// dst = src OVER dst (premultiplied), sizes must match.
int sourceOver(Surface dst, const ConstSurface& src);
// Fill color (premultiplied by alpha) wherever mask alpha > 0: out = color * mask.alpha
int tintMask(Surface dst, const ConstSurface& mask, uint8_t r, uint8_t g, uint8_t b, uint8_t aScale);

// ---- Effect brush ----------------------------------------------------------
enum EffectKey {
  FX_TEMPERATURE = 0,
  FX_EXPOSURE,
  FX_BRIGHTNESS,
  FX_CONTRAST,
  FX_SATURATION,
  FX_HUE,
  FX_INVERT,
  FX_POSTERIZE,
  FX_GRAIN,
  FX_VIGNETTE,
  FX_PIXELATE,
  FX_BLUR,
  FX_NONE
};
// Filter region (x0,y0,bw,bh) of snapshot `snap` (WxH, premultiplied) into `out` (bw x bh premultiplied).
// `p` is the shader-space value, exactly as PARAM_DEFS.toShader produced it.
int effectRegion(const ConstSurface& snap, int x0, int y0, int bw, int bh, int key, float p,
                 Surface out);

// Library self-test hook (returns 0 when the engine's internal sanity checks pass).
int selfTest();

}  // namespace zeta
