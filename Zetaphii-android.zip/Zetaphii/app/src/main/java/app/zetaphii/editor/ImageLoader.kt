package app.zetaphii.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri

/** Decodes picked images with a bounded size (keeps 4 GB phones healthy) and applies EXIF orientation. */
object ImageLoader {
    /** Longest side kept when importing; larger photos are decoded with a power-of-two subsample. */
    const val MAX_IMPORT_SIDE = 4096

    fun decode(ctx: Context, uri: Uri): Bitmap? {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (Math.max(bounds.outWidth, bounds.outHeight) / sample > MAX_IMPORT_SIDE) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888
            var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            var orientation = ExifInterface.ORIENTATION_NORMAL
            try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    orientation = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (t: Throwable) {
            }
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            }
            if (!m.isIdentity) {
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated !== bmp) bmp = rotated
            }
            if (bmp.config != Bitmap.Config.ARGB_8888 || !bmp.isPremultiplied) {
                bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
            }
            return bmp
        } catch (t: Throwable) {
            return null
        }
    }
}
