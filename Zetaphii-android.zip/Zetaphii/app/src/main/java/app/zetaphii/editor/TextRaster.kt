package app.zetaphii.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import app.zetaphii.model.TextProps

/** Port of measureAndDrawText / rasterizeTextProps (16-import.ts). Output is a full-canvas-size bitmap. */
object TextRaster {
    /** Optional bundled fonts (assets/fonts/<name>.ttf). Falls back to system fonts when absent. */
    var fontLoader: ((String, Boolean, Boolean) -> Typeface?)? = null

    val families: List<String> = listOf("Space Grotesk", "News Cycle", "Changa One", "sans-serif", "serif", "monospace")

    fun parseColor(css: String?, fallback: Int = Color.WHITE): Int {
        return try {
            Color.parseColor(css ?: "#ffffff")
        } catch (t: Throwable) {
            fallback
        }
    }

    fun typeface(family: String, weight: String, style: String): Typeface {
        val bold = (weight.toIntOrNull() ?: 400) >= 600 || weight == "bold"
        val italic = style == "italic"
        val custom = fontLoader?.invoke(family, bold, italic)
        if (custom != null) return custom
        val base = when (family) {
            "serif" -> Typeface.SERIF
            "monospace" -> Typeface.MONOSPACE
            else -> Typeface.SANS_SERIF
        }
        val st = if (bold && italic) Typeface.BOLD_ITALIC else if (bold) Typeface.BOLD else if (italic) Typeface.ITALIC else Typeface.NORMAL
        return Typeface.create(base, st)
    }

    fun draw(canvas: Canvas, props: TextProps, canvasW: Int, canvasH: Int) {
        val lines = (if (props.content.isEmpty()) "Text" else props.content).split("\n")
        val size = Math.max(8.0, if (props.fontSize != 0.0) props.fontSize else 72.0).toFloat()
        val sx = if (props.scaleX != 0.0) props.scaleX.toFloat() else 1f
        val sy = if (props.scaleY != 0.0) props.scaleY.toFloat() else 1f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = typeface(props.fontFamily, props.fontWeight, props.fontStyle)
        p.textSize = size
        p.color = parseColor(props.color)
        p.textAlign = when (props.align) {
            "left" -> Paint.Align.LEFT
            "right" -> Paint.Align.RIGHT
            else -> Paint.Align.CENTER
        }
        canvas.save()
        canvas.translate(canvasW / 2f + props.offsetX.toFloat(), canvasH / 2f + props.offsetY.toFloat())
        canvas.rotate(props.rotation.toFloat())
        canvas.scale(sx, sy)
        val lineHeight = size * 1.25f
        val totalH = lines.size * lineHeight
        val startY = -totalH / 2f + lineHeight / 2f
        var x = 0f
        if (props.align == "left") x = -Math.min(canvasW * 0.35f, size * 6f)
        else if (props.align == "right") x = Math.min(canvasW * 0.35f, size * 6f)
        // Canvas textBaseline='middle' ~ centre of the em box; Android draws on the alphabetic baseline.
        val fm = p.fontMetrics
        val midOffset = -(fm.ascent + fm.descent) / 2f
        for (i in lines.indices) canvas.drawText(lines[i], x, startY + i * lineHeight + midOffset, p)
        canvas.restore()
    }

    fun rasterize(props: TextProps, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), props, w, h)
        return bmp
    }
}
