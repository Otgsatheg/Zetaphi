package app.zetaphii

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.graphics.Typeface
import app.zetaphii.editor.EditorCore
import app.zetaphii.editor.ImageStore
import app.zetaphii.editor.NativeEngine
import app.zetaphii.editor.TextRaster
import app.zetaphii.storage.ProjectStore
import app.zetaphii.storage.SettingsStore
import app.zetaphii.ui.Theme
import app.zetaphii.ui.uiTypeface
import java.io.File

/** Process-wide singletons: the editor state survives Activity recreation. */
class ZetaApp : Application() {
    lateinit var settingsStore: SettingsStore
    lateinit var projects: ProjectStore
    lateinit var core: EditorCore
    var nativeOk: Boolean = false

    override fun onCreate() {
        super.onCreate()
        nativeOk = NativeEngine.ensureLoaded()
        settingsStore = SettingsStore(this)
        val settings = settingsStore.load()
        Theme.id = settings.theme
        projects = ProjectStore(this)
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val budgetMb = if (am.isLowRamDevice) 96 else (am.memoryClass * 0.6).toInt().coerceIn(96, 320)
        val store = ImageStore(File(cacheDir, "spill"), budgetMb * 1024L * 1024L)
        core = EditorCore(store, projects, settings)
        installFonts()
    }

    /** Uses bundled fonts from assets/fonts when present (see README), otherwise system fonts. */
    private fun installFonts() {
        fun load(file: String): Typeface? = try { Typeface.createFromAsset(assets, "fonts/$file") } catch (t: Throwable) { null }
        val grotesk = load("SpaceGrotesk-Regular.ttf")
        val groteskBold = load("SpaceGrotesk-Bold.ttf")
        uiTypeface = grotesk
        TextRaster.fontLoader = { family, bold, _ ->
            when (family) {
                "Space Grotesk" -> if (bold) groteskBold ?: grotesk else grotesk
                "News Cycle" -> if (bold) load("NewsCycle-Bold.ttf") ?: load("NewsCycle-Regular.ttf") else load("NewsCycle-Regular.ttf")
                "Changa One" -> load("ChangaOne-Regular.ttf")
                else -> null
            }
        }
    }
}
