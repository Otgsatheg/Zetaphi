package app.zetaphii.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path

class PatternPreset(val id: String, val name: String)

/** Preset pattern tiles — port of buildPresetTile (30-patterns-fills.ts), 96 px tiles. */
object Patterns {
    const val TILE = 96

    val presets: List<PatternPreset> = listOf(
        PatternPreset("dots", "Dots"), PatternPreset("grid", "Grid"), PatternPreset("diagonal", "Stripes"),
        PatternPreset("checker", "Checker"), PatternPreset("crosshatch", "Hatch"), PatternPreset("zigzag", "Zigzag"),
        PatternPreset("waves", "Waves"), PatternPreset("triangles", "Triangles"), PatternPreset("noise", "Noise"),
        PatternPreset("stars", "Stars")
    )

    /** FNV-1a string hash with 32-bit wraparound (hashStr in the original). */
    fun hashStr(s: String): Int {
        var h = 0x811C9DC5.toInt()
        for (ch in s) h = (h xor ch.code) * 16777619
        return h
    }

    /** mulberry32 (makeRng in the original) — identical sequence for identical seeds. */
    class Rng(seed: Int) {
        private var s: Int = seed
        fun next(): Double {
            s += 0x6D2B79F5
            var t = s
            t = (t xor (t ushr 15)) * (t or 1)
            t = t xor (t + (t xor (t ushr 7)) * (t or 61))
            val r = (t xor (t ushr 14)).toLong() and 0xFFFFFFFFL
            return r.toDouble() / 4294967296.0
        }
    }

    fun buildTile(id: String, color: Int): Bitmap {
        val S = TILE.toFloat()
        val bmp = Bitmap.createBitmap(TILE, TILE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        stroke.color = color
        stroke.style = Paint.Style.STROKE
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.color = color
        fill.style = Paint.Style.FILL
        val rnd = Rng(0x51ED2700 xor hashStr(id))
        when (id) {
            "dots" -> {
                val r = S * 0.11f
                c.drawCircle(S * 0.25f, S * 0.25f, r, fill)
                c.drawCircle(S * 0.75f, S * 0.75f, r, fill)
            }
            "grid" -> {
                stroke.strokeWidth = 2f
                c.drawRect(1f, 1f, S - 1f, S - 1f, stroke)
            }
            "diagonal" -> {
                stroke.strokeWidth = S * 0.12f
                for (k in -2..4) {
                    val c0 = k * S / 2f
                    c.drawLine(c0, -10f, c0 - S - 10f, S + 10f, stroke)
                }
            }
            "checker" -> {
                val h2 = S / 2f
                c.drawRect(0f, 0f, h2, h2, fill)
                c.drawRect(h2, h2, S, S, fill)
            }
            "crosshatch" -> {
                stroke.strokeWidth = 1.6f
                for (k in -2..5) {
                    c.drawLine(k * S / 2f, -10f, k * S / 2f - S - 10f, S + 10f, stroke)
                    c.drawLine(k * S / 2f, -10f, k * S / 2f + S + 10f, S + 10f, stroke)
                }
            }
            "zigzag" -> {
                stroke.strokeWidth = S * 0.08f
                stroke.strokeJoin = Paint.Join.MITER
                val rows = 2
                val seg = S / 4f
                for (r in 0 until rows) {
                    val y0 = (r + 0.5f) * S / rows
                    val p = Path()
                    p.moveTo(-2f, y0)
                    for (x in 0..4) p.lineTo(x * seg, y0 + (if (x % 2 == 0) -S / rows * 0.35f else S / rows * 0.35f))
                    p.lineTo(S + 2f, y0)
                    c.drawPath(p, stroke)
                }
            }
            "waves" -> {
                stroke.strokeWidth = S * 0.09f
                val rows = 2
                for (r in 0 until rows) {
                    val y1 = (r + 0.5f) * S / rows
                    val p = Path()
                    var x = 0
                    while (x <= TILE) {
                        val yy = y1 + (Math.sin((x / S) * Math.PI * 2) * (S / rows * 0.3f)).toFloat()
                        if (x == 0) p.moveTo(0f, yy) else p.lineTo(x.toFloat(), yy)
                        x += 2
                    }
                    c.drawPath(p, stroke)
                }
            }
            "triangles" -> {
                val n = 2
                val t = S / n
                for (row in 0 until n) for (col in 0 until n) {
                    val x = col * t
                    val y = row * t
                    val p = Path()
                    if ((row + col) % 2 == 0) {
                        p.moveTo(x, y); p.lineTo(x + t, y); p.lineTo(x, y + t)
                    } else {
                        p.moveTo(x + t, y); p.lineTo(x + t, y + t); p.lineTo(x, y + t)
                    }
                    p.close()
                    c.drawPath(p, fill)
                }
            }
            "noise" -> {
                val baseAlpha = android.graphics.Color.alpha(color)
                for (i in 0 until 900) {
                    val a = 0.15 + rnd.next() * 0.75
                    fill.alpha = (baseAlpha * a).toInt().coerceIn(0, 255)
                    val s5 = (0.6 + rnd.next() * 1.6).toFloat()
                    val x = (rnd.next() * S).toFloat()
                    val y = (rnd.next() * S).toFloat()
                    c.drawRect(x, y, x + s5, y + s5, fill)
                }
            }
            "stars" -> {
                fun star(cx: Float, cy: Float, r: Float) {
                    val p = Path()
                    p.moveTo(cx, cy - r)
                    p.quadTo(cx, cy, cx + r, cy)
                    p.quadTo(cx, cy, cx, cy + r)
                    p.quadTo(cx, cy, cx - r, cy)
                    p.quadTo(cx, cy, cx, cy - r)
                    c.drawPath(p, fill)
                }
                star(S * 0.5f, S * 0.5f, S * 0.3f)
                star(0f, 0f, S * 0.14f); star(S, 0f, S * 0.14f); star(0f, S, S * 0.14f); star(S, S, S * 0.14f)
            }
        }
        return bmp
    }
}
