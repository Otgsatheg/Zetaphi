package app.zetaphii.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Blend modes — identical order/ids to BLEND_MODES in the original config. */
object BlendModes {
    val names: List<String> = listOf(
        "Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light", "Color Burn",
        "Linear Burn", "Color Dodge", "Linear Dodge (Add)", "Difference", "Exclusion",
        "Hard Mix", "Divide", "Subtract", "Hue", "Saturation", "Color", "Luminosity"
    )
}

/** One adjustment slider (PARAM_DEFS). [toShader] maps UI units to the value the native engine uses. */
class ParamDef(
    val key: String,
    val label: String,
    val min: Int,
    val max: Int,
    val def: Int,
    val toShader: (Double) -> Double
)

object Params {
    private fun lin(v: Double, scale: Double): Double = (v / 100.0) * scale

    val defs: List<ParamDef> = listOf(
        ParamDef("brightness", "Brightness", -100, 100, 0) { lin(it, 0.5) },
        ParamDef("contrast", "Contrast", -100, 100, 0) { 1.0 + lin(it, 1.0) },
        ParamDef("saturation", "Saturation", -100, 100, 0) { 1.0 + lin(it, 1.0) },
        ParamDef("vibrance", "Vibrance", -100, 100, 0) { lin(it, 1.0) },
        ParamDef("exposure", "Exposure", -100, 100, 0) { lin(it, 5.0) },
        ParamDef("highlights", "Highlights", -100, 100, 0) { lin(it, 1.0) },
        ParamDef("shadows", "Shadows", -100, 100, 0) { lin(it, 1.0) },
        ParamDef("temperature", "Temperature", -100, 100, 0) { lin(it, 0.5) },
        ParamDef("tint", "Tint", -100, 100, 0) { lin(it, 0.5) },
        ParamDef("sharpness", "Sharpness", 0, 100, 0) { lin(it, 1.0) },
        ParamDef("blur", "Blur", 0, 100, 0) { lin(it, 40.0) },
        ParamDef("opacity", "Opacity", 0, 100, 100) { Math.min(1.0, Math.max(0.0, it / 100.0)) },
        ParamDef("posterize", "Posterize", 0, 100, 0) { v ->
            if (v <= 0.0) 0.0 else (2 + Math.round((v - 1) * 30 / 99)).toDouble()
        },
        ParamDef("pixelate", "Pixelate", 0, 100, 0) { v ->
            if (v <= 0.0) 0.0 else Math.round(254 - (v - 1) * 246 / 99).toDouble()
        },
        ParamDef("grain", "Grain", 0, 100, 0) { lin(it, 0.35) },
        ParamDef("vignette", "Vignette", 0, 100, 0) { lin(it, 0.9) },
        ParamDef("invert", "Invert", 0, 100, 0) { lin(it, 1.0) },
        ParamDef("hue", "Hue", -100, 100, 0) { lin(it, 180.0) }
    )
    val byKey: Map<String, ParamDef> = defs.associateBy { it.key }

    fun defaults(): MutableMap<String, Double> {
        val m = LinkedHashMap<String, Double>()
        for (d in defs) m[d.key] = d.def.toDouble()
        return m
    }
}

enum class LayerKind(val id: String) {
    RASTER("raster"), TEXT("text"), MASK("mask");

    companion object {
        fun from(s: String?): LayerKind = values().firstOrNull { it.id == s } ?: RASTER
    }
}

class TextProps(
    var content: String = "Text",
    var fontFamily: String = "Space Grotesk",
    var fontSize: Double = 72.0,
    var fontWeight: String = "700",
    var fontStyle: String = "normal",
    var color: String = "#ffffff",
    var align: String = "center",
    var rotation: Double = 0.0,
    var offsetX: Double = 0.0,
    var offsetY: Double = 0.0,
    var scaleX: Double = 1.0,
    var scaleY: Double = 1.0
) {
    fun copy(): TextProps = TextProps(
        content, fontFamily, fontSize, fontWeight, fontStyle, color, align,
        rotation, offsetX, offsetY, scaleX, scaleY
    )

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("content", content); o.put("fontFamily", fontFamily); o.put("fontSize", fontSize)
        o.put("fontWeight", fontWeight); o.put("fontStyle", fontStyle); o.put("color", color)
        o.put("align", align); o.put("rotation", rotation); o.put("offsetX", offsetX)
        o.put("offsetY", offsetY); o.put("scaleX", scaleX); o.put("scaleY", scaleY)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): TextProps = TextProps(
            o.optString("content", "Text"), o.optString("fontFamily", "Space Grotesk"),
            o.optDouble("fontSize", 72.0), o.optString("fontWeight", "700"),
            o.optString("fontStyle", "normal"), o.optString("color", "#ffffff"),
            o.optString("align", "center"), o.optDouble("rotation", 0.0),
            o.optDouble("offsetX", 0.0), o.optDouble("offsetY", 0.0),
            o.optDouble("scaleX", 1.0), o.optDouble("scaleY", 1.0)
        )
    }
}

fun newId(): String = "id" + UUID.randomUUID().toString().replace("-", "").substring(0, 12)

/** A layer. Pixels live in ImageStore under [imageId]; every edit creates a new immutable imageId. */
class Layer(var id: String, var imageId: String, var name: String) {
    var kind: LayerKind = LayerKind.RASTER
    var textProps: TextProps? = null
    var blendMode: Int = 0
    var visible: Boolean = true
    var params: MutableMap<String, Double> = Params.defaults()

    fun param(key: String): Double {
        val v = params[key]
        if (v != null) return v
        val d = Params.byKey[key]
        return if (d != null) d.def.toDouble() else 0.0
    }

    fun toSnapshot(): LayerSnapshot = LayerSnapshot(
        id, imageId, name, kind, textProps?.copy(), blendMode, visible, LinkedHashMap(params)
    )

    companion object {
        fun fromSnapshot(s: LayerSnapshot): Layer {
            val l = Layer(s.id, s.imageId, s.name)
            l.kind = s.kind
            l.textProps = s.textProps?.copy()
            l.blendMode = s.blendMode
            l.visible = s.visible
            l.params = Params.defaults()
            for ((k, v) in s.params) l.params[k] = v
            return l
        }
    }
}

class LayerSnapshot(
    val id: String,
    val imageId: String,
    val name: String,
    val kind: LayerKind,
    val textProps: TextProps?,
    val blendMode: Int,
    val visible: Boolean,
    val params: Map<String, Double>
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("imageId", imageId); o.put("name", name); o.put("kind", kind.id)
        o.put("textProps", textProps?.toJson() ?: JSONObject.NULL)
        o.put("blendMode", blendMode); o.put("visible", visible)
        val p = JSONObject()
        for ((k, v) in params) p.put(k, v)
        o.put("params", p)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): LayerSnapshot {
            val params = LinkedHashMap<String, Double>()
            val po = o.optJSONObject("params")
            if (po != null) {
                val keys = po.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    params[k] = po.optDouble(k, 0.0)
                }
            }
            val tp = o.optJSONObject("textProps")
            return LayerSnapshot(
                o.getString("id"), o.getString("imageId"), o.optString("name", "Layer"),
                LayerKind.from(o.optString("kind", "raster")),
                if (tp != null) TextProps.fromJson(tp) else null,
                o.optInt("blendMode", 0), o.optBoolean("visible", true), params
            )
        }
    }
}

class ManagerSnapshot(val selectedId: String?, val layers: List<LayerSnapshot>) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("selectedId", selectedId ?: JSONObject.NULL)
        val arr = JSONArray()
        for (l in layers) arr.put(l.toJson())
        o.put("layers", arr)
        return o
    }

    fun imageIds(): List<String> = layers.map { it.imageId }.distinct()

    companion object {
        fun fromJson(o: JSONObject): ManagerSnapshot {
            val arr = o.optJSONArray("layers") ?: JSONArray()
            val ls = ArrayList<LayerSnapshot>()
            for (i in 0 until arr.length()) ls.add(LayerSnapshot.fromJson(arr.getJSONObject(i)))
            val sel = if (o.isNull("selectedId")) null else o.optString("selectedId")
            return ManagerSnapshot(sel, ls)
        }
    }
}

/** Stored project metadata (ProjectRecord in the original; the snapshot schema is unchanged). */
class ProjectRecord(
    val id: String,
    var name: String,
    var updatedAt: Long,
    var createdAt: Long,
    var snapshot: ManagerSnapshot,
    var imageIds: List<String>
)

class AppSettings(
    var theme: String = "dark",
    var thumbSize: Int = 96,
    var thumbQuality: Double = 0.85,
    var autosaveMs: Int = 1500,
    var historySteps: Int = 60,
    var defaultCanvasW: Int = 1080,
    var defaultCanvasH: Int = 1080,
    var brushSize: Int = 12,
    var brushOpacity: Int = 100
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("theme", theme); o.put("thumbSize", thumbSize); o.put("thumbQuality", thumbQuality)
        o.put("autosaveMs", autosaveMs); o.put("historySteps", historySteps)
        o.put("defaultCanvasW", defaultCanvasW); o.put("defaultCanvasH", defaultCanvasH)
        o.put("brushSize", brushSize); o.put("brushOpacity", brushOpacity)
        return o
    }

    fun load(o: JSONObject) {
        if (o.has("theme")) theme = o.optString("theme", theme)
        thumbSize = positive(o.optInt("thumbSize", thumbSize), 96)
        thumbQuality = if (o.optDouble("thumbQuality", thumbQuality) > 0.0) o.optDouble("thumbQuality", thumbQuality) else 0.85
        autosaveMs = positive(o.optInt("autosaveMs", autosaveMs), 1500)
        historySteps = positive(o.optInt("historySteps", historySteps), 60)
        defaultCanvasW = positive(o.optInt("defaultCanvasW", defaultCanvasW), 1080)
        defaultCanvasH = positive(o.optInt("defaultCanvasH", defaultCanvasH), 1080)
        brushSize = positive(o.optInt("brushSize", brushSize), 12)
        brushOpacity = positive(o.optInt("brushOpacity", brushOpacity), 100)
    }

    private fun positive(v: Int, fallback: Int): Int = if (v > 0) v else fallback
}
