package app.zetaphii.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import app.zetaphii.storage.ProjectMeta
import app.zetaphii.storage.ProjectStore
import app.zetaphii.storage.SettingsStore
import app.zetaphii.model.AppSettings
import java.text.DateFormat
import java.util.Date

interface ProjectsHost {
    fun openProject(id: String)
    fun newProject()
    fun rebuildUi()
}

/** Projects page: Zetaphii header, Help / New / Settings, project cards (open, long-press for rename/delete). */
class ProjectsScreen(
    private val ctx: Context,
    private val projects: ProjectStore,
    private val settings: AppSettings,
    private val settingsStore: SettingsStore,
    private val host: ProjectsHost
) {
    val root = FrameLayout(ctx)
    private val list = ctx.vbox()

    init {
        root.setBackgroundColor(Theme.bg)
        val col = ctx.vbox()
        val header = ctx.hbox()
        header.setPadding(ctx.dp(18), ctx.dp(26), ctx.dp(12), ctx.dp(10))
        val title = ctx.label("Zetaphii", 28f, Theme.text, true)
        header.addView(title, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(ctx.iconButton("help") { showHelp() })
        header.addView(ctx.iconButton("settings") { showSettings() })
        col.addView(header)
        val actions = ctx.hbox()
        actions.setPadding(ctx.dp(18), 0, ctx.dp(18), ctx.dp(8))
        actions.addView(ctx.button("New", true) { host.newProject() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(actions)
        val sv = ScrollView(ctx)
        list.setPadding(ctx.dp(18), ctx.dp(8), ctx.dp(18), ctx.dp(24))
        sv.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(sv, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        refresh()
    }

    fun refresh() {
        list.removeAllViews()
        val items = projects.list()
        if (items.isEmpty()) {
            list.addView(ctx.label("No projects yet — tap New to start.", 14f, Theme.textDim))
            return
        }
        val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        for (m in items) list.addView(card(m, fmt))
    }

    private fun card(m: ProjectMeta, fmt: DateFormat): LinearLayout {
        val row = ctx.hbox()
        row.setPadding(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
        row.background = withRipple(ctx, rounded(Theme.surface2, ctx.dpf(16f), Theme.border, ctx.dp(1)))
        val iv = ImageView(ctx)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = rounded(Theme.surface3, ctx.dpf(10f))
        iv.clipToOutline = true
        val th = m.thumb
        if (th != null) {
            try { iv.setImageBitmap(BitmapFactory.decodeFile(th.absolutePath)) } catch (t: Throwable) {}
        }
        row.addView(iv, LinearLayout.LayoutParams(ctx.dp(64), ctx.dp(64)))
        val info = ctx.vbox()
        info.setPadding(ctx.dp(12), 0, 0, 0)
        info.addView(ctx.label(m.name, 16f, Theme.text, true))
        info.addView(ctx.label(fmt.format(Date(m.updatedAt)), 12f, Theme.textDim))
        row.addView(info, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener { host.openProject(m.id) }
        row.setOnLongClickListener { manage(m); true }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.bottomMargin = ctx.dp(10)
        row.layoutParams = p
        return row
    }

    private fun manage(m: ProjectMeta) {
        val sh = Sheet(ctx, m.name)
        sh.add(ctx.button("Rename") { sh.dismiss(); rename(m) })
        sh.add(ctx.button("Delete", danger = true) { sh.dismiss(); projects.delete(m.id); refresh() })
        sh.add(ctx.button("Cancel") { sh.dismiss() })
        sh.show()
    }

    private fun rename(m: ProjectMeta) {
        val sh = Sheet(ctx, "Rename project")
        val f = ctx.textField(m.name)
        sh.add(f)
        sh.add(ctx.button("Done", true) {
            val n = f.text.toString().trim()
            if (n.isNotEmpty()) { projects.rename(m.id, n); refresh() }
            sh.dismiss()
        })
        sh.show()
    }

    private fun showSettings() {
        val sh = Sheet(ctx, "Settings")
        sh.add(ctx.label("Theme", 13f, Theme.textDim))
        val ids = listOf("dark", "light", "oled")
        sh.add(Segmented(ctx, listOf("Dark", "Light", "OLED"), ids.indexOf(settings.theme).coerceAtLeast(0)) { i ->
            settings.theme = ids[i]; Theme.id = ids[i]; settingsStore.save(settings); sh.dismiss(); host.rebuildUi()
        }, 4)
        sh.add(ctx.button("Delete all projects", danger = true) {
            for (m in projects.list()) projects.delete(m.id)
            sh.dismiss(); refresh()
        }, 18)
        sh.add(ctx.button("Done") { sh.dismiss() })
        sh.show()
    }

    private fun showHelp() {
        val sh = Sheet(ctx, "Help")
        fun h(t: String) = sh.add(ctx.label(t, 13f, Theme.textDim, true), 14)
        fun b(t: String) = sh.add(ctx.label(t, 14f, Theme.text), 4)
        h("Touch gestures")
        b("Pinch — zoom the canvas")
        b("Two fingers — pan and rotate the view")
        b("One finger — draw (Draw tab) or pan")
        b("Double-tap — reset the view")
        h("Keyboard")
        b("Ctrl+Z undo · Ctrl+Shift+Z / Ctrl+Y redo")
        h("Bringing images in")
        b("Choose Photo / + Add Image, or share an image to Zetaphii from another app.")
        sh.add(ctx.button("Done") { sh.dismiss() }, 18)
        sh.show()
    }
}

/** Splash shown briefly at launch (brand title on the dark chrome). */
fun splashView(ctx: Context): FrameLayout {
    val f = FrameLayout(ctx)
    f.setBackgroundColor(Color.BLACK)
    val t = ctx.label("Zetaphii", 36f, Color.WHITE, true)
    t.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    f.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    return f
}
