package app.zetaphii.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import app.zetaphii.editor.BrushEngine
import app.zetaphii.editor.EditorCore
import app.zetaphii.editor.EditorListener
import app.zetaphii.editor.LassoEngine
import app.zetaphii.editor.Patterns
import app.zetaphii.editor.TextRaster
import app.zetaphii.model.AppSettings
import app.zetaphii.model.BlendModes
import app.zetaphii.model.LayerKind
import app.zetaphii.model.Params
import app.zetaphii.storage.ImageCodec
import app.zetaphii.storage.ProjectStore
import app.zetaphii.storage.SettingsStore
import java.io.OutputStream

/** Services the editor needs from the hosting activity. */
interface EditorHost {
    fun pickImage()
    fun saveFile(suggestedName: String, mime: String, write: (OutputStream) -> Unit)
    fun goHome()
    fun rebuildUi()
}

class EditorScreen(
    private val ctx: Context,
    private val core: EditorCore,
    private val settingsStore: SettingsStore,
    private val projects: ProjectStore,
    private val host: EditorHost
) : EditorListener {

    val root: LinearLayout = ctx.vbox()
    private val brush = BrushEngine(core)
    private val lasso = LassoEngine(core)
    val canvas = CanvasView(ctx, core, brush, lasso)
    private val settings: AppSettings = core.settings
    private val ui = Handler(Looper.getMainLooper())

    private val projectLabel = ctx.label("Untitled", 16f, Theme.text, true)
    private val saveDot = View(ctx)
    private lateinit var undoBtn: FrameLayout
    private lateinit var redoBtn: FrameLayout
    private val panelHost = FrameLayout(ctx)
    private val railItems = LinkedHashMap<String, LinearLayout>()
    private val emptyState = ctx.vbox()
    private val busyOverlay = FrameLayout(ctx)
    private val toastView = ctx.label("", 14f, Color.WHITE, true)
    private val placeBar = ctx.vbox()
    private var currentTab: String? = null
    private var editSub = "adjust"
    private var selectedParam = "brightness"
    private var toastHide: Runnable? = null
    private var layersPanel: LinearLayout? = null

    // draw settings kept across panel rebuilds
    private var drawTool = "brush"
    private var lassoMode = "freehand"

    // elements state
    private var patternId: String? = null
    private var patternColor = Theme.accent
    private var fillScale = 100
    private var fillOpacity = 100
    private var gradC1 = Theme.accent
    private var gradC2 = Theme.accentWarm
    private var gradRadial = false
    private var gradAngle = 90

    init {
        core.listeners.add(this)
        brush.size = settings.brushSize
        brush.opacity = settings.brushOpacity / 100.0
        canvas.brushSizePx = settings.brushSize
        buildLayout()
        selectTab(null)
        refreshAll()
    }

    fun release() {
        core.listeners.remove(this)
        canvas.detach()
        brush.release()
    }

    // ------------------------------------------------------------------ layout ---
    private fun buildLayout() {
        root.setBackgroundColor(Theme.bg)
        // top bar
        val top = ctx.hbox()
        top.setBackgroundColor(Theme.chrome)
        top.setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(10), ctx.dp(6))
        top.addView(ctx.iconButton("back") { core.saveNow(); host.goHome() })
        projectLabel.setOnClickListener { renameProject() }
        top.addView(projectLabel, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        saveDot.layoutParams = LinearLayout.LayoutParams(ctx.dp(8), ctx.dp(8)).also { it.rightMargin = ctx.dp(8) }
        top.addView(saveDot)
        undoBtn = ctx.iconButton("undo") { core.undo() }
        redoBtn = ctx.iconButton("redo") { core.redo() }
        top.addView(undoBtn)
        top.addView(redoBtn)
        root.addView(top, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // stage
        val stage = FrameLayout(ctx)
        stage.addView(canvas, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildEmptyState()
        stage.addView(emptyState, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildPlaceBar()
        stage.addView(placeBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        val zoomReset = ctx.button("Reset") { canvas.resetView() }
        stage.addView(zoomReset, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).also { it.setMargins(0, ctx.dp(8), ctx.dp(8), 0) })
        toastView.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
        toastView.background = rounded(Theme.toast, ctx.dpf(14f), Theme.borderStrong, ctx.dp(1))
        toastView.visibility = View.GONE
        stage.addView(toastView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = ctx.dp(16) })
        busyOverlay.setBackgroundColor(Theme.veil)
        busyOverlay.visibility = View.GONE
        busyOverlay.isClickable = true
        busyOverlay.addView(ProgressBar(ctx), FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        stage.addView(busyOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(stage, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // drawer panel + tool rail
        panelHost.setBackgroundColor(Theme.chrome)
        root.addView(panelHost, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val rail = ctx.hbox()
        rail.setBackgroundColor(Theme.chrome)
        val tabs = listOf(Triple("draw", "Draw", "draw"), Triple("edit", "Edit", "adjust"), Triple("layers", "Layers", "layers"),
            Triple("elements", "Elements", "elements"), Triple("settings", "Settings", "settings"))
        for (t in tabs) {
            val item = ctx.vbox()
            item.gravity = Gravity.CENTER
            item.setPadding(0, ctx.dp(8), 0, ctx.dp(8))
            item.background = withRipple(ctx, rounded(Color.TRANSPARENT, 0f))
            val iv = ctx.iconView(t.third, 22, Theme.textDim)
            iv.tag = "icon"
            item.addView(iv, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)).also { it.gravity = Gravity.CENTER_HORIZONTAL })
            val tv = ctx.label(t.second, 11f, Theme.textDim, true)
            tv.tag = "text"
            tv.gravity = Gravity.CENTER
            item.addView(tv)
            item.setOnClickListener { selectTab(if (currentTab == t.first) null else t.first) }
            railItems[t.first] = item
            rail.addView(item, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(rail, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun buildEmptyState() {
        emptyState.gravity = Gravity.CENTER
        emptyState.setBackgroundColor(Theme.bgSoft)
        emptyState.addView(ctx.label("Start creating", 22f, Theme.text, true))
        emptyState.addView(ctx.spacer(6))
        emptyState.addView(ctx.label("Open a blank canvas or import a photo.", 14f, Theme.textDim))
        emptyState.addView(ctx.spacer(18))
        val row = ctx.hbox()
        row.addView(ctx.button("Blank Canvas", true) { showCanvasSizeSheet() })
        row.addView(ctx.spacer(0), lp(ctx.dp(10), 1))
        row.addView(ctx.button("Choose Photo") { host.pickImage() })
        emptyState.addView(row)
    }

    private fun buildPlaceBar() {
        placeBar.setBackgroundColor(Theme.chrome)
        placeBar.setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
        placeBar.visibility = View.GONE
        placeBar.addView(ctx.label("Move · scale · rotate", 14f, Theme.textDim))
        val r1 = ctx.hbox()
        r1.addView(ctx.button("90° Left") { canvas.placeRotate(-90f) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r1.addView(ctx.button("90° Right") { canvas.placeRotate(90f) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r1.addView(ctx.button("Flip H") { canvas.placeFlipH() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r1.addView(ctx.button("Flip V") { canvas.placeFlipV() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        placeBar.addView(r1)
        val r2 = ctx.hbox()
        r2.addView(ctx.button("Cancel") { endPlace(false) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r2.addView(ctx.button("Place Image", true) { endPlace(true) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        placeBar.addView(r2)
    }

    // ------------------------------------------------------------- place mode ---
    fun onImagePicked(bmp: Bitmap) {
        // Place mode needs a canvas to place into: an empty project gets a temporary preview size only
        if (core.layers.isEmpty()) {
            val dim = Math.max(bmp.width, bmp.height).coerceIn(1080, 2048)
            core.createBlankCanvas(dim, dim, true)
        }
        selectTab(null)
        placeBar.visibility = View.VISIBLE
        canvas.startPlace(bmp)
    }

    private fun endPlace(confirm: Boolean) {
        val pl = canvas.place
        if (confirm && pl != null) {
            core.addPlacedImage(pl.bitmap, pl.cx, pl.cy, pl.scaleX, pl.scaleY, pl.rotation, pl.flipH, pl.flipV)
        }
        canvas.endPlace()
        placeBar.visibility = View.GONE
    }

    // -------------------------------------------------------------- tab logic ---
    private fun selectTab(tab: String?) {
        if (canvas.mode == CanvasView.Mode.CROP && tab != "edit") canvas.cancelCrop()
        currentTab = tab
        for ((k, v) in railItems) {
            val on = k == tab
            val col = if (on) Theme.accentStrong else Theme.textDim
            (v.findViewWithTag<ImageView>("icon"))?.imageTintList = android.content.res.ColorStateList.valueOf(col)
            (v.findViewWithTag<TextView>("text"))?.setTextColor(col)
        }
        canvas.mode = if (tab == "draw") CanvasView.Mode.DRAW
            else if (canvas.mode == CanvasView.Mode.CROP && tab == "edit") CanvasView.Mode.CROP
            else CanvasView.Mode.NAVIGATE
        canvas.drawTool = drawTool
        panelHost.removeAllViews()
        if (tab == null) { panelHost.visibility = View.GONE; return }
        panelHost.visibility = View.VISIBLE
        val content: View = when (tab) {
            "draw" -> drawPanel()
            "edit" -> editPanel()
            "layers" -> layersPanelView()
            "elements" -> elementsPanel()
            else -> settingsPanel()
        }
        val sv = ScrollView(ctx)
        content.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        sv.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val maxH = (ctx.resources.displayMetrics.heightPixels * 0.42f).toInt()
        panelHost.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sv.post {
            if (sv.height > maxH) { val p = sv.layoutParams; p.height = maxH; sv.layoutParams = p }
        }
    }

    private fun chips(items: List<Pair<String, String>>, selected: String?, onPick: (String) -> Unit): HorizontalScrollView {
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val row = ctx.hbox()
        for (item in items) {
            val on = item.first == selected
            val t = ctx.label(item.second, 13f, if (on) Color.WHITE else Theme.text, true)
            t.setPadding(ctx.dp(14), ctx.dp(9), ctx.dp(14), ctx.dp(9))
            t.background = rounded(if (on) Theme.accent else Theme.surface2, ctx.dpf(18f), Theme.border, ctx.dp(1))
            val key = item.first
            t.setOnClickListener { onPick(key) }
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.rightMargin = ctx.dp(8)
            row.addView(t, p)
        }
        hs.addView(row)
        return hs
    }

    private fun colorSwatch(initial: Int, onPick: (Int) -> Unit): View {
        val v = View(ctx)
        v.background = rounded(initial, ctx.dpf(10f), Theme.borderStrong, ctx.dp(1))
        v.layoutParams = LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(34))
        v.setOnClickListener { pickColor(ctx, (v.tag as? Int) ?: initial) { c -> v.tag = c; v.background = rounded(c, ctx.dpf(10f), Theme.borderStrong, ctx.dp(1)); onPick(c) } }
        v.tag = initial
        return v
    }

    private fun addRow(parent: LinearLayout, v: View, topDp: Int = 10) {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = ctx.dp(topDp)
        parent.addView(v, p)
    }

    // -------------------------------------------------------------- draw panel ---
    private fun drawPanel(): View {
        val p = ctx.vbox()
        addRow(p, Segmented(ctx, listOf("Brush", "Eraser", "Lasso"), listOf("brush", "eraser", "lasso").indexOf(drawTool)) { i ->
            drawTool = listOf("brush", "eraser", "lasso")[i]
            canvas.drawTool = drawTool
            if (drawTool != "lasso") lasso.cancel()
            selectTab("draw")
        }, 0)
        if (drawTool == "lasso") {
            addRow(p, Segmented(ctx, listOf("Brush", "Rect", "Ellipse", "Poly"), listOf("freehand", "rect", "ellipse", "poly").indexOf(lassoMode)) { i ->
                lassoMode = listOf("freehand", "rect", "ellipse", "poly")[i]
                lasso.cancel(); lasso.mode = lassoMode
            })
            lasso.mode = lassoMode
            val r = ctx.hbox()
            r.addView(ctx.button("Clear") { lasso.cancel(); core.clearSelection() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(ctx.button("Invert") { lasso.cancel(); core.invertSelection() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(ctx.button("Apply to Mask") { core.commitSelectionToMask() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addRow(p, r)
        } else {
            if (drawTool == "brush") {
                addRow(p, ctx.label("Brushes", 13f, Theme.textDim))
                addRow(p, chips(listOf(Pair("hard", "Hard"), Pair("soft", "Soft"), Pair("air", "Air")), if (brush.effectKey == null) brush.style else null) { id ->
                    brush.style = id; brush.effectKey = null; selectTab("draw")
                }, 4)
                addRow(p, ctx.label("Effect brushes", 13f, Theme.textDim))
                addRow(p, chips(BrushEngine.EFFECT_BRUSHES.map { Pair(it.key, it.name) }, brush.effectKey) { id ->
                    val def = BrushEngine.EFFECT_BRUSHES.first { it.key == id }
                    brush.effectKey = id; brush.effectStrength = def.def; selectTab("draw")
                }, 4)
                val ek = brush.effectKey
                if (ek != null) {
                    val def = BrushEngine.EFFECT_BRUSHES.first { it.key == ek }
                    addRow(p, SliderRow(ctx, "Strength", if (def.bidirectional) -100 else 0, 100, brush.effectStrength) { v, _ -> brush.effectStrength = v })
                }
                val colorRow = ctx.hbox()
                colorRow.addView(ctx.label("Color", 13f, Theme.textDim), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                colorRow.addView(colorSwatch(brush.color) { c -> brush.color = c })
                addRow(p, colorRow)
            }
            addRow(p, SliderRow(ctx, "Size", 1, 300, settings.brushSize) { v, c ->
                settings.brushSize = v; brush.size = v; canvas.brushSizePx = v
                if (c) settingsStore.save(settings)
            })
            addRow(p, SliderRow(ctx, "Opacity", 1, 100, settings.brushOpacity) { v, c ->
                settings.brushOpacity = v; brush.opacity = v / 100.0
                if (c) settingsStore.save(settings)
            })
        }
        val r = ctx.hbox()
        r.addView(ctx.button("Clear strokes") { brush.clear(); canvas.invalidate() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(ctx.button("+ Empty Layer") { addEmptyLayer() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addRow(p, r)
        return p
    }

    private fun addEmptyLayer() { core.addEmptyLayer() }

    // --------------------------------------------------------------- edit panel ---
    private fun editPanel(): View {
        val p = ctx.vbox()
        addRow(p, Segmented(ctx, listOf("Adjust", "Transform"), if (editSub == "adjust") 0 else 1) { i ->
            editSub = if (i == 0) "adjust" else "transform"; selectTab("edit")
        }, 0)
        val layer = core.selected()
        if (layer == null) { addRow(p, ctx.label("Select a layer first", 14f, Theme.textDim)); return p }
        if (editSub == "adjust") {
            addRow(p, chips(Params.defs.map { Pair(it.key, it.label) }, selectedParam) { k -> selectedParam = k; selectTab("edit") })
            val def = Params.byKey[selectedParam]!!
            val row = SliderRow(ctx, def.label, def.min, def.max, layer.param(selectedParam).toInt()) { v, committed ->
                core.setParam(layer.id, selectedParam, v.toDouble())
                if (committed) core.commitHistory()
            }
            addRow(p, row)
            val r = ctx.hbox()
            r.addView(ctx.button("Reset") { core.setParam(layer.id, selectedParam, def.def.toDouble()); row.set(def.def); core.commitHistory() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(ctx.button("Reset all") { core.resetParams(layer.id); selectTab("edit") }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addRow(p, r)
        } else {
            addRow(p, ctx.label("Rotate & Flip", 13f, Theme.textDim))
            val r1 = ctx.hbox()
            r1.addView(ctx.button("90° Left") { core.rotate90(false) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r1.addView(ctx.button("90° Right") { core.rotate90(true) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r1.addView(ctx.button("Flip H") { core.flip(true) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r1.addView(ctx.button("Flip V") { core.flip(false) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addRow(p, r1)
            addRow(p, ctx.label("Resize", 13f, Theme.textDim))
            val sz = core.store.size(layer.imageId) ?: intArrayOf(1, 1)
            val wF = ctx.textField(sz[0].toString(), numeric = true)
            val hF = ctx.textField(sz[1].toString(), numeric = true)
            var locked = true
            val lockBtn = ctx.iconButton("lock") { }
            var fromCode = false
            wF.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (fromCode || !locked) return
                    val w = s.toString().toIntOrNull() ?: return
                    fromCode = true; hF.setText(Math.max(1, Math.round(w.toDouble() * sz[1] / sz[0]).toInt()).toString()); fromCode = false
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            hF.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (fromCode || !locked) return
                    val h = s.toString().toIntOrNull() ?: return
                    fromCode = true; wF.setText(Math.max(1, Math.round(h.toDouble() * sz[0] / sz[1]).toInt()).toString()); fromCode = false
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            lockBtn.setOnClickListener {
                locked = !locked
                val iv = lockBtn.findViewWithTag<ImageView>("icon")
                iv?.setImageResource(ctx.iconRes(if (locked) "lock" else "unlock"))
            }
            val r2 = ctx.hbox()
            r2.addView(wF, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r2.addView(lockBtn)
            r2.addView(hF, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addRow(p, r2)
            addRow(p, ctx.button("Apply Resize") {
                val w = wF.text.toString().toIntOrNull() ?: 0
                val h = hF.text.toString().toIntOrNull() ?: 0
                core.resizeSelected(w, h)
            })
            addRow(p, ctx.label("Crop", 13f, Theme.textDim))
            if (canvas.mode == CanvasView.Mode.CROP) {
                val r3 = ctx.hbox()
                r3.addView(ctx.button("Cancel") { canvas.cancelCrop(); selectTab("edit") }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r3.addView(ctx.button("Apply Crop", true) {
                    val r = canvas.cropResult()
                    canvas.cancelCrop()
                    if (r != null) core.cropSelected(r[0], r[1], r[2], r[3])
                    selectTab("edit")
                }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addRow(p, r3)
            } else {
                addRow(p, ctx.button("Crop Image") {
                    val s = core.store.size(layer.imageId)
                    if (s != null) { canvas.startCrop(s[0], s[1]); selectTab("edit") }
                })
            }
        }
        return p
    }

    // ------------------------------------------------------------- layers panel ---
    private fun layersPanelView(): View {
        val p = ctx.vbox()
        layersPanel = p
        rebuildLayerRows()
        return p
    }

    private fun rebuildLayerRows() {
        val p = layersPanel ?: return
        p.removeAllViews()
        if (core.layers.isEmpty()) { p.addView(ctx.label("No layers yet", 14f, Theme.textDim)); return }
        for (l in core.layers.reversed()) {
            val sel = l.id == core.selectedId
            val row = ctx.hbox()
            row.setPadding(ctx.dp(8), ctx.dp(6), ctx.dp(8), ctx.dp(6))
            row.background = rounded(if (sel) Theme.surface3 else Theme.surface2, ctx.dpf(12f), if (sel) Theme.accent else Theme.border, ctx.dp(if (sel) 2 else 1))
            row.addView(ctx.iconButton(if (l.visible) "eye" else "eyeOff", 38) { core.toggleVisible(l.id) })
            val info = ctx.vbox()
            info.addView(ctx.label(l.name, 14f, Theme.text, true))
            val sub = ctx.label(BlendModes.names[l.blendMode.coerceIn(0, BlendModes.names.size - 1)] + (if (l.kind != LayerKind.RASTER) " · " + l.kind.id else ""), 11f, Theme.textDim)
            sub.setOnClickListener { pickBlend(l.id) }
            info.addView(sub)
            info.setOnClickListener { core.selectLayer(l.id) }
            info.setOnLongClickListener { renameLayer(l.id); true }
            row.addView(info, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(ctx.button("▲") { core.moveLayer(l.id, 1) }.also { it.minHeight = 0; it.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6)) })
            row.addView(ctx.button("▼") { core.moveLayer(l.id, -1) }.also { it.minHeight = 0; it.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6)) })
            row.addView(ctx.iconButton("edit", 38) { renameLayer(l.id) })
            row.addView(ctx.button("Copy") { core.duplicateLayer(l.id) }.also { it.minHeight = 0; it.setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6)) })
            row.addView(ctx.iconButton("trash", 38) { if (!core.removeLayer(l.id)) core.toast("Can't delete the last layer") })
            val lpr = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpr.bottomMargin = ctx.dp(8)
            p.addView(row, lpr)
        }
    }

    private fun pickBlend(layerId: String) {
        val sh = Sheet(ctx, "Blend mode")
        for ((i, n) in BlendModes.names.withIndex()) {
            sh.add(ctx.button(n, core.layerById(layerId)?.blendMode == i) { core.setBlend(layerId, i); sh.dismiss() }, 6)
        }
        sh.show()
    }

    private fun renameLayer(id: String) {
        val l = core.layerById(id) ?: return
        val sh = Sheet(ctx, "Rename layer")
        val f = ctx.textField(l.name)
        sh.add(f)
        sh.add(ctx.button("Done", true) { core.renameLayer(id, f.text.toString()); sh.dismiss() })
        sh.show()
    }

    // ----------------------------------------------------------- elements panel ---
    private fun elementsPanel(): View {
        val p = ctx.vbox()
        addRow(p, ctx.label("Add elements", 13f, Theme.textDim), 0)
        val r = ctx.hbox()
        r.addView(ctx.button("+ Add Text") { core.addTextLayer(null); selectTab("elements") }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(ctx.button("+ Add Image") { host.pickImage() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addRow(p, r)

        addRow(p, ctx.label("Text", 13f, Theme.textDim), 14)
        val layer = core.selected()
        val tp = layer?.textProps
        if (layer == null || layer.kind != LayerKind.TEXT || tp == null) {
            addRow(p, ctx.label("Select a text layer to edit.", 14f, Theme.textDim), 4)
        } else {
            val props = tp.copy()
            var pending: Runnable? = null
            fun applyDebounced() {
                pending?.let { ui.removeCallbacks(it) }
                val rr = Runnable { core.updateTextLayer(layer.id, props.copy()) }
                pending = rr
                ui.postDelayed(rr, 350)
            }
            val content = ctx.textField(props.content, multiline = true)
            content.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { props.content = s.toString(); applyDebounced() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            addRow(p, content, 6)
            addRow(p, chips(TextRaster.families.map { Pair(it, it) }, props.fontFamily) { f -> props.fontFamily = f; core.updateTextLayer(layer.id, props.copy()); selectTab("elements") }, 8)
            addRow(p, SliderRow(ctx, "Size", 8, 600, props.fontSize.toInt()) { v, c -> props.fontSize = v.toDouble(); if (c) applyDebounced() })
            addRow(p, SliderRow(ctx, "Rotate", -180, 180, props.rotation.toInt()) { v, c -> props.rotation = v.toDouble(); if (c) applyDebounced() })
            val cr = ctx.hbox()
            cr.addView(ctx.label("Color", 13f, Theme.textDim), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            cr.addView(colorSwatch(TextRaster.parseColor(props.color)) { c -> props.color = String.format("#%06X", 0xFFFFFF and c); applyDebounced() })
            addRow(p, cr)
        }

        addRow(p, ctx.label("Patterns", 13f, Theme.textDim), 16)
        val grid = ctx.hbox()
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        for (pp in Patterns.presets) {
            val cell = ctx.vbox()
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val iv = ImageView(ctx)
            iv.setImageBitmap(Patterns.buildTile(pp.id, patternColor))
            iv.background = rounded(Theme.surface2, ctx.dpf(10f), if (patternId == pp.id) Theme.accent else Theme.border, ctx.dp(if (patternId == pp.id) 2 else 1))
            cell.addView(iv, LinearLayout.LayoutParams(ctx.dp(60), ctx.dp(60)))
            cell.addView(ctx.label(pp.name, 11f, Theme.textDim))
            cell.setOnClickListener { patternId = pp.id; selectTab("elements") }
            val lpp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lpp.rightMargin = ctx.dp(8)
            grid.addView(cell, lpp)
        }
        hs.addView(grid)
        addRow(p, hs, 6)
        val tintRow = ctx.hbox()
        tintRow.addView(ctx.label("Tint", 13f, Theme.textDim), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tintRow.addView(colorSwatch(patternColor) { c -> patternColor = c; selectTab("elements") })
        addRow(p, tintRow)
        addRow(p, SliderRow(ctx, "Scale", 10, 800, fillScale) { v, _ -> fillScale = v })
        addRow(p, SliderRow(ctx, "Opacity", 0, 100, fillOpacity) { v, _ -> fillOpacity = v })
        addRow(p, ctx.button("Fill Layer with Pattern") {
            val id = patternId
            if (id == null) core.toast("Select a pattern first")
            else core.fillPattern(Patterns.buildTile(id, patternColor), fillScale, fillOpacity)
        })

        addRow(p, ctx.label("Gradient Fill", 13f, Theme.textDim), 16)
        val g1 = ctx.hbox()
        g1.addView(ctx.label("From", 13f, Theme.textDim), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        g1.addView(colorSwatch(gradC1) { c -> gradC1 = c })
        g1.addView(ctx.spacer(0), lp(ctx.dp(16), 1))
        g1.addView(ctx.label("To", 13f, Theme.textDim))
        g1.addView(ctx.spacer(0), lp(ctx.dp(8), 1))
        g1.addView(colorSwatch(gradC2) { c -> gradC2 = c })
        addRow(p, g1, 6)
        addRow(p, Segmented(ctx, listOf("Linear", "Radial"), if (gradRadial) 1 else 0) { i -> gradRadial = i == 1 })
        addRow(p, SliderRow(ctx, "Angle", 0, 360, gradAngle) { v, _ -> gradAngle = v })
        addRow(p, ctx.button("Fill Layer with Gradient") { core.fillGradient(gradC1, gradC2, gradRadial, gradAngle.toDouble(), false, fillOpacity) })
        return p
    }

    // ----------------------------------------------------------- settings panel ---
    private fun settingsPanel(): View {
        val p = ctx.vbox()
        addRow(p, ctx.label("Appearance", 13f, Theme.textDim), 0)
        addRow(p, Segmented(ctx, listOf("Dark", "Light", "OLED"), listOf("dark", "light", "oled").indexOf(settings.theme).coerceAtLeast(0)) { i ->
            settings.theme = listOf("dark", "light", "oled")[i]
            settingsStore.save(settings)
            Theme.id = settings.theme
            host.rebuildUi()
        }, 4)
        addRow(p, ctx.label("Canvas bg", 13f, Theme.textDim))
        addRow(p, Segmented(ctx, listOf("Checker", "White", "Black"), listOf("checker", "white", "black").indexOf(canvas.stageBg)) { i ->
            canvas.stageBg = listOf("checker", "white", "black")[i]; canvas.invalidate()
        }, 4)
        addRow(p, ctx.label("Editor", 13f, Theme.textDim), 14)
        addRow(p, SliderRow(ctx, "History", 5, 100, settings.historySteps) { v, c -> settings.historySteps = v; if (c) settingsStore.save(settings) })
        val dw = ctx.textField(settings.defaultCanvasW.toString(), numeric = true)
        val dh = ctx.textField(settings.defaultCanvasH.toString(), numeric = true)
        val dr = ctx.hbox()
        dr.addView(ctx.label("Default canvas", 13f, Theme.textDim), lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        dr.addView(dw, lp(ctx.dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        dr.addView(ctx.label(" × ", 13f, Theme.textDim))
        dr.addView(dh, lp(ctx.dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        addRow(p, dr)
        addRow(p, ctx.button("Save default canvas") {
            settings.defaultCanvasW = (dw.text.toString().toIntOrNull() ?: 1080).coerceIn(16, 8192)
            settings.defaultCanvasH = (dh.text.toString().toIntOrNull() ?: 1080).coerceIn(16, 8192)
            settingsStore.save(settings); core.toast("Saved")
        })
        addRow(p, ctx.label("Data & storage", 13f, Theme.textDim), 14)
        addRow(p, SliderRow(ctx, "Autosave (ms)", 500, 10000, settings.autosaveMs) { v, c -> settings.autosaveMs = v; if (c) settingsStore.save(settings) })
        addRow(p, SliderRow(ctx, "Thumb size", 48, 256, settings.thumbSize) { v, c -> settings.thumbSize = v; if (c) settingsStore.save(settings) })
        addRow(p, SliderRow(ctx, "Thumb JPEG", 40, 100, (settings.thumbQuality * 100).toInt()) { v, c -> settings.thumbQuality = v / 100.0; if (c) settingsStore.save(settings) })
        addRow(p, ctx.button("Free memory") {
            core.store.retainOnly(core.history.referencedImageIds() + core.layers.map { it.imageId })
            core.toast("Memory freed")
        })
        addRow(p, ctx.button("Delete all projects", danger = true) { confirmDeleteAll() })
        addRow(p, ctx.label("Canvas", 13f, Theme.textDim), 14)
        addRow(p, ctx.button("New Blank Canvas") { showCanvasSizeSheet() }, 4)
        addRow(p, ctx.label("Bake", 13f, Theme.textDim), 14)
        addRow(p, ctx.button("Bake Effects", true) { showBakeSheet() }, 4)
        addRow(p, ctx.label("Zetaphii Editor · native Android build", 12f, Theme.textDim), 14)
        return p
    }

    private fun confirmDeleteAll() {
        val sh = Sheet(ctx, "Delete all projects?")
        sh.add(ctx.label("This permanently removes every saved project on this device.", 14f, Theme.textDim))
        sh.add(ctx.button("Delete everything", danger = true) {
            for (m in projects.list()) projects.delete(m.id)
            sh.dismiss(); core.projectId = null
            host.goHome()
        })
        sh.add(ctx.button("Cancel") { sh.dismiss() })
        sh.show()
    }

    // --------------------------------------------------------------------- sheets ---
    fun showCanvasSizeSheet() {
        val sh = Sheet(ctx, "Canvas size")
        var w = settings.defaultCanvasW
        var h = settings.defaultCanvasH
        val preview = ctx.label("$w × $h", 15f, Theme.text, true)
        val wF = ctx.textField(w.toString(), numeric = true)
        val hF = ctx.textField(h.toString(), numeric = true)
        fun sync() {
            w = (wF.text.toString().toIntOrNull() ?: w).coerceIn(1, 8192)
            h = (hF.text.toString().toIntOrNull() ?: h).coerceIn(1, 8192)
            preview.text = "$w × $h"
        }
        val presets = listOf(Triple("1:1", 1080, 1080), Triple("16:9", 1920, 1080), Triple("9:16", 1080, 1920), Triple("2K²", 2048, 2048))
        val pr = ctx.hbox()
        for (pz in presets) pr.addView(ctx.button(pz.first) { wF.setText(pz.second.toString()); hF.setText(pz.third.toString()); sync() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sh.add(pr)
        val fr = ctx.hbox()
        fr.addView(wF, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fr.addView(ctx.label("  ×  ", 15f, Theme.textDim))
        fr.addView(hF, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sh.add(fr)
        sh.add(preview)
        val br = ctx.hbox()
        br.addView(ctx.button("Cancel") { sh.dismiss() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        br.addView(ctx.button("Create Canvas", true) { sync(); sh.dismiss(); core.createBlankCanvas(w, h) }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sh.add(br)
        sh.show()
    }

    fun showBakeSheet() {
        if (core.layers.isEmpty()) { core.toast("Nothing to bake yet"); return }
        val sh = Sheet(ctx, "Bake")
        var fmt = ImageCodec.Format.PNG
        var quality = 92
        var scopeAll = true
        val qRow = SliderRow(ctx, "Quality", 1, 100, quality) { v, _ -> quality = v }
        qRow.visibility = View.GONE
        sh.add(Segmented(ctx, listOf("PNG", "JPG", "WEBP"), 0) { i ->
            fmt = listOf(ImageCodec.Format.PNG, ImageCodec.Format.JPG, ImageCodec.Format.WEBP)[i]
            qRow.visibility = if (fmt == ImageCodec.Format.PNG) View.GONE else View.VISIBLE
        })
        sh.add(qRow)
        sh.add(ctx.button("Bake & Save Image", true) {
            val size = core.canvasSize()
            if (size != null) {
                val name = ImageCodec.fileName(core.projectName, size[0], size[1], fmt)
                val f = fmt
                val q = quality
                sh.dismiss()
                host.saveFile(name, f.mime) { out ->
                    val bmp = core.renderFull()
                    if (bmp == null) throw IllegalStateException("render failed")
                    ImageCodec.encode(bmp, f, q, out)
                }
            }
        })
        sh.add(Segmented(ctx, listOf("Selected layer", "All layers"), 1) { i -> scopeAll = i == 1 }, 18)
        sh.add(ctx.button("Bake into layer pixels") { sh.dismiss(); core.bakeIntoPixels(scopeAll) })
        sh.add(ctx.button("Cancel") { sh.dismiss() })
        sh.show()
    }

    private fun renameProject() {
        val sh = Sheet(ctx, "Rename project")
        val f = ctx.textField(core.projectName)
        sh.add(f)
        sh.add(ctx.button("Done", true) {
            val n = f.text.toString().trim()
            if (n.isNotEmpty()) { core.projectName = n; projectLabel.text = n; core.scheduleAutosave() }
            sh.dismiss()
        })
        sh.show()
    }

    // ------------------------------------------------------------ state refresh ---
    private fun refreshAll() {
        projectLabel.text = core.projectName
        emptyState.visibility = if (core.layers.isEmpty() && canvas.mode != CanvasView.Mode.PLACE) View.VISIBLE else View.GONE
        undoBtn.setEnabledLook(core.canUndo())
        redoBtn.setEnabledLook(core.canRedo())
        canvas.invalidate()
    }

    override fun onLayersChanged() {
        refreshAll()
        if (currentTab == "layers") rebuildLayerRows()
    }

    override fun onHistoryChanged() { undoBtn.setEnabledLook(core.canUndo()); redoBtn.setEnabledLook(core.canRedo()) }
    override fun onCanvasSizeChanged() { refreshAll() }

    override fun onBusy(busy: Boolean) { busyOverlay.visibility = if (busy) View.VISIBLE else View.GONE }

    override fun onToast(msg: String) {
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        toastHide?.let { ui.removeCallbacks(it) }
        val r = Runnable { toastView.visibility = View.GONE }
        toastHide = r
        ui.postDelayed(r, 2200)
    }

    override fun onSaveState(state: String) {
        val c = when (state) { "saved" -> Color.parseColor("#3BA55D"); "saving" -> Theme.accentStrong; else -> Theme.accentWarm }
        saveDot.background = rounded(c, ctx.dpf(4f))
    }
}

/** Compact HSV colour picker (sheet) with a hex field. */
fun pickColor(ctx: Context, initial: Int, onPick: (Int) -> Unit) {
    val sh = Sheet(ctx, "Color")
    val hsv = FloatArray(3)
    Color.colorToHSV(initial, hsv)
    val preview = View(ctx)
    val hex = ctx.textField(String.format("#%06X", 0xFFFFFF and initial))
    var silent = false
    fun current(): Int = Color.HSVToColor(hsv)
    fun refresh() {
        preview.background = rounded(current(), ctx.dpf(12f), Theme.borderStrong, ctx.dp(1))
        silent = true; hex.setText(String.format("#%06X", 0xFFFFFF and current())); silent = false
    }
    sh.add(preview.also { it.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(54)) })
    val hRow = SliderRow(ctx, "Hue", 0, 359, hsv[0].toInt()) { v, _ -> hsv[0] = v.toFloat(); refresh() }
    val sRow = SliderRow(ctx, "Saturation", 0, 100, (hsv[1] * 100).toInt()) { v, _ -> hsv[1] = v / 100f; refresh() }
    val vRow = SliderRow(ctx, "Brightness", 0, 100, (hsv[2] * 100).toInt()) { v, _ -> hsv[2] = v / 100f; refresh() }
    sh.add(hRow); sh.add(sRow); sh.add(vRow)
    sh.add(hex)
    hex.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
            if (silent) return
            try {
                val c = Color.parseColor(s.toString())
                Color.colorToHSV(c, hsv)
                preview.background = rounded(c, ctx.dpf(12f), Theme.borderStrong, ctx.dp(1))
                hRow.set(hsv[0].toInt()); sRow.set((hsv[1] * 100).toInt()); vRow.set((hsv[2] * 100).toInt())
            } catch (t: Throwable) {
            }
        }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    })
    sh.add(ctx.button("Use color", true) { onPick(current()); sh.dismiss() })
    refresh()
    sh.show()
}
