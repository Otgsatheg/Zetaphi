package app.zetaphii.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import app.zetaphii.model.Params

class EffectBrushDef(val key: String, val name: String, val bidirectional: Boolean, val def: Int)

/** Port of the stamp-based brush from 22-drawing-*.ts (hard / soft / air tips, eraser, effect brushes). */
class BrushEngine(private val core: EditorCore) {
    companion object {
        val EFFECT_BRUSHES: List<EffectBrushDef> = listOf(
            EffectBrushDef("posterize", "Posterize", false, 65),
            EffectBrushDef("pixelate", "Pixelate", false, 45),
            EffectBrushDef("blur", "Blur", false, 55),
            EffectBrushDef("grain", "Grain", false, 55),
            EffectBrushDef("vignette", "Vignette", false, 60),
            EffectBrushDef("invert", "Invert", false, 100),
            EffectBrushDef("hue", "Hue", true, 40),
            EffectBrushDef("saturation", "Saturation", true, -70),
            EffectBrushDef("brightness", "Brightness", true, 35),
            EffectBrushDef("contrast", "Contrast", true, 40),
            EffectBrushDef("temperature", "Temperature", true, 45),
            EffectBrushDef("exposure", "Exposure", true, 40)
        )
    }

    var style: String = "hard"          // hard | soft | air
    var size: Int = 12                   // brush diameter in image pixels (independent of zoom)
    var opacity: Double = 1.0            // 0..1
    var color: Int = Color.parseColor("#0731A7")
    var eraser: Boolean = false
    var effectKey: String? = null        // non-null = effect brush
    var effectStrength: Int = 50

    var overlay: Bitmap? = null
        private set
    private var overlayCanvas: Canvas? = null
    var hasStrokes: Boolean = false
        private set

    private var snap: Bitmap? = null     // pre-stroke layer pixels for effect brushes
    private var selMask: Bitmap? = null

    private var spriteKey = ""
    private var sprite: Bitmap? = null

    /** Allocates the stroke overlay at canvas size when the first stroke starts. */
    fun begin(w: Int, h: Int): Boolean {
        val ov = overlay
        if (ov == null || ov.width != w || ov.height != h) {
            try {
                overlay = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            } catch (t: OutOfMemoryError) {
                overlay = null
                return false
            }
            overlayCanvas = Canvas(overlay!!)
        }
        selMask = core.selectionBitmap()
        snap = null
        if (effectKey != null && !eraser) {
            val l = core.selected()
            val b = l?.let { core.store.get(it.imageId) }
            if (b != null && b.width == w && b.height == h) snap = b
        }
        return true
    }

    fun clear() {
        overlay?.eraseColor(Color.TRANSPARENT)
        hasStrokes = false
        snap = null
    }

    fun release() {
        overlay = null
        overlayCanvas = null
        hasStrokes = false
        snap = null
        sprite = null
        spriteKey = ""
    }

    private fun stampSprite(st: String, col: Int, alpha: Float, radius: Float): Bitmap {
        val r = Math.max(0.5f, Math.ceil(radius.toDouble()).toFloat())
        val key = "$st|$col|${"%.4f".format(alpha)}|$r"
        val cached = sprite
        if (cached != null && key == spriteKey) return cached
        val sz = Math.ceil((r * 2 + 2).toDouble()).toInt()
        val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val cx = sz / 2f
        val rr = Color.red(col)
        val gg = Color.green(col)
        val bb = Color.blue(col)
        fun c(a: Float): Int = Color.argb((Math.max(0f, Math.min(1f, a)) * 255f + 0.5f).toInt(), rr, gg, bb)
        val colors: IntArray
        val pos: FloatArray
        when (st) {
            "air" -> { colors = intArrayOf(c(alpha * 0.22f), c(alpha * 0.08f), c(0f)); pos = floatArrayOf(0f, 0.45f, 1f) }
            "soft" -> { colors = intArrayOf(c(alpha), c(alpha * 0.55f), c(0f)); pos = floatArrayOf(0f, 0.55f, 1f) }
            else -> { colors = intArrayOf(c(alpha), c(alpha), c(0f)); pos = floatArrayOf(0f, 0.85f, 1f) }
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(cx, cx, r, colors, pos, Shader.TileMode.CLAMP)
        Canvas(bmp).drawCircle(cx, cx, r, p)
        sprite = bmp
        spriteKey = key
        return bmp
    }

    private fun inSelection(x: Float, y: Float): Boolean {
        val m = selMask ?: return true
        val ov = overlay ?: return true
        val sx = (x * m.width / Math.max(1, ov.width)).toInt()
        val sy = (y * m.height / Math.max(1, ov.height)).toInt()
        if (sx < 0 || sy < 0 || sx >= m.width || sy >= m.height) return false
        return Color.alpha(m.getPixel(sx, sy)) > 8
    }

    private fun spacingFor(radius: Float): Float = when (style) {
        "air" -> Math.max(0.35f, radius * 0.12f)
        "soft" -> Math.max(0.4f, radius * 0.22f)
        else -> Math.max(0.35f, radius * 0.28f)
    }

    /** Paints from [from] (null = first dab) to [to] in image pixel coordinates. */
    fun stroke(from: PointF?, to: PointF) {
        val c = overlayCanvas ?: return
        val radius = Math.max(0.5f, size / 2f)
        val col = if (eraser) Color.parseColor("#0731A7") else color
        val alpha = (if (eraser) Math.max(0.35, opacity) else opacity).toFloat()
        val spacing = spacingFor(radius)
        fun stampAt(x: Float, y: Float) {
            if (!inSelection(x, y)) return
            if (effectKey != null && !eraser) effectStamp(c, x, y, radius, alpha)
            else {
                val s = stampSprite(style, col, alpha, radius)
                val baseR = Math.max(0.5f, Math.ceil(radius.toDouble()).toFloat())
                val sc = if (Math.abs(baseR - radius) > 0.5f) radius / baseR else 1f
                if (sc != 1f) {
                    c.save(); c.translate(x, y); c.scale(sc, sc)
                    c.drawBitmap(s, -s.width / 2f, -s.height / 2f, null)
                    c.restore()
                } else c.drawBitmap(s, x - s.width / 2f, y - s.height / 2f, null)
            }
        }
        if (from == null) {
            stampAt(to.x, to.y)
        } else {
            val dx = to.x - from.x
            val dy = to.y - from.y
            val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (dist < 0.001f) stampAt(to.x, to.y)
            else {
                val steps = Math.max(1, Math.ceil((dist / spacing).toDouble()).toInt())
                for (i in 1..steps) {
                    val t = i.toFloat() / steps
                    stampAt(from.x + dx * t, from.y + dy * t)
                }
            }
        }
        hasStrokes = true
    }

    /** Effect brush dab: native per-pixel filter of the pre-stroke pixels, masked by the round tip. */
    private fun effectStamp(c: Canvas, x: Float, y: Float, radius: Float, alpha: Float) {
        val s = snap ?: return
        val key = effectKey ?: return
        val idx = NativeEngine.EFFECT_KEYS.indexOf(key)
        if (idx < 0) return
        val r = Math.max(1, Math.ceil(radius.toDouble()).toInt())
        val x0 = Math.max(0, Math.floor((x - r).toDouble()).toInt())
        val y0 = Math.max(0, Math.floor((y - r).toDouble()).toInt())
        val x1 = Math.min(s.width, Math.ceil((x + r).toDouble()).toInt())
        val y1 = Math.min(s.height, Math.ceil((y + r).toDouble()).toInt())
        val bw = x1 - x0
        val bh = y1 - y0
        if (bw < 1 || bh < 1) return
        val def = Params.byKey[key] ?: return
        val shaderValue = def.toShader(effectStrength.toDouble()).toFloat()
        val region = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        if (NativeEngine.nativeEffectRegion(s, x0, y0, bw, bh, idx, shaderValue, region) != 0) return
        val tip = stampSprite(style, Color.WHITE, 1f, radius)
        val mask = Paint()
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        Canvas(region).drawBitmap(tip, x - tip.width / 2f - x0, y - tip.height / 2f - y0, mask)
        val p = Paint()
        p.alpha = (Math.max(0f, Math.min(1f, alpha)) * 255f + 0.5f).toInt()
        c.drawBitmap(region, x0.toFloat(), y0.toFloat(), p)
    }
}

/** Lasso selection (freehand / rect / ellipse / polygon) painting into a canvas-sized mask. Selections are additive. */
class LassoEngine(private val core: EditorCore) {
    var mode: String = "freehand"        // freehand | rect | ellipse | poly
    var points: ArrayList<PointF> = ArrayList()
        private set
    private var start: PointF? = null
    private var work: Bitmap? = null
    private var workCanvas: Canvas? = null
    private var nonEmpty: Boolean = false
    private var strokeActive = false

    /** Working mask being edited (shown live by the canvas view); null when idle. */
    fun workingMask(): Bitmap? = work

    private fun ensureWork(): Boolean {
        if (work == null) {
            val m = core.selectionBitmapForEdit() ?: return false
            work = m
            workCanvas = Canvas(m)
            nonEmpty = core.hasSelection
        }
        return true
    }

    fun cancel() {
        work = null; workCanvas = null; points = ArrayList(); start = null; strokeActive = false
    }

    fun pointerDown(pt: PointF, brushSize: Int) {
        if (!ensureWork()) return
        paintAt(pt, null, brushSize)
    }

    fun pointerMove(from: PointF, pt: PointF, brushSize: Int) {
        if (work == null) return
        paintAt(pt, from, brushSize)
    }

    private fun white(): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        return p
    }

    private fun paintAt(pt: PointF, from: PointF?, brushSize: Int) {
        val c = workCanvas ?: return
        if (mode == "freehand") {
            val radius = Math.max(1f, brushSize / 2f)
            val p = white()
            if (from == null) {
                c.drawCircle(pt.x, pt.y, radius, p)
            } else {
                val dx = pt.x - from.x
                val dy = pt.y - from.y
                val dist = Math.max(0.001, Math.sqrt((dx * dx + dy * dy).toDouble())).toFloat()
                val spacing = Math.max(0.5f, radius * 0.35f)
                val steps = Math.max(1, Math.ceil((dist / spacing).toDouble()).toInt())
                for (i in 1..steps) {
                    val t = i.toFloat() / steps
                    c.drawCircle(from.x + dx * t, from.y + dy * t, radius, p)
                }
            }
            nonEmpty = true
            strokeActive = true
            return
        }
        if (from == null) {
            start = PointF(pt.x, pt.y)
            if (mode == "poly") {
                if (points.isEmpty()) {
                    points.add(PointF(pt.x, pt.y)); points.add(PointF(pt.x, pt.y))
                } else {
                    points[points.size - 1] = PointF(pt.x, pt.y)
                    points.add(PointF(pt.x, pt.y))
                }
            } else {
                points = arrayListOf(PointF(pt.x, pt.y), PointF(pt.x, pt.y))
            }
            strokeActive = true
        } else if (mode == "rect" || mode == "ellipse") {
            points = arrayListOf(start ?: pt, PointF(pt.x, pt.y))
        } else if (mode == "poly") {
            if (points.isNotEmpty()) points[points.size - 1] = PointF(pt.x, pt.y)
        }
    }

    /** Finishes a gesture. Returns true when the selection changed (and was committed to history). */
    fun pointerUp(): Boolean {
        if (!strokeActive) return false
        strokeActive = false
        var changed = false
        if (mode == "freehand") {
            changed = nonEmpty
        } else if (mode == "poly") {
            if (points.size >= 3) {
                val s = points[0]
                val p = points[points.size - 1]
                if (Math.hypot((p.x - s.x).toDouble(), (p.y - s.y).toDouble()) < 24.0) {
                    fillPath()
                    points = ArrayList()
                    changed = true
                }
            }
        } else if (points.size >= 2) {
            fillPath()
            points = ArrayList()
            changed = true
        }
        if (changed) commit()
        return changed
    }

    private fun fillPath() {
        val c = workCanvas ?: return
        val p = white()
        if (mode == "rect" || mode == "ellipse") {
            val a = points[0]
            val b = points[1]
            val r = RectF(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.max(a.x, b.x), Math.max(a.y, b.y))
            if (mode == "rect") c.drawRect(r, p) else c.drawOval(r, p)
        } else {
            val path = Path()
            for (i in points.indices) {
                if (i == 0) path.moveTo(points[i].x, points[i].y) else path.lineTo(points[i].x, points[i].y)
            }
            path.close()
            c.drawPath(path, p)
        }
        nonEmpty = true
    }

    private fun commit() {
        val m = work ?: return
        core.setSelection(m, nonEmpty)
        work = null
        workCanvas = null
    }
}
