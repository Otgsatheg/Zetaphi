package app.zetaphii.editor

import app.zetaphii.model.ManagerSnapshot

/**
 * Snapshot-based undo/redo (HistoryManager in the original). Images are immutable, so a snapshot only
 * stores image ids. The lasso selection mask is stored the same way (as an image id), so undo/redo
 * also restores selection edits, like the original.
 */
class History(var maxSteps: Int) {
    class Entry(val snap: ManagerSnapshot, val selectionId: String?)

    private val stack = ArrayList<Entry>()
    private var index = -1

    fun reset(initial: ManagerSnapshot, selectionId: String?) {
        stack.clear()
        stack.add(Entry(initial, selectionId))
        index = 0
    }

    fun push(s: ManagerSnapshot, selectionId: String?) {
        while (stack.size > index + 1) stack.removeAt(stack.size - 1)
        stack.add(Entry(s, selectionId))
        index = stack.size - 1
        while (stack.size > maxSteps && stack.size > 1) {
            stack.removeAt(0)
            index--
        }
    }

    fun canUndo(): Boolean = index > 0
    fun canRedo(): Boolean = index >= 0 && index < stack.size - 1

    fun undo(): Entry? {
        if (!canUndo()) return null
        index--
        return stack[index]
    }

    fun redo(): Entry? {
        if (!canRedo()) return null
        index++
        return stack[index]
    }

    /** Every image id still reachable through undo/redo (layer images and selection masks). */
    fun referencedImageIds(): Set<String> {
        val s = HashSet<String>()
        for (e in stack) {
            s.addAll(e.snap.imageIds())
            if (e.selectionId != null) s.add(e.selectionId)
        }
        return s
    }
}
