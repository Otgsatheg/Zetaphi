package app.zetaphii.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Shader
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import app.zetaphii.editor.BrushEngine
import app.zetaphii.editor.EditorCore
import app.zetaphii.editor.EditorListener
import app.zetaphii.editor.LassoEngine

/** State of the "place image" mode (move / scale / rotate / flip a picture before it becomes a layer). */
class PlaceState(val bitmap: Bitmap, var cx: Float, var cy: Float, var scaleX: Float, var scaleY: Float) {
    var rotation = 0f
    var flipH = false
    var flipV = false
}

/**
 * The stage: draws the composed frame (from the native renderer), the live stroke overlay, selection,
 * crop box and place box, and handles touch (pinch/pan/rotate, drawing, lasso, crop, place).
 */
class CanvasView(
    context: Context,
    private val core: EditorCore,
    val brush: BrushEngine,
    val lasso: LassoEngine
) : View(context), EditorListener {

    enum class Mode { NAVIGATE, DRAW, CROP, PLACE }

    var mode = Mode.NAVIGATE
        set(v) { field = v; invalidate() }
    var drawTool = "brush"          // brush | eraser | lasso
    var stageBg = "checker"         // checker | white | black
    var brushSizePx = 12

    // view transform (CSS translate → scale → rotate about the frame centre)
    var scale = 1f
    var tx = 0f
    var ty = 0f
    var viewRotation = 0f

    private val pad = dp(14).toFloat()
    private val frameRect = RectF()
    private val m = Matrix()
    private val inv = Matrix()

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val checkerPaint = Paint()
    private val dimPaint = Paint().apply { color = Color.argb(150, 0, 0, 0) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = dp(2).toFloat() }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Theme.accent; strokeWidth = dp(2).toFloat() }
    private val selPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        // tint the white selection mask with the accent colour at ~40% opacity
        colorFilter = ColorMatrixColorFilter(floatArrayOf(
            0f, 0f, 0f, 0f, 42f,
            0f, 0f, 0f, 0f, 112f,
            0f, 0f, 0f, 0f, 255f,
            0f, 0f, 0f, 0.4f, 0f))
    }
    private val antsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = dp(1.5f).toFloat()
        pathEffect = DashPathEffect(floatArrayOf(dp(6).toFloat(), dp(4).toFloat()), 0f)
    }

    // pointer bookkeeping
    private var drawing = false
    private var last: PointF? = null
    private var navActive = false
    private var navMid = PointF()
    private var navDist = 0f
    private var navAngle = 0f

    // crop
    var crop: RectF? = null                  // in layer pixel space
    private var cropLayerW = 1
    private var cropLayerH = 1
    private var cropDrag: String? = null
    private var cropStart = RectF()
    private var cropStartPt = PointF()

    // place
    var place: PlaceState? = null
    private var placeDrag = false
    private var placeHandle = -1

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (mode == Mode.NAVIGATE) { resetView(); return true }
            return false
        }
    })

    init {
        core.listeners.add(this)
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    private fun dp(v: Int): Int = context.dp(v)
    private fun dp(v: Float): Float = context.dpf(v)

    fun detach() { core.listeners.remove(this) }

    override fun onFrameReady() { invalidate() }
    override fun onCanvasSizeChanged() { invalidate() }
    override fun onLayersChanged() { invalidate() }

    fun resetView() { scale = 1f; tx = 0f; ty = 0f; viewRotation = 0f; invalidate() }

    // --------------------------------------------------------------- geometry ---
    private fun canvasDims(): IntArray = core.canvasSize() ?: intArrayOf(1, 1)

    private fun updateGeometry() {
        val d = canvasDims()
        val availW = Math.max(1f, width - pad * 2)
        val availH = Math.max(1f, height - pad * 2)
        val k = Math.min(availW / d[0], availH / d[1])
        val fw = d[0] * k
        val fh = d[1] * k
        frameRect.set((width - fw) / 2f, (height - fh) / 2f, (width + fw) / 2f, (height + fh) / 2f)
        m.reset()
        m.postTranslate(frameRect.left, frameRect.top)
        m.postScale(k, k, frameRect.left, frameRect.top)
        val cx = frameRect.centerX()
        val cy = frameRect.centerY()
        m.postRotate(viewRotation, cx, cy)
        m.postScale(scale, scale, cx, cy)
        m.postTranslate(tx, ty)
        m.invert(inv)
    }

    private fun toImage(x: Float, y: Float): PointF {
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return PointF(p[0], p[1])
    }

    private fun toScreen(x: Float, y: Float): PointF {
        val p = floatArrayOf(x, y)
        m.mapPoints(p)
        return PointF(p[0], p[1])
    }

    private fun ensureChecker() {
        if (checkerPaint.shader != null) return
        val s = 16
        val b = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint()
        p.color = Color.parseColor("#2A2A2E"); c.drawRect(0f, 0f, s * 2f, s * 2f, p)
        p.color = Color.parseColor("#3A3A40")
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p); c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        checkerPaint.shader = BitmapShader(b, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    // ------------------------------------------------------------------- draw ---
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Theme.bgSoft)
        val d = canvasDims()
        val hasLayers = core.layers.isNotEmpty()
        if (!hasLayers) return
        updateGeometry()
        val img = RectF(0f, 0f, d[0].toFloat(), d[1].toFloat())
        canvas.save()
        canvas.concat(m)
        when (stageBg) {
            "white" -> canvas.drawRect(img, Paint().apply { color = Color.WHITE })
            "black" -> canvas.drawRect(img, Paint().apply { color = Color.BLACK })
            else -> {
                ensureChecker()
                canvas.save()
                canvas.clipRect(img)
                // checker squares are 16 image-px wide scaled to the frame so they stay visible
                val kk = frameRect.width() / d[0]
                canvas.scale(1f / kk, 1f / kk)
                canvas.drawRect(0f, 0f, d[0] * kk, d[1] * kk, checkerPaint)
                canvas.restore()
            }
        }
        core.frame?.let { canvas.drawBitmap(it, null, img, bmpPaint) }
        brush.overlay?.let { if (brush.hasStrokes) canvas.drawBitmap(it, null, img, bmpPaint) }
        val sel = lasso.workingMask() ?: core.selectionBitmap()
        if (sel != null && drawTool == "lasso" && mode == Mode.DRAW) canvas.drawBitmap(sel, null, img, selPaint)
        else if (sel != null && core.hasSelection && mode == Mode.DRAW) canvas.drawBitmap(sel, null, img, selPaint)
        // lasso path being drawn (shape modes)
        if (mode == Mode.DRAW && drawTool == "lasso" && lasso.points.size >= 2) {
            val pts = lasso.points
            val path = Path()
            if (lasso.mode == "rect") {
                path.addRect(Math.min(pts[0].x, pts[1].x), Math.min(pts[0].y, pts[1].y), Math.max(pts[0].x, pts[1].x), Math.max(pts[0].y, pts[1].y), Path.Direction.CW)
            } else if (lasso.mode == "ellipse") {
                path.addOval(RectF(Math.min(pts[0].x, pts[1].x), Math.min(pts[0].y, pts[1].y), Math.max(pts[0].x, pts[1].x), Math.max(pts[0].y, pts[1].y)), Path.Direction.CW)
            } else {
                for (i in pts.indices) if (i == 0) path.moveTo(pts[i].x, pts[i].y) else path.lineTo(pts[i].x, pts[i].y)
            }
            val strokeScale = 1f / (Math.max(0.0001f, frameRect.width() / d[0]) * scale)
            val ants = Paint(antsPaint)
            ants.strokeWidth = antsPaint.strokeWidth * strokeScale
            ants.pathEffect = DashPathEffect(floatArrayOf(6f * strokeScale * dp(1), 4f * strokeScale * dp(1)), 0f)
            canvas.drawPath(path, ants)
        }
        // place preview (drawn in image space so it follows the view transform)
        val pl = place
        if (mode == Mode.PLACE && pl != null) {
            canvas.save()
            canvas.translate(pl.cx, pl.cy)
            canvas.rotate(pl.rotation)
            canvas.scale(pl.scaleX * (if (pl.flipH) -1f else 1f), pl.scaleY * (if (pl.flipV) -1f else 1f))
            canvas.drawBitmap(pl.bitmap, -pl.bitmap.width / 2f, -pl.bitmap.height / 2f, bmpPaint)
            canvas.restore()
        }
        canvas.restore()

        // screen-space overlays (constant handle size)
        if (mode == Mode.CROP) drawCrop(canvas, d)
        if (mode == Mode.PLACE && pl != null) drawPlaceBox(canvas, pl)
    }

    private fun cropToCanvas(r: RectF, d: IntArray): RectF {
        val sx = d[0].toFloat() / cropLayerW
        val sy = d[1].toFloat() / cropLayerH
        return RectF(r.left * sx, r.top * sy, r.right * sx, r.bottom * sy)
    }

    private fun drawCrop(canvas: Canvas, d: IntArray) {
        val r = crop ?: return
        val c = cropToCanvas(r, d)
        val corners = arrayOf(toScreen(c.left, c.top), toScreen(c.right, c.top), toScreen(c.right, c.bottom), toScreen(c.left, c.bottom))
        val path = Path()
        path.moveTo(corners[0].x, corners[0].y)
        for (i in 1..3) path.lineTo(corners[i].x, corners[i].y)
        path.close()
        // dim everything outside the crop path
        val outer = Path()
        outer.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        outer.addPath(path)
        outer.fillType = Path.FillType.EVEN_ODD
        canvas.drawPath(outer, dimPaint)
        canvas.drawPath(path, linePaint)
        for (cp in cropHandlePoints(c)) canvas.drawCircle(cp.second.x, cp.second.y, dp(8).toFloat(), handlePaint)
    }

    /** Eight handles + names (n, s, e, w combinations). */
    private fun cropHandlePoints(c: RectF): List<Pair<String, PointF>> {
        val cx = (c.left + c.right) / 2
        val cy = (c.top + c.bottom) / 2
        return listOf(
            Pair("nw", toScreen(c.left, c.top)), Pair("n", toScreen(cx, c.top)), Pair("ne", toScreen(c.right, c.top)),
            Pair("e", toScreen(c.right, cy)), Pair("se", toScreen(c.right, c.bottom)), Pair("s", toScreen(cx, c.bottom)),
            Pair("sw", toScreen(c.left, c.bottom)), Pair("w", toScreen(c.left, cy))
        )
    }

    private fun placeCorners(pl: PlaceState): Array<PointF> {
        val hw = pl.bitmap.width / 2f * pl.scaleX
        val hh = pl.bitmap.height / 2f * pl.scaleY
        val rad = Math.toRadians(pl.rotation.toDouble())
        val cs = Math.cos(rad).toFloat()
        val sn = Math.sin(rad).toFloat()
        fun pt(x: Float, y: Float) = toScreen(pl.cx + x * cs - y * sn, pl.cy + x * sn + y * cs)
        return arrayOf(pt(-hw, -hh), pt(hw, -hh), pt(hw, hh), pt(-hw, hh))
    }

    private fun drawPlaceBox(canvas: Canvas, pl: PlaceState) {
        val c = placeCorners(pl)
        val path = Path()
        path.moveTo(c[0].x, c[0].y)
        for (i in 1..3) path.lineTo(c[i].x, c[i].y)
        path.close()
        canvas.drawPath(path, handleStroke)
        for (p in c) canvas.drawCircle(p.x, p.y, dp(9).toFloat(), handlePaint)
        for (p in c) canvas.drawCircle(p.x, p.y, dp(9).toFloat(), handleStroke)
    }

    // ------------------------------------------------------------------ touch ---
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (core.layers.isEmpty()) return false
        updateGeometry()
        detector.onTouchEvent(e)
        // two-finger gesture: navigate the view (or transform the piece in place mode)
        if (e.pointerCount >= 2) {
            if (drawing) finishStroke()
            return twoFinger(e)
        } else if (navActive) {
            navActive = false
            if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) { last = null }
        }
        return when (mode) {
            Mode.DRAW -> drawTouch(e)
            Mode.CROP -> cropTouch(e)
            Mode.PLACE -> placeTouch(e)
            Mode.NAVIGATE -> navTouch(e)
        }
    }

    private fun twoFinger(e: MotionEvent): Boolean {
        val x0 = e.getX(0); val y0 = e.getY(0); val x1 = e.getX(1); val y1 = e.getY(1)
        val mid = PointF((x0 + x1) / 2f, (y0 + y1) / 2f)
        val dist = Math.hypot((x1 - x0).toDouble(), (y1 - y0).toDouble()).toFloat()
        val ang = Math.toDegrees(Math.atan2((y1 - y0).toDouble(), (x1 - x0).toDouble())).toFloat()
        if (!navActive || e.actionMasked == MotionEvent.ACTION_POINTER_DOWN) {
            navActive = true; navMid = mid; navDist = dist; navAngle = ang
            return true
        }
        if (e.actionMasked == MotionEvent.ACTION_MOVE) {
            val pl = place
            if (mode == Mode.PLACE && pl != null) {
                val a = toImage(navMid.x, navMid.y)
                val b = toImage(mid.x, mid.y)
                pl.cx += b.x - a.x
                pl.cy += b.y - a.y
                if (navDist > 1f) { val f = dist / navDist; pl.scaleX *= f; pl.scaleY *= f }
                pl.rotation += ang - navAngle
            } else {
                tx += mid.x - navMid.x
                ty += mid.y - navMid.y
                if (navDist > 1f) scale = (scale * dist / navDist).coerceIn(0.5f, 8f)
                if (mode != Mode.CROP) viewRotation += ang - navAngle
            }
            navMid = mid; navDist = dist; navAngle = ang
            invalidate()
        }
        return true
    }

    private fun navTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> last = PointF(e.x, e.y)
            MotionEvent.ACTION_MOVE -> {
                val l = last
                if (l != null) { tx += e.x - l.x; ty += e.y - l.y; last = PointF(e.x, e.y); invalidate() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> last = null
        }
        return true
    }

    private fun drawTouch(e: MotionEvent): Boolean {
        val d = canvasDims()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = toImage(e.x, e.y)
                parent?.requestDisallowInterceptTouchEvent(true)
                if (drawTool == "lasso") {
                    lasso.pointerDown(p, brushSizePx)
                    last = p
                    drawing = true
                } else {
                    if (core.ensureDrawableLayer() == null) return true
                    val dd = canvasDims()
                    if (!brush.begin(dd[0], dd[1])) { core.toast("Not enough memory to paint"); return true }
                    brush.eraser = drawTool == "eraser"
                    brush.stroke(null, p)
                    last = p
                    drawing = true
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                var from = last
                for (i in 0 until e.historySize) {
                    val hp = toImage(e.getHistoricalX(i), e.getHistoricalY(i))
                    stepTo(from, hp)
                    from = hp
                }
                val p = toImage(e.x, e.y)
                stepTo(from, p)
                last = p
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (drawing) { finishStroke(); invalidate() }
            MotionEvent.ACTION_CANCEL -> if (drawing) { finishStroke(); invalidate() }
        }
        if (d[0] < 1) return false
        return true
    }

    private fun stepTo(from: PointF?, p: PointF) {
        if (drawTool == "lasso") { if (from != null) lasso.pointerMove(from, p, brushSizePx) }
        else brush.stroke(from, p)
    }

    private fun finishStroke() {
        drawing = false
        last = null
        if (drawTool == "lasso") {
            lasso.pointerUp()
        } else {
            val ov = brush.overlay
            if (ov != null && brush.hasStrokes) {
                val erase = drawTool == "eraser"
                core.bakeStroke(ov, erase)
            }
            brush.clear()
        }
    }

    // ------------------------------------------------------------------- crop ---
    fun startCrop(layerW: Int, layerH: Int) {
        resetView()
        cropLayerW = layerW
        cropLayerH = layerH
        val cw = Math.round(layerW * 0.8f)
        val ch = Math.round(layerH * 0.8f)
        val x = (layerW - cw) / 2f
        val y = (layerH - ch) / 2f
        crop = RectF(x, y, x + cw, y + ch)
        mode = Mode.CROP
    }

    fun cancelCrop() { crop = null; mode = Mode.NAVIGATE; invalidate() }

    /** Crop rectangle in layer pixels (x, y, w, h) or null. */
    fun cropResult(): IntArray? {
        val r = crop ?: return null
        return intArrayOf(Math.round(r.left), Math.round(r.top), Math.round(r.width()), Math.round(r.height()))
    }

    private fun cropTouch(e: MotionEvent): Boolean {
        val r = crop ?: return false
        val d = canvasDims()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val c = cropToCanvas(r, d)
                var hit: String? = null
                val tol = dp(26).toFloat()
                for (h in cropHandlePoints(c)) {
                    if (Math.hypot((h.second.x - e.x).toDouble(), (h.second.y - e.y).toDouble()) < tol) { hit = h.first; break }
                }
                if (hit == null) {
                    val ip = toImage(e.x, e.y)
                    if (ip.x >= c.left && ip.x <= c.right && ip.y >= c.top && ip.y <= c.bottom) hit = "move"
                }
                cropDrag = hit
                cropStart = RectF(r)
                cropStartPt = PointF(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                val mode = cropDrag ?: return true
                val a = toImage(cropStartPt.x, cropStartPt.y)
                val b = toImage(e.x, e.y)
                val sx = cropLayerW.toFloat() / d[0]
                val sy = cropLayerH.toFloat() / d[1]
                val dx = (b.x - a.x) * sx
                val dy = (b.y - a.y) * sy
                val s = cropStart
                val minSize = 20f
                val n = RectF(s)
                if (mode == "move") {
                    val nx = (s.left + dx).coerceIn(0f, cropLayerW - s.width())
                    val ny = (s.top + dy).coerceIn(0f, cropLayerH - s.height())
                    n.set(nx, ny, nx + s.width(), ny + s.height())
                } else {
                    if (mode.contains('w')) n.left = (s.left + dx).coerceIn(0f, s.right - minSize)
                    if (mode.contains('e')) n.right = (s.right + dx).coerceIn(s.left + minSize, cropLayerW.toFloat())
                    if (mode.contains('n')) n.top = (s.top + dy).coerceIn(0f, s.bottom - minSize)
                    if (mode.contains('s')) n.bottom = (s.bottom + dy).coerceIn(s.top + minSize, cropLayerH.toFloat())
                }
                crop = n
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cropDrag = null
        }
        return true
    }

    // ------------------------------------------------------------------ place ---
    fun startPlace(bitmap: Bitmap) {
        resetView()
        val d = canvasDims()
        val s = Math.min(d[0].toFloat() / bitmap.width, d[1].toFloat() / bitmap.height)
        place = PlaceState(bitmap, d[0] / 2f, d[1] / 2f, s, s)
        mode = Mode.PLACE
        invalidate()
    }

    fun endPlace() { place = null; mode = Mode.NAVIGATE; invalidate() }

    fun placeRotate(deg: Float) { place?.let { it.rotation += deg; invalidate() } }
    fun placeFlipH() { place?.let { it.flipH = !it.flipH; invalidate() } }
    fun placeFlipV() { place?.let { it.flipV = !it.flipV; invalidate() } }
    fun placeScale(f: Float) { place?.let { it.scaleX *= f; it.scaleY *= f; invalidate() } }

    private fun placeTouch(e: MotionEvent): Boolean {
        val pl = place ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                placeHandle = -1
                val corners = placeCorners(pl)
                for (i in 0..3) {
                    if (Math.hypot((corners[i].x - e.x).toDouble(), (corners[i].y - e.y).toDouble()) < dp(28)) { placeHandle = i; break }
                }
                placeDrag = true
                last = PointF(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                val l = last
                if (placeDrag && l != null) {
                    if (placeHandle >= 0) {
                        // uniform scale about the centre: ratio of pointer distance to centre
                        val c = toScreen(pl.cx, pl.cy)
                        val d0 = Math.hypot((l.x - c.x).toDouble(), (l.y - c.y).toDouble()).toFloat()
                        val d1 = Math.hypot((e.x - c.x).toDouble(), (e.y - c.y).toDouble()).toFloat()
                        if (d0 > 4f) { val f = d1 / d0; pl.scaleX *= f; pl.scaleY *= f }
                    } else {
                        val a = toImage(l.x, l.y)
                        val b = toImage(e.x, e.y)
                        pl.cx += b.x - a.x
                        pl.cy += b.y - a.y
                    }
                    last = PointF(e.x, e.y)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { placeDrag = false; placeHandle = -1; last = null }
        }
        return true
    }
}
