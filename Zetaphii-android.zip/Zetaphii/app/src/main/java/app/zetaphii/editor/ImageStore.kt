package app.zetaphii.editor

import android.graphics.Bitmap
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * Immutable-image cache (the native counterpart of imageCache in the original).
 * Every edit produces a NEW image id, so history entries can share images.
 * To keep memory bounded on 4 GB phones, least-recently-used bitmaps are spilled to
 * raw files in the cache directory and reloaded on demand.
 */
class ImageStore(private val spillDir: File, private val budgetBytes: Long) {
    private class Entry(val w: Int, val h: Int) {
        var bmp: Bitmap? = null
        var onDisk: Boolean = false
    }

    private val map = LinkedHashMap<String, Entry>(32, 0.75f, true)
    private var inMemory: Long = 0

    init {
        spillDir.mkdirs()
        // Spill files never survive a process restart (project PNGs are the durable copy).
        spillDir.listFiles()?.forEach { it.delete() }
    }

    private fun bytes(w: Int, h: Int): Long = w.toLong() * h.toLong() * 4L

    @Synchronized
    fun put(id: String, bmp: Bitmap) {
        val old = map.remove(id)
        if (old?.bmp != null) inMemory -= bytes(old.w, old.h)
        val e = Entry(bmp.width, bmp.height)
        e.bmp = bmp
        map[id] = e
        inMemory += bytes(e.w, e.h)
        evictIfNeeded(id)
    }

    @Synchronized
    fun has(id: String): Boolean = map.containsKey(id)

    @Synchronized
    fun size(id: String): IntArray? {
        val e = map[id] ?: return null
        return intArrayOf(e.w, e.h)
    }

    /** Returns the bitmap for [id], reloading it from the spill file if it was evicted. */
    @Synchronized
    fun get(id: String): Bitmap? {
        val e = map[id] ?: return null
        var b = e.bmp
        if (b == null) {
            b = readSpill(id, e) ?: return null
            e.bmp = b
            inMemory += bytes(e.w, e.h)
            evictIfNeeded(id)
        }
        return b
    }

    /** Drops every image whose id is not in [keep] (memory and spill files). */
    @Synchronized
    fun retainOnly(keep: Set<String>) {
        val it = map.entries.iterator()
        while (it.hasNext()) {
            val en = it.next()
            if (!keep.contains(en.key)) {
                if (en.value.bmp != null) inMemory -= bytes(en.value.w, en.value.h)
                spillFile(en.key).delete()
                it.remove()
            }
        }
    }

    @Synchronized
    fun clear() = retainOnly(emptySet())

    private fun evictIfNeeded(protectId: String) {
        if (inMemory <= budgetBytes) return
        val it = map.entries.iterator() // access order: eldest first
        while (it.hasNext() && inMemory > budgetBytes) {
            val en = it.next()
            if (en.key == protectId) continue
            val b = en.value.bmp ?: continue
            if (!en.value.onDisk) {
                if (!writeSpill(en.key, b)) continue
                en.value.onDisk = true
            }
            en.value.bmp = null
            inMemory -= bytes(en.value.w, en.value.h)
        }
    }

    private fun spillFile(id: String) = File(spillDir, "$id.raw")

    private fun writeSpill(id: String, b: Bitmap): Boolean {
        return try {
            RandomAccessFile(spillFile(id), "rw").use { raf ->
                val bb = ByteBuffer.allocateDirect(b.byteCount)
                b.copyPixelsToBuffer(bb)
                bb.rewind()
                val ch: FileChannel = raf.channel
                while (bb.hasRemaining()) ch.write(bb)
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun readSpill(id: String, e: Entry): Bitmap? {
        return try {
            val f = spillFile(id)
            if (!f.exists()) return null
            val b = Bitmap.createBitmap(e.w, e.h, Bitmap.Config.ARGB_8888)
            RandomAccessFile(f, "r").use { raf ->
                val bb = ByteBuffer.allocateDirect(b.byteCount)
                val ch = raf.channel
                while (bb.hasRemaining()) { if (ch.read(bb) < 0) break }
                bb.rewind()
                b.copyPixelsFromBuffer(bb)
            }
            b
        } catch (t: Throwable) {
            null
        }
    }
}
