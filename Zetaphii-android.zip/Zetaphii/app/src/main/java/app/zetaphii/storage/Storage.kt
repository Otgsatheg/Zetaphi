package app.zetaphii.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import app.zetaphii.model.AppSettings
import app.zetaphii.model.ManagerSnapshot
import app.zetaphii.model.ProjectRecord
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class ProjectMeta(val id: String, val name: String, val updatedAt: Long, val createdAt: Long, val thumb: File?)

/**
 * Projects are stored as  files/projects/<id>/project.json  +  images/<imageId>.png  (+ thumb.jpg).
 * project.json keeps the original ProjectRecord schema (id, name, updatedAt, createdAt, snapshot, imageIds).
 * Images are immutable (a new id per edit), so each PNG is written once.
 */
class ProjectStore(context: Context) {
    private val root = File(context.filesDir, "projects").also { it.mkdirs() }

    private fun dir(id: String) = File(root, id)
    private fun imagesDir(id: String) = File(dir(id), "images").also { it.mkdirs() }

    fun list(): List<ProjectMeta> {
        val out = ArrayList<ProjectMeta>()
        val dirs = root.listFiles() ?: return out
        for (d in dirs) {
            val pj = File(d, "project.json")
            if (!pj.isFile) continue
            try {
                val o = JSONObject(pj.readText())
                val th = File(d, "thumb.jpg")
                out.add(ProjectMeta(
                    o.optString("id", d.name), o.optString("name", "Untitled"),
                    o.optLong("updatedAt", 0L), o.optLong("createdAt", 0L), if (th.isFile) th else null
                ))
            } catch (t: Throwable) {
                // skip unreadable project
            }
        }
        out.sortByDescending { it.updatedAt }
        return out
    }

    fun load(id: String): ProjectRecord? {
        val pj = File(dir(id), "project.json")
        if (!pj.isFile) return null
        return try {
            val o = JSONObject(pj.readText())
            val ids = ArrayList<String>()
            val arr = o.optJSONArray("imageIds") ?: JSONArray()
            for (i in 0 until arr.length()) ids.add(arr.getString(i))
            ProjectRecord(
                o.optString("id", id), o.optString("name", "Untitled"),
                o.optLong("updatedAt", 0L), o.optLong("createdAt", 0L),
                ManagerSnapshot.fromJson(o.getJSONObject("snapshot")), ids
            )
        } catch (t: Throwable) {
            null
        }
    }

    fun hasImage(projectId: String, imageId: String): Boolean = File(imagesDir(projectId), "$imageId.png").isFile

    fun loadImage(projectId: String, imageId: String): Bitmap? {
        val f = File(imagesDir(projectId), "$imageId.png")
        if (!f.isFile) return null
        val opts = BitmapFactory.Options()
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888
        return try { BitmapFactory.decodeFile(f.absolutePath, opts) } catch (t: Throwable) { null }
    }

    /** Writes missing image PNGs, then the JSON (atomically), then prunes images no longer referenced. */
    @Synchronized
    fun save(rec: ProjectRecord, imageSource: (String) -> Bitmap?, thumb: Bitmap?, thumbQuality: Int = 85) {
        val imgs = imagesDir(rec.id)
        for (iid in rec.imageIds) {
            val f = File(imgs, "$iid.png")
            if (f.isFile) continue
            val b = imageSource(iid) ?: continue
            val tmp = File(imgs, "$iid.png.tmp")
            FileOutputStream(tmp).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            tmp.renameTo(f)
        }
        if (thumb != null) {
            val tf = File(dir(rec.id), "thumb.jpg")
            FileOutputStream(tf).use { thumb.compress(Bitmap.CompressFormat.JPEG, thumbQuality.coerceIn(1, 100), it) }
        }
        val o = JSONObject()
        o.put("id", rec.id); o.put("name", rec.name); o.put("updatedAt", rec.updatedAt)
        o.put("createdAt", rec.createdAt); o.put("snapshot", rec.snapshot.toJson())
        val arr = JSONArray(); for (i in rec.imageIds) arr.put(i); o.put("imageIds", arr)
        val tmp = File(dir(rec.id), "project.json.tmp")
        tmp.writeText(o.toString())
        val dst = File(dir(rec.id), "project.json")
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) }
        val keep = rec.imageIds.map { "$it.png" }.toSet()
        imgs.listFiles()?.forEach { if (!keep.contains(it.name)) it.delete() }
    }

    fun delete(id: String) { dir(id).deleteRecursively() }

    fun rename(id: String, name: String) {
        val rec = load(id) ?: return
        rec.name = name
        val o = JSONObject()
        o.put("id", rec.id); o.put("name", rec.name); o.put("updatedAt", System.currentTimeMillis())
        o.put("createdAt", rec.createdAt); o.put("snapshot", rec.snapshot.toJson())
        val arr = JSONArray(); for (i in rec.imageIds) arr.put(i); o.put("imageIds", arr)
        File(dir(id), "project.json").writeText(o.toString())
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("zetaphii", Context.MODE_PRIVATE)
    private val key = "zetaphii-settings"

    fun load(): AppSettings {
        val s = AppSettings()
        try {
            val raw = prefs.getString(key, null)
            if (raw != null) s.load(JSONObject(raw))
        } catch (t: Throwable) {
        }
        return s
    }

    fun save(s: AppSettings) {
        prefs.edit().putString(key, s.toJson().toString()).apply()
    }
}

object ImageCodec {
    enum class Format(val ext: String, val mime: String) {
        PNG("png", "image/png"), JPG("jpg", "image/jpeg"), WEBP("webp", "image/webp")
    }

    fun encode(bmp: Bitmap, fmt: Format, quality: Int, out: OutputStream): Boolean {
        val cf = when (fmt) {
            Format.PNG -> Bitmap.CompressFormat.PNG
            Format.JPG -> Bitmap.CompressFormat.JPEG
            Format.WEBP -> webpFormat()
        }
        return bmp.compress(cf, if (fmt == Format.PNG) 100 else quality.coerceIn(1, 100), out)
    }

    @Suppress("DEPRECATION")
    private fun webpFormat(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    /** Friendly filename: kebab-cased project name + dimensions (same scheme as the original). */
    fun fileName(projectName: String?, w: Int, h: Int, fmt: Format): String {
        var slug = (projectName ?: "zetaphii").lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
        if (slug.isEmpty()) slug = "zetaphii"
        return "$slug-${w}x$h.${fmt.ext}"
    }
}
