package app.zetaphii.editor

import android.graphics.Bitmap

/**
 * Kotlin face of the C++ pixel engine (libzetaphii_native.so, see app/src/main/cpp).
 * Bitmaps must be ARGB_8888, non-hardware, premultiplied (the Android default).
 * Calls return 0 on success and a negative value on error (-1 alloc, -2 bad args),
 * except where noted.
 */
object NativeEngine {
    const val LAYER_FLOATS = 20

    @Volatile
    var loaded: Boolean = false
        private set

    /** Loads the library once and runs the native self test. */
    fun ensureLoaded(): Boolean {
        if (!loaded) {
            try {
                System.loadLibrary("zetaphii_native")
                loaded = nativeSelfTest() == 0
            } catch (t: Throwable) {
                loaded = false
            }
        }
        return loaded
    }

    @JvmStatic external fun nativeSelfTest(): Int
    @JvmStatic external fun nativeComposite(layers: Array<Bitmap>, params: FloatArray, count: Int, out: Bitmap, blurScale: Float): Int
    @JvmStatic external fun nativeRenderSingle(layer: Bitmap, params: FloatArray, out: Bitmap, blurScale: Float): Int
    @JvmStatic external fun nativeResize(src: Bitmap, dst: Bitmap): Int
    @JvmStatic external fun nativeRotate90(src: Bitmap, dst: Bitmap, cw: Boolean): Int
    @JvmStatic external fun nativeFlip(src: Bitmap, dst: Bitmap, horizontal: Boolean): Int
    @JvmStatic external fun nativeCrop(src: Bitmap, dst: Bitmap, x: Int, y: Int): Int

    /** 1 = something selected afterwards, 0 = empty, negative = error. */
    @JvmStatic external fun nativeInvertMask(mask: Bitmap): Int

    /** 1 = found (outBox = x,y,w,h), 0 = nothing above the threshold, negative = error. */
    @JvmStatic external fun nativeAlphaBounds(bmp: Bitmap, thr: Int, outBox: IntArray): Int
    @JvmStatic external fun nativeDestinationIn(dst: Bitmap, mask: Bitmap): Int
    @JvmStatic external fun nativeDestinationOut(dst: Bitmap, src: Bitmap): Int
    @JvmStatic external fun nativeSourceOver(dst: Bitmap, src: Bitmap): Int
    @JvmStatic external fun nativeTintMask(dst: Bitmap, mask: Bitmap, r: Int, g: Int, b: Int, aScale: Int): Int
    @JvmStatic external fun nativeEffectRegion(snap: Bitmap, x0: Int, y0: Int, bw: Int, bh: Int, key: Int, p: Float, out: Bitmap): Int

    /** Effect-brush keys in the same order as the native EffectKey enum. */
    val EFFECT_KEYS: List<String> = listOf(
        "temperature", "exposure", "brightness", "contrast", "saturation", "hue",
        "invert", "posterize", "grain", "vignette", "pixelate", "blur"
    )
}
