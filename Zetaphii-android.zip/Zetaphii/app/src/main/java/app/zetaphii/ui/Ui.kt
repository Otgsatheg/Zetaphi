package app.zetaphii.ui

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** Colour tokens — values copied from the original CSS (:root, html[data-theme=light], html[data-theme=oled]). */
object Theme {
    var id: String = "dark"

    val accent = Color.parseColor("#0731A7")
    val accent2 = Color.parseColor("#7E549E")
    val accent3 = Color.parseColor("#B69573")
    val accentWarm = Color.parseColor("#BD690A")
    val danger = Color.parseColor("#C1443B")

    val bg: Int get() = pick("#000000", "#F4F4F6", "#000000")
    val bgSoft: Int get() = pick("#050505", "#ECECF0", "#000000")
    val surface: Int get() = pick("#0A0A0A", "#FFFFFF", "#050505")
    val surface2: Int get() = pick("#121212", "#F0F0F4", "#0C0C0C")
    val surface3: Int get() = pick("#1A1A1A", "#E4E4EA", "#141414")
    val border: Int get() = pick("#2E78787F", "#14000000", "#14FFFFFF")
    val borderStrong: Int get() = pick("#5278787F", "#29000000", "#29FFFFFF")
    val text: Int get() = pick("#E8E8EC", "#14141A", "#F2F2F5")
    val textDim: Int get() = pick("#9CA3AF", "#5C5C6A", "#A0A0AB")
    val accentStrong: Int get() = pick("#2A52C9", "#052A8F", "#2A52C9")
    val chrome: Int get() = pick("#121214", "#FAFAFC", "#080808")
    val sheet: Int get() = pick("#181614", "#F6F6FA", "#080808")
    val toast: Int get() = pick("#16161A", "#1C1C22", "#0A0A0C")
    val veil: Int get() = pick("#C7000000", "#CCF0F0F4", "#C7000000")

    private fun pick(dark: String, light: String, oled: String): Int =
        Color.parseColor(when (id) { "light" -> light; "oled" -> oled; else -> dark })
}

var uiTypeface: Typeface? = null

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun rounded(fill: Int, radiusPx: Float, stroke: Int = 0, strokePx: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = radiusPx
    if (strokePx > 0) g.setStroke(strokePx, stroke)
    return g
}

fun withRipple(ctx: Context, content: android.graphics.drawable.Drawable): android.graphics.drawable.Drawable {
    val rc = if (Theme.id == "light") Color.parseColor("#22000000") else Color.parseColor("#33FFFFFF")
    return RippleDrawable(ColorStateList.valueOf(rc), content, null)
}

fun Context.iconRes(name: String): Int {
    val snake = name.replace(Regex("([A-Z])")) { "_" + it.value.lowercase() }
    return resources.getIdentifier("ic_$snake", "drawable", packageName)
}

fun Context.iconView(name: String, sizeDp: Int = 22, tint: Int = Theme.text): ImageView {
    val v = ImageView(this)
    val id = iconRes(name)
    if (id != 0) v.setImageResource(id)
    v.imageTintList = ColorStateList.valueOf(tint)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    v.scaleType = ImageView.ScaleType.FIT_CENTER
    return v
}

fun Context.label(text: String, sp: Float = 14f, color: Int = Theme.text, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sp
    t.setTextColor(color)
    val tf = uiTypeface
    t.typeface = if (tf != null) Typeface.create(tf, if (bold) Typeface.BOLD else Typeface.NORMAL)
    else Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
    return t
}

/** Rounded text button. primary = accent fill. */
fun Context.button(text: String, primary: Boolean = false, danger: Boolean = false, onClick: () -> Unit): TextView {
    val t = label(text, 14f, if (primary || danger) Color.WHITE else Theme.text, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(10), dp(14), dp(10))
    val fill = if (danger) Theme.danger else if (primary) Theme.accent else Theme.surface2
    t.background = withRipple(this, rounded(fill, dpf(12f), Theme.border, dp(1)))
    t.setOnClickListener { onClick() }
    t.minHeight = dp(44)
    return t
}

/** Square icon-only button. */
fun Context.iconButton(icon: String, sizeDp: Int = 40, onClick: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    f.background = withRipple(this, rounded(Color.TRANSPARENT, dpf(12f)))
    val iv = iconView(icon, 22)
    iv.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
    iv.tag = "icon"
    f.addView(iv)
    f.setOnClickListener { onClick() }
    return f
}

fun FrameLayout.setIconTint(color: Int) {
    val iv = findViewWithTag<ImageView>("icon")
    iv?.imageTintList = ColorStateList.valueOf(color)
}

fun View.setEnabledLook(enabled: Boolean) {
    isEnabled = enabled
    alpha = if (enabled) 1f else 0.35f
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun Context.spacer(h: Int): View {
    val v = View(this)
    v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
    return v
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

/** Labelled slider with a live value box. [onChange] gets (value, committed); committed=true on release. */
class SliderRow(ctx: Context, title: String, private val min: Int, max: Int, value: Int,
                private val onChange: (Int, Boolean) -> Unit) : LinearLayout(ctx) {
    private val seek = SeekBar(ctx)
    private val valueLabel = ctx.label("", 13f, Theme.textDim)
    private var silent = false

    init {
        orientation = VERTICAL
        val top = ctx.hbox()
        val t = ctx.label(title, 13f, Theme.textDim)
        top.addView(t, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(valueLabel)
        addView(top)
        seek.max = max - min
        seek.progressTintList = ColorStateList.valueOf(Theme.accentStrong)
        seek.thumbTintList = ColorStateList.valueOf(Theme.accentStrong)
        addView(seek, lp(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(36)))
        set(value)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                valueLabel.text = (p + min).toString()
                if (fromUser && !silent) onChange(p + min, false)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { if (!silent) onChange(seek.progress + min, true) }
        })
    }

    fun set(v: Int) {
        silent = true
        seek.progress = (v - min).coerceIn(0, seek.max)
        valueLabel.text = v.toString()
        silent = false
    }

    fun value(): Int = seek.progress + min
}

/** Segmented control (format / theme / scope pickers). */
class Segmented(ctx: Context, options: List<String>, selected: Int, private val onSelect: (Int) -> Unit) : LinearLayout(ctx) {
    private val cells = ArrayList<TextView>()
    var index = selected
        private set

    init {
        orientation = HORIZONTAL
        background = rounded(Theme.surface2, ctx.dpf(12f), Theme.border, ctx.dp(1))
        setPadding(ctx.dp(3), ctx.dp(3), ctx.dp(3), ctx.dp(3))
        for ((i, o) in options.withIndex()) {
            val t = ctx.label(o, 13f, Theme.text, true)
            t.gravity = Gravity.CENTER
            t.setPadding(ctx.dp(8), ctx.dp(9), ctx.dp(8), ctx.dp(9))
            t.setOnClickListener { select(i, true) }
            cells.add(t)
            addView(t, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        paint()
    }

    fun select(i: Int, notify: Boolean) {
        index = i
        paint()
        if (notify) onSelect(i)
    }

    private fun paint() {
        for ((i, t) in cells.withIndex()) {
            val on = i == index
            t.background = rounded(if (on) Theme.accent else Color.TRANSPARENT, context.dpf(9f))
            t.setTextColor(if (on) Color.WHITE else Theme.textDim)
        }
    }
}

fun Context.textField(initial: String, multiline: Boolean = false, numeric: Boolean = false): EditText {
    val e = EditText(this)
    e.setText(initial)
    e.setTextColor(Theme.text)
    e.setHintTextColor(Theme.textDim)
    e.textSize = 15f
    e.background = rounded(Theme.surface2, dpf(10f), Theme.border, dp(1))
    e.setPadding(dp(12), dp(10), dp(12), dp(10))
    e.inputType = when {
        numeric -> InputType.TYPE_CLASS_NUMBER
        multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        else -> InputType.TYPE_CLASS_TEXT
    }
    if (!multiline) e.setSingleLine(true)
    return e
}

/** Bottom sheet (the original's slide-up sheets) as a dialog with a scrollable content column. */
class Sheet(private val ctx: Context, title: String) {
    val dialog = Dialog(ctx)
    val body: LinearLayout = ctx.vbox()

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val outer = ctx.vbox()
        outer.background = rounded(Theme.sheet, ctx.dpf(22f))
        outer.setPadding(ctx.dp(18), ctx.dp(16), ctx.dp(18), ctx.dp(16))
        val t = ctx.label(title, 18f, Theme.text, true)
        outer.addView(t)
        outer.addView(ctx.spacer(10))
        val sv = ScrollView(ctx)
        body.setPadding(0, 0, 0, ctx.dp(8))
        sv.addView(body, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        outer.addView(sv, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(outer)
        val w = dialog.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            w.setDimAmount(0.55f)
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
    }

    fun add(v: View, topMarginDp: Int = 10): Sheet {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = ctx.dp(topMarginDp)
        body.addView(v, p)
        return this
    }

    fun show(): Sheet { dialog.show(); return this }
    fun dismiss() { dialog.dismiss() }
}
