package app.zetaphii.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import app.zetaphii.model.AppSettings
import app.zetaphii.model.Layer
import app.zetaphii.model.LayerKind
import app.zetaphii.model.ManagerSnapshot
import app.zetaphii.model.Params
import app.zetaphii.model.ProjectRecord
import app.zetaphii.model.TextProps
import app.zetaphii.model.newId
import app.zetaphii.storage.ProjectStore
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** UI callbacks. All are invoked on the main thread. */
interface EditorListener {
    fun onLayersChanged() {}
    fun onFrameReady() {}
    fun onToast(msg: String) {}
    fun onBusy(busy: Boolean) {}
    fun onHistoryChanged() {}
    fun onCanvasSizeChanged() {}
    fun onSaveState(state: String) {}
}

/**
 * Port of the original global editor state: layer stack, selection mask, history, renderer driver,
 * transforms, fills and project persistence. Pixels are handled by the C++ engine through [NativeEngine].
 */
class EditorCore(
    val store: ImageStore,
    private val projects: ProjectStore,
    val settings: AppSettings
) {
    companion object {
        /** Interactive preview is rendered at most this many pixels on the long side (export is always native). */
        const val PREVIEW_MAX = 2048

        /** While a slider is being dragged the preview is rendered smaller for responsiveness, then re-rendered sharp on release. */
        const val INTERACTIVE_MAX = 1024
        const val DEFAULT_CANVAS = 1080
    }

    private val main = Handler(Looper.getMainLooper())
    val listeners = ArrayList<EditorListener>()

    val layers = ArrayList<Layer>()
    var selectedId: String? = null
    var projectId: String? = null
    var projectName: String = "Untitled"
    private var createdAt: Long = System.currentTimeMillis()

    val history = History(60)

    /** Lasso selection (premultiplied white where selected), canvas sized; null = nothing selected. */
    var selectionId: String? = null
        private set
    var hasSelection: Boolean = false
        private set

    // ------------------------------------------------------------------ events ---
    private inline fun emit(f: (EditorListener) -> Unit) {
        for (l in ArrayList(listeners)) f(l)
    }

    fun toast(msg: String) = main.post { emit { it.onToast(msg) } }
    fun busy(b: Boolean) = main.post { emit { it.onBusy(b) } }

    fun selected(): Layer? = layers.firstOrNull { it.id == selectedId }
    fun layerById(id: String): Layer? = layers.firstOrNull { it.id == id }

    /** Canvas size = size of the first (bottom) layer, as in the original fitCanvasToLayers. */
    fun canvasSize(): IntArray? {
        val base = layers.firstOrNull() ?: return null
        return store.size(base.imageId)
    }

    // ------------------------------------------------------------- rendering ---
    private val renderExec = Executors.newSingleThreadExecutor()
    private val renderGen = AtomicInteger(0)
    private val frames = arrayOfNulls<Bitmap>(3)
    private var frameRot = 0

    @Volatile
    var frame: Bitmap? = null
        private set

    @Volatile
    private var interactive = false

    private class Job(val bitmaps: Array<Bitmap>, val params: FloatArray, val outW: Int, val outH: Int, val blurScale: Float, val count: Int)

    fun layerFloats(l: Layer, out: FloatArray, off: Int) {
        out[off + NativeEngine_LF.VISIBLE] = if (l.visible) 1f else 0f
        out[off + NativeEngine_LF.BLEND] = l.blendMode.toFloat()
        val keys = Params.defs
        for (d in keys) {
            val v = d.toShader(l.param(d.key)).toFloat()
            val idx = NativeEngine_LF.indexOf(d.key)
            if (idx >= 0) out[off + idx] = v
        }
    }

    private fun buildJob(): Job? {
        val size = canvasSize() ?: return null
        val vis = layers.filter { it.visible }
        val bmps = ArrayList<Bitmap>()
        val fl = FloatArray(Math.max(1, vis.size) * NativeEngine.LAYER_FLOATS)
        for (l in vis) {
            val b = store.get(l.imageId) ?: continue
            layerFloats(l, fl, bmps.size * NativeEngine.LAYER_FLOATS)
            bmps.add(b)
        }
        val cap = if (interactive) INTERACTIVE_MAX else PREVIEW_MAX
        val s = Math.min(1.0, cap.toDouble() / Math.max(size[0], size[1]))
        val ow = Math.max(1, Math.round(size[0] * s).toInt())
        val oh = Math.max(1, Math.round(size[1] * s).toInt())
        return Job(bmps.toTypedArray(), fl, ow, oh, (ow.toFloat() / size[0]), bmps.size)
    }

    /** Coalescing render request: only the newest request is rendered (like requestAnimationFrame). */
    fun requestRender() {
        val job = buildJob()
        val gen = renderGen.incrementAndGet()
        if (job == null) {
            frame = null
            main.post { emit { it.onFrameReady() } }
            return
        }
        renderExec.execute {
            if (gen != renderGen.get()) return@execute
            frameRot = (frameRot + 1) % frames.size
            var f = frames[frameRot]
            if (f == null || f.width != job.outW || f.height != job.outH) {
                f = Bitmap.createBitmap(job.outW, job.outH, Bitmap.Config.ARGB_8888)
                frames[frameRot] = f
            }
            val rc = NativeEngine.nativeComposite(job.bitmaps, job.params, job.count, f!!, job.blurScale)
            if (rc != 0) {
                toast("Render failed ($rc)")
                return@execute
            }
            if (gen != renderGen.get()) return@execute
            main.post {
                frame = f
                emit { it.onFrameReady() }
            }
        }
    }

    /** Full-resolution render for export (blocking; call off the main thread). */
    fun renderFull(): Bitmap? {
        val size = canvasSize() ?: return null
        val vis = layers.filter { it.visible }
        val bmps = ArrayList<Bitmap>()
        val fl = FloatArray(Math.max(1, vis.size) * NativeEngine.LAYER_FLOATS)
        for (l in vis) {
            val b = store.get(l.imageId) ?: continue
            layerFloats(l, fl, bmps.size * NativeEngine.LAYER_FLOATS)
            bmps.add(b)
        }
        val out = try {
            Bitmap.createBitmap(size[0], size[1], Bitmap.Config.ARGB_8888)
        } catch (t: OutOfMemoryError) {
            return null
        }
        val rc = NativeEngine.nativeComposite(bmps.toTypedArray(), fl, bmps.size, out, 1f)
        return if (rc == 0) out else null
    }

    // ---------------------------------------------------------------- history ---
    fun snapshot(): ManagerSnapshot = ManagerSnapshot(selectedId, layers.map { it.toSnapshot() })

    fun commitHistory() {
        if (interactive) { interactive = false; requestRender() }
        history.maxSteps = settings.historySteps
        history.push(snapshot(), selectionId)
        store.retainOnly(history.referencedImageIds() + liveImageIds())
        main.post { emit { it.onHistoryChanged() } }
        scheduleAutosave()
    }

    fun resetHistory() {
        history.reset(snapshot(), selectionId)
        main.post { emit { it.onHistoryChanged() } }
    }

    private fun liveImageIds(): Set<String> {
        val s = HashSet<String>()
        for (l in layers) s.add(l.imageId)
        selectionId?.let { s.add(it) }
        return s
    }

    private fun restore(e: History.Entry) {
        layers.clear()
        for (ls in e.snap.layers) layers.add(Layer.fromSnapshot(ls))
        selectedId = e.snap.selectedId ?: layers.lastOrNull()?.id
        selectionId = e.selectionId
        hasSelection = e.selectionId != null
        main.post {
            emit { it.onLayersChanged() }
            emit { it.onCanvasSizeChanged() }
            emit { it.onHistoryChanged() }
        }
        requestRender()
        scheduleAutosave()
    }

    fun undo() { history.undo()?.let { restore(it) } }
    fun redo() { history.redo()?.let { restore(it) } }
    fun canUndo() = history.canUndo()
    fun canRedo() = history.canRedo()

    // ---------------------------------------------------------------- layers ---
    private fun notifyLayers() = main.post { emit { it.onLayersChanged() } }

    fun newBitmap(w: Int, h: Int): Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    /** Registers [bmp] as a new immutable image and returns its id. */
    fun registerImage(bmp: Bitmap): String {
        val id = newId()
        store.put(id, bmp)
        return id
    }

    fun addLayer(bmp: Bitmap, name: String, kind: LayerKind = LayerKind.RASTER): Layer {
        val l = Layer(newId(), registerImage(bmp), name)
        l.kind = kind
        layers.add(l)
        selectedId = l.id
        return l
    }

    /** Creates a transparent canvas layer (first layer defines the canvas size). */
    fun createBlankCanvas(w: Int, h: Int, silent: Boolean = false) {
        val cw = w.coerceIn(1, 8192)
        val ch = h.coerceIn(1, 8192)
        val wasEmpty = layers.isEmpty()
        layers.clear()
        selectedId = null
        clearSelectionSilently()
        addLayer(newBitmap(cw, ch), "Canvas")
        notifyLayers()
        main.post { emit { it.onCanvasSizeChanged() } }
        requestRender()
        if (wasEmpty) {
            // The very first canvas is the document: undo must not be able to remove it ("protect this blank canvas").
            resetHistory()
            scheduleAutosave()
        } else commitHistory()
        if (!silent) toast("Blank canvas ${cw}×$ch")
    }

    fun ensureDrawableLayer(): Layer? {
        if (layers.isEmpty()) createBlankCanvas(settings.defaultCanvasW, settings.defaultCanvasH, true)
        if (selected() == null && layers.isNotEmpty()) selectedId = layers.last().id
        return selected()
    }

    fun addEmptyLayer() {
        ensureDrawableLayer()
        val d = canvasSize() ?: return
        addLayer(newBitmap(d[0], d[1]), "Layer")
        notifyLayers(); requestRender(); commitHistory()
    }

    fun selectLayer(id: String) {
        if (layerById(id) == null) return
        selectedId = id
        notifyLayers()
    }

    fun toggleVisible(id: String) {
        val l = layerById(id) ?: return
        l.visible = !l.visible
        notifyLayers(); requestRender(); commitHistory()
    }

    fun removeLayer(id: String): Boolean {
        val idx = layers.indexOfFirst { it.id == id }
        if (idx < 0 || layers.size <= 1) return false
        layers.removeAt(idx)
        if (selectedId == id) selectedId = layers[Math.min(idx, layers.size - 1)].id
        notifyLayers(); main.post { emit { it.onCanvasSizeChanged() } }; requestRender(); commitHistory()
        return true
    }

    fun duplicateLayer(id: String) {
        val src = layerById(id) ?: return
        val copy = Layer(newId(), src.imageId, src.name + " copy")
        copy.kind = src.kind; copy.textProps = src.textProps?.copy()
        copy.blendMode = src.blendMode; copy.visible = src.visible
        copy.params = LinkedHashMap(src.params)
        layers.add(layers.indexOf(src) + 1, copy)
        selectedId = copy.id
        notifyLayers(); requestRender(); commitHistory()
    }

    /** Moves a layer by [delta] positions in the stack (+1 = towards the top). */
    fun moveLayer(id: String, delta: Int) {
        val idx = layers.indexOfFirst { it.id == id }
        val to = idx + delta
        if (idx < 0 || to < 0 || to >= layers.size) return
        val l = layers.removeAt(idx)
        layers.add(to, l)
        notifyLayers(); main.post { emit { it.onCanvasSizeChanged() } }; requestRender(); commitHistory()
    }

    fun renameLayer(id: String, name: String) {
        val l = layerById(id) ?: return
        l.name = name.ifBlank { l.name }
        notifyLayers(); commitHistory()
    }

    fun setBlend(id: String, mode: Int) {
        val l = layerById(id) ?: return
        l.blendMode = mode
        notifyLayers(); requestRender(); commitHistory()
    }

    /** Live slider change (no history entry until [commitHistory]). */
    fun setParam(id: String, key: String, value: Double) {
        val l = layerById(id) ?: return
        l.params[key] = value
        interactive = true
        requestRender()
    }

    fun resetParams(id: String) {
        val l = layerById(id) ?: return
        l.params = Params.defaults()
        notifyLayers(); requestRender(); commitHistory()
    }

    // ------------------------------------------------------------ bake pixels ---
    /** "Bake into layer pixels": renders the layer's own blur/adjustments into its bitmap and resets them. */
    fun bakeIntoPixels(scopeAll: Boolean) {
        val targets = if (scopeAll) ArrayList(layers) else listOfNotNull(selected())
        if (targets.isEmpty()) { toast("Select a layer first"); return }
        busy(true)
        renderExec.execute {
            val results = ArrayList<Pair<Layer, Bitmap>>()
            try {
                for (l in targets) {
                    val untouched = l.params.entries.all { e -> e.value == (Params.byKey[e.key]?.def?.toDouble() ?: e.value) }
                    if (untouched) continue
                    val fl = FloatArray(NativeEngine.LAYER_FLOATS)
                    layerFloats(l, fl, 0)
                    val src = store.get(l.imageId) ?: continue
                    val out = newBitmap(src.width, src.height)
                    if (NativeEngine.nativeRenderSingle(src, fl, out, 1f) != 0) continue
                    results.add(Pair(l, out))
                }
            } catch (t: OutOfMemoryError) {
                // fall through with whatever finished
            }
            main.post {
                busy(false)
                // Image registration and layer edits happen on the main thread (the image store is pruned there).
                for (r in results) {
                    val l = r.first
                    l.imageId = registerImage(r.second)
                    l.params = Params.defaults()
                    if (l.kind == LayerKind.TEXT) { l.kind = LayerKind.RASTER; l.textProps = null }
                }
                notifyLayers(); requestRender()
                if (results.isNotEmpty()) {
                    commitHistory()
                    toast("Baked " + results.size + " layer" + (if (results.size == 1) "" else "s"))
                } else toast("Nothing to bake")
            }
        }
    }

    // -------------------------------------------------------------- transforms ---
    /** transformSelectedLayer: runs [fn] on the selected layer's bitmap and commits a new image. */
    fun transformSelected(label: String, fn: (Bitmap) -> Bitmap?) {
        val l = selected()
        if (l == null) { toast("Select a layer first"); return }
        val src = store.get(l.imageId)
        if (src == null) { toast("No image data"); return }
        busy(true)
        renderExec.execute {
            var result: Bitmap? = null
            try {
                result = fn(src)
            } catch (t: OutOfMemoryError) {
                result = null
            }
            val out = result
            main.post {
                busy(false)
                if (out != null) {
                    l.imageId = registerImage(out)
                    if (l.kind == LayerKind.TEXT) { l.kind = LayerKind.RASTER; l.textProps = null }
                    notifyLayers(); emit { it.onCanvasSizeChanged() }; requestRender(); commitHistory()
                    toast(label)
                } else toast("Transform failed")
            }
        }
    }

    fun rotate90(cw: Boolean) = transformSelected("Transform applied") { src ->
        val out = newBitmap(src.height, src.width)
        if (NativeEngine.nativeRotate90(src, out, cw) == 0) out else null
    }

    fun flip(horizontal: Boolean) = transformSelected("Transform applied") { src ->
        val out = newBitmap(src.width, src.height)
        if (NativeEngine.nativeFlip(src, out, horizontal) == 0) out else null
    }

    fun resizeSelected(w: Int, h: Int) {
        if (w < 1 || h < 1) { toast("Enter valid dimensions"); return }
        if (w.toLong() * h > 64_000_000L) { toast("Too many pixels for this device"); return }
        transformSelected("Transform applied") { src ->
            val out = newBitmap(w, h)
            if (NativeEngine.nativeResize(src, out) == 0) out else null
        }
    }

    fun cropSelected(x: Int, y: Int, w: Int, h: Int) = transformSelected("Transform applied") { src ->
        val cx = x.coerceIn(0, src.width - 1)
        val cy = y.coerceIn(0, src.height - 1)
        val cw = w.coerceIn(1, src.width - cx)
        val ch = h.coerceIn(1, src.height - cy)
        val out = newBitmap(cw, ch)
        if (NativeEngine.nativeCrop(src, out, cx, cy) == 0) out else null
    }

    // --------------------------------------------------------------- selection ---
    private fun clearSelectionSilently() { selectionId = null; hasSelection = false }

    /** Returns a mutable copy of the selection mask (or a new empty one) sized to the canvas. */
    fun selectionBitmapForEdit(): Bitmap? {
        val size = canvasSize() ?: return null
        val cur = selectionId?.let { store.get(it) }
        val out = newBitmap(size[0], size[1])
        if (cur != null) {
            val c = Canvas(out)
            c.drawBitmap(cur, null, android.graphics.Rect(0, 0, size[0], size[1]), null)
        }
        return out
    }

    fun selectionBitmap(): Bitmap? = if (hasSelection) selectionId?.let { store.get(it) } else null

    fun setSelection(mask: Bitmap, nonEmpty: Boolean) {
        selectionId = registerImage(mask)
        hasSelection = nonEmpty
        commitHistory()
    }

    fun clearSelection() {
        if (!hasSelection) { toast("Selection cleared"); return }
        val size = canvasSize()
        if (size != null) { selectionId = registerImage(newBitmap(size[0], size[1])) }
        hasSelection = false
        commitHistory()
        toast("Selection cleared")
    }

    fun invertSelection() {
        val m = selectionBitmapForEdit() ?: return
        val rc = NativeEngine.nativeInvertMask(m)
        selectionId = registerImage(m)
        hasSelection = rc == 1
        commitHistory()
        toast("Selection inverted")
    }

    /** commitSelectionToMask: paints the selection into the permanent Mask layer (blue, 55% alpha). */
    fun commitSelectionToMask() {
        val sel = selectionBitmap()
        val size = canvasSize()
        if (sel == null || size == null) { toast("Nothing selected"); return }
        val out = newBitmap(size[0], size[1])
        out.eraseColor(Color.argb((0.55f * 255).toInt(), 7, 49, 167))
        NativeEngine.nativeDestinationIn(out, sel)
        var mask = layers.firstOrNull { it.kind == LayerKind.MASK }
        if (mask == null) {
            val m = Layer(newId(), registerImage(out), "Mask")
            m.kind = LayerKind.MASK
            layers.add(0, m)
            mask = m
        } else {
            mask.imageId = registerImage(out)
        }
        selectedId = mask.id
        notifyLayers(); requestRender(); commitHistory()
        toast("Applied to Mask layer")
    }

    // ------------------------------------------------------------------- fills ---
    /** Draws a fill onto the selected layer, clipped to the selection (Photoshop behaviour). */
    fun applyFill(label: String, draw: (Canvas, Int, Int) -> Boolean) {
        val l = ensureDrawableLayer()
        if (l == null) { toast("Select a layer first"); return }
        val src = store.get(l.imageId)
        if (src == null) { toast("No image data"); return }
        val sel = selectionBitmap()
        busy(true)
        renderExec.execute {
            var result: Bitmap? = null
            try {
                val w = src.width
                val h = src.height
                val fill = newBitmap(w, h)
                if (draw(Canvas(fill), w, h)) {
                    if (sel != null) {
                        val m = if (sel.width == w && sel.height == h) sel else Bitmap.createScaledBitmap(sel, w, h, true)
                        NativeEngine.nativeDestinationIn(fill, m)
                    }
                    val out = newBitmap(w, h)
                    val c = Canvas(out)
                    c.drawBitmap(src, 0f, 0f, null)
                    c.drawBitmap(fill, 0f, 0f, null)
                    result = out
                }
            } catch (t: OutOfMemoryError) {
                result = null
            }
            val out = result
            main.post {
                busy(false)
                if (out != null) {
                    l.imageId = registerImage(out)
                    if (l.kind == LayerKind.TEXT) { l.kind = LayerKind.RASTER; l.textProps = null }
                    notifyLayers(); requestRender(); commitHistory(); toast(label)
                }
            }
        }
    }

    fun fillSolid(color: Int, opacityPct: Int) = applyFill("Fill applied") { c, w, h ->
        val p = Paint()
        p.color = color
        p.alpha = (opacityPct.coerceIn(0, 100) * 255 / 100)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        true
    }

    fun fillGradient(c1: Int, c2: Int, radial: Boolean, angleDeg: Double, reverse: Boolean, opacityPct: Int) =
        applyFill("Gradient applied") { c, w, h ->
            val a = if (reverse) c2 else c1
            val b = if (reverse) c1 else c2
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val len = Math.hypot(w.toDouble(), h.toDouble()) / 2.0
            p.shader = if (radial) {
                RadialGradient(w / 2f, h / 2f, len.toFloat(), a, b, Shader.TileMode.CLAMP)
            } else {
                val rad = Math.toRadians(angleDeg)
                val cx = w / 2.0
                val cy = h / 2.0
                LinearGradient(
                    (cx - Math.cos(rad) * len).toFloat(), (cy - Math.sin(rad) * len).toFloat(),
                    (cx + Math.cos(rad) * len).toFloat(), (cy + Math.sin(rad) * len).toFloat(),
                    a, b, Shader.TileMode.CLAMP
                )
            }
            p.alpha = (opacityPct.coerceIn(0, 100) * 255 / 100)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            true
        }

    fun fillPattern(tile: Bitmap, scalePct: Int, opacityPct: Int) = applyFill("Pattern applied") { c, w, h ->
        val s = scalePct.coerceIn(10, 800) / 100f
        val p = Paint()
        p.shader = android.graphics.BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        p.alpha = (opacityPct.coerceIn(0, 100) * 255 / 100)
        c.save()
        c.scale(s, s)
        c.drawRect(0f, 0f, Math.ceil(w / s.toDouble()).toFloat(), Math.ceil(h / s.toDouble()).toFloat(), p)
        c.restore()
        true
    }

    // ------------------------------------------------------------ place image ---
    /**
     * Bakes a placed picture (move/scale/rotate/flip from place mode) into a new full-canvas "Image" layer.
     * With no layers yet, a square canvas of clamp(longest side, 1080..2048) is created first (like the original).
     */
    fun addPlacedImage(piece: Bitmap, cx: Float, cy: Float, sx: Float, sy: Float, rotDeg: Float, flipH: Boolean, flipV: Boolean) {
        val size = canvasSize()
        if (size == null) {
            val dim = Math.max(piece.width, piece.height).coerceIn(1080, 2048)
            createBlankCanvas(dim, dim, true)
        }
        val d = canvasSize() ?: return
        val out = newBitmap(d[0], d[1])
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        c.translate(cx, cy)
        c.rotate(rotDeg)
        c.scale(sx * (if (flipH) -1f else 1f), sy * (if (flipV) -1f else 1f))
        c.drawBitmap(piece, -piece.width / 2f, -piece.height / 2f, p)
        addLayer(out, "Image")
        notifyLayers(); requestRender(); commitHistory()
        toast("Image placed")
    }

    // -------------------------------------------------------------------- text ---
    fun addTextLayer(content: String?) {
        ensureDrawableLayer()
        val size = canvasSize() ?: return
        val props = TextProps()
        if (!content.isNullOrEmpty()) props.content = content
        val l = addLayer(TextRaster.rasterize(props, size[0], size[1]), "Text", LayerKind.TEXT)
        l.textProps = props
        notifyLayers(); requestRender(); commitHistory()
        toast("Text layer added")
    }

    /** Re-rasterizes a text layer after its properties changed. */
    fun updateTextLayer(id: String, props: TextProps) {
        val l = layerById(id) ?: return
        val size = canvasSize() ?: return
        l.textProps = props
        l.imageId = registerImage(TextRaster.rasterize(props, size[0], size[1]))
        val first = props.content.split("\n").firstOrNull()?.trim().orEmpty()
        if (first.isNotEmpty()) l.name = if (first.length > 18) first.substring(0, 18) + "…" else first
        notifyLayers(); requestRender(); commitHistory()
    }

    // ------------------------------------------------------- stroke baking ---
    /**
     * Bakes a finished stroke overlay (full canvas size, premultiplied) into the selected layer.
     * erase = true punches the stroke out of the layer (canvas 'destination-out').
     */
    fun bakeStroke(overlay: Bitmap, erase: Boolean) {
        val l = ensureDrawableLayer() ?: return
        val src = store.get(l.imageId) ?: return
        val out = src.copy(Bitmap.Config.ARGB_8888, true) ?: return
        var stroke = overlay
        if (stroke.width != out.width || stroke.height != out.height) {
            stroke = Bitmap.createScaledBitmap(overlay, out.width, out.height, true)
        }
        val sel = selectionBitmap()
        if (sel != null) {
            val m = if (sel.width == stroke.width && sel.height == stroke.height) sel else Bitmap.createScaledBitmap(sel, stroke.width, stroke.height, true)
            if (stroke === overlay) stroke = overlay.copy(Bitmap.Config.ARGB_8888, true) ?: overlay
            NativeEngine.nativeDestinationIn(stroke, m)
        }
        if (erase) NativeEngine.nativeDestinationOut(out, stroke) else NativeEngine.nativeSourceOver(out, stroke)
        if (l.kind == LayerKind.TEXT) { l.kind = LayerKind.RASTER; l.textProps = null }
        l.imageId = registerImage(out)
        notifyLayers(); requestRender(); commitHistory()
    }

    // -------------------------------------------------------------- persistence ---
    private var autosaveRunnable: Runnable? = null
    private val saveExec = Executors.newSingleThreadExecutor()

    fun scheduleAutosave() {
        if (projectId == null || layers.isEmpty()) return
        emit { it.onSaveState("dirty") }
        autosaveRunnable?.let { main.removeCallbacks(it) }
        val r = Runnable { saveNow() }
        autosaveRunnable = r
        main.postDelayed(r, settings.autosaveMs.toLong())
    }

    fun saveNow() {
        val pid = projectId ?: return
        if (layers.isEmpty()) return
        autosaveRunnable?.let { main.removeCallbacks(it) }
        val snap = snapshot()
        val rec = ProjectRecord(pid, projectName, System.currentTimeMillis(), createdAt, snap, snap.imageIds())
        // Grab the bitmaps that still need writing NOW (main thread) so cache pruning can't race the background save.
        val pending = HashMap<String, Bitmap>()
        for (iid in rec.imageIds) {
            if (!projects.hasImage(pid, iid)) {
                val b = store.get(iid)
                if (b != null) pending[iid] = b
            }
        }
        val f = frame
        val thumbBase = if (f != null && !f.isRecycled) f else null
        val thumbSize = settings.thumbSize.coerceIn(32, 512)
        val thumbQuality = (settings.thumbQuality * 100).toInt()
        emit { it.onSaveState("saving") }
        saveExec.execute {
            try {
                var thumb: Bitmap? = null
                if (thumbBase != null) {
                    val sc = thumbSize.toFloat() / Math.max(thumbBase.width, thumbBase.height)
                    thumb = Bitmap.createScaledBitmap(thumbBase, Math.max(1, (thumbBase.width * sc).toInt()), Math.max(1, (thumbBase.height * sc).toInt()), true)
                }
                projects.save(rec, { id -> pending[id] }, thumb, thumbQuality)
                main.post { emit { it.onSaveState("saved") } }
            } catch (t: Throwable) {
                main.post { emit { it.onSaveState("dirty") }; toast("Autosave failed") }
            }
        }
    }

    fun newProject(name: String): String {
        val id = newId()
        projectId = id
        projectName = name
        createdAt = System.currentTimeMillis()
        layers.clear(); selectedId = null; clearSelectionSilently()
        store.clear()
        history.reset(snapshot(), null)
        return id
    }

    fun openProject(id: String): Boolean {
        val rec = projects.load(id) ?: return false
        store.clear()
        layers.clear(); clearSelectionSilently()
        for (ls in rec.snapshot.layers) {
            if (!store.has(ls.imageId)) {
                val b = projects.loadImage(id, ls.imageId)
                if (b != null) store.put(ls.imageId, b)
            }
            layers.add(Layer.fromSnapshot(ls))
        }
        projectId = rec.id
        projectName = rec.name
        createdAt = rec.createdAt
        selectedId = rec.snapshot.selectedId ?: layers.lastOrNull()?.id
        resetHistory()
        notifyLayers()
        main.post { emit { it.onCanvasSizeChanged() } }
        requestRender()
        return true
    }

    fun closeProject() {
        saveNow()
        main.removeCallbacksAndMessages(null)
    }
}

/** Index of each shader-space value inside the 20-float block the native engine expects. */
object NativeEngine_LF {
    const val VISIBLE = 0
    const val BLEND = 1
    private val order = mapOf(
        "blur" to 2, "brightness" to 3, "contrast" to 4, "saturation" to 5, "vibrance" to 6,
        "exposure" to 7, "highlights" to 8, "shadows" to 9, "temperature" to 10, "tint" to 11,
        "sharpness" to 12, "opacity" to 13, "posterize" to 14, "pixelate" to 15, "grain" to 16,
        "vignette" to 17, "invert" to 18, "hue" to 19
    )

    fun indexOf(key: String): Int = order[key] ?: -1
}
