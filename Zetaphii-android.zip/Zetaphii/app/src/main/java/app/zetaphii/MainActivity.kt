package app.zetaphii

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import app.zetaphii.editor.EditorCore
import app.zetaphii.editor.ImageLoader
import app.zetaphii.ui.EditorHost
import app.zetaphii.ui.EditorScreen
import app.zetaphii.ui.ProjectsHost
import app.zetaphii.ui.ProjectsScreen
import app.zetaphii.ui.Theme
import app.zetaphii.ui.splashView
import java.io.OutputStream
import java.util.concurrent.Executors

/** Single activity: splash → projects page ⇄ editor. No AndroidX dependency (plain Activity). */
class MainActivity : Activity(), EditorHost, ProjectsHost {
    private val app get() = application as ZetaApp
    private val core: EditorCore get() = app.core
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var container: FrameLayout
    private var projectsScreen: ProjectsScreen? = null
    private var editorScreen: EditorScreen? = null
    private var page = "projects"
    private var pendingWrite: ((OutputStream) -> Unit)? = null
    private var pendingImageForEditor: Bitmap? = null

    private val REQ_PICK = 11
    private val REQ_SAVE = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        container = FrameLayout(this)
        setContentView(container, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (!app.nativeOk) Toast.makeText(this, "Native engine failed to load", Toast.LENGTH_LONG).show()
        page = if (core.projectId != null && core.layers.isNotEmpty()) "editor" else "projects"
        container.addView(splashView(this))
        main.postDelayed({ showPage() }, 700)
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    /** Share/open an image into Zetaphii (the mobile counterpart of the web app's paste / drag-and-drop). */
    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_SEND -> streamUri(i)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri == null) return
        io.execute {
            val bmp = ImageLoader.decode(this, uri)
            main.post {
                if (bmp == null) { Toast.makeText(this, "Couldn't open image", Toast.LENGTH_SHORT).show(); return@post }
                pendingImageForEditor = bmp
                if (core.projectId == null) newProject() else { page = "editor"; showPage() }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun streamUri(i: Intent): Uri? = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    private fun showPage() {
        container.removeAllViews()
        projectsScreen = null
        editorScreen?.release()
        editorScreen = null
        if (page == "editor" && core.projectId != null) {
            val es = EditorScreen(this, core, app.settingsStore, app.projects, this)
            editorScreen = es
            container.addView(es.root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            core.requestRender()
            val pend = pendingImageForEditor
            if (pend != null) { pendingImageForEditor = null; es.onImagePicked(pend) }
        } else {
            page = "projects"
            val ps = ProjectsScreen(this, app.projects, core.settings, app.settingsStore, this)
            projectsScreen = ps
            container.addView(ps.root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        window.decorView.setBackgroundColor(Theme.bg)
    }

    // ---- ProjectsHost / EditorHost ----
    override fun openProject(id: String) {
        if (core.openProject(id)) { page = "editor"; showPage() }
        else Toast.makeText(this, "Couldn't open project", Toast.LENGTH_SHORT).show()
    }

    override fun newProject() {
        core.newProject("Untitled")
        core.saveNow()
        page = "editor"
        showPage()
    }

    override fun rebuildUi() { showPage() }

    override fun goHome() {
        core.saveNow()
        core.projectId = null
        page = "projects"
        showPage()
    }

    override fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(i, "Choose Photo"), REQ_PICK)
    }

    override fun saveFile(suggestedName: String, mime: String, write: (OutputStream) -> Unit) {
        pendingWrite = write
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_TITLE, suggestedName)
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_SAVE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) { pendingWrite = null; return }
        if (requestCode == REQ_PICK) {
            core.busy(true)
            io.execute {
                val bmp = ImageLoader.decode(this, uri)
                main.post {
                    core.busy(false)
                    if (bmp == null) Toast.makeText(this, "Couldn't open image", Toast.LENGTH_SHORT).show()
                    else editorScreen?.onImagePicked(bmp)
                }
            }
        } else if (requestCode == REQ_SAVE) {
            val w = pendingWrite
            pendingWrite = null
            if (w == null) return
            core.busy(true)
            io.execute {
                var ok = false
                try {
                    contentResolver.openOutputStream(uri)?.use { out -> w(out); out.flush(); ok = true }
                } catch (t: Throwable) {
                    ok = false
                }
                main.post { core.busy(false); core.toast(if (ok) "Saved" else "Save failed") }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isCtrlPressed && page == "editor") {
            if (keyCode == KeyEvent.KEYCODE_Z) { if (event.isShiftPressed) core.redo() else core.undo(); return true }
            if (keyCode == KeyEvent.KEYCODE_Y) { core.redo(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (page == "editor") goHome() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        if (core.projectId != null) core.saveNow()
    }

    override fun onDestroy() {
        editorScreen?.release()
        super.onDestroy()
    }
}
