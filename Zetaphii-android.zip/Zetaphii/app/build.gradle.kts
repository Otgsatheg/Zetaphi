plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.zetaphii"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.zetaphii"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.2.0-native"

        // Galaxy A05 and all modern phones are arm64; armeabi-v7a is kept for older 32-bit devices.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Signs with the debug key so the release APK installs for testing; replace for publishing.
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// No third-party libraries: the app uses only the Android SDK, the Kotlin stdlib and the bundled C++ engine.
dependencies {
}
