# JNI entry points are resolved by name from native code (Java_app_zetaphii_editor_NativeEngine_*).
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class app.zetaphii.editor.NativeEngine { *; }
