# Zetaphii → native Android: feature migration report

Source of truth: `xzeta-app-improved-v5.zip` (TypeScript compiled to one `app.js`, `index.html`, `css/main.css`;
30 source modules). Targets: Kotlin app layer + C++17 engine (NDK / CMake / JNI), Android 8.0+ (API 26), ARM64.

## 1. Verification status — read this before trusting anything else

| Level | What | Evidence |
|---|---|---|
| **Verified (host)** | C++ engine numerics: identity pass-through, all 18 adjustments, 9-tap blur incl. fractional radius and preview scaling, all 19 blend modes with translucent layers, multi-layer chains, hidden-layer skipping, rotate / flip / crop / resize, selection invert, effect-brush filters | `tests/native/test_engine.py` — **68 checks, 0 failures**, against an independent numpy transcription of the original GLSL. Max difference ≤ 3/255 (8-bit rounding); `grain` matches exactly once the reference hash is evaluated in float32 like a GPU |
| **Verified (host)** | C++ compiles clean with `-Wall -Wextra`; JNI bridge passes a syntax check against stub JNI/bitmap headers | `tests/native/run_tests.sh` |
| **Verified (host)** | Seeded RNG / hash used by the "noise" pattern reproduces the original JS sequence | compared against the original algorithm run in Node |
| **Statically checked** | JNI names + arity ↔ Kotlin `external fun`; `LayerFloat` and `EffectKey` index agreement C++ ↔ Kotlin; all 18 params have a native slot; icons referenced exist; XML well-formed; brackets balanced; project imports resolve | `tools/verify_project.py` (all pass). **This is not a compile.** |
| **Written, NOT compiled** | All ~4,000 lines of Kotlin | no Kotlin compiler / Android SDK was available |
| **Written, NOT run** | CMake / NDK build, JNI calls from a real app, app launch, every UI flow, gestures, drawing, import/export, autosave/restore, behaviour on a Galaxy A05 | no device or emulator was available |

No claim of a successful build or of on-device behaviour is made anywhere in this project.

Engine timing, measured on a **single x86 sandbox core** (indicative only; includes process start and file I/O),
2048×1536 composite: copy 51 ms · full adjust 324 ms · 3 layers with blends 601 ms · blur r=12 745 ms.
The engine uses up to 4 threads; a Galaxy A05 has different per-core speed, so real figures must be measured. The
1024 px interactive preview during slider drags exists because of these numbers.

## 2. How the original works (inventory summary)

* **Pipeline:** every layer is a bitmap keyed by an immutable `imageId`; a layer stack is rendered by WebGL as
  *per-layer blur (9-tap separable Gaussian) → one adjust pass → blend onto accumulator*; layer textures are
  stretched over the whole canvas; the first (bottom) layer defines canvas size. 8-bit straight-alpha FBOs.
* **Layer params:** 18 sliders (`PARAM_DEFS`) mapped to shader values; 19 blend modes; kinds `raster | text | mask`.
* **History:** snapshots of `{selectedId, layers[]}` (+ selection mask), up to 60 steps; images shared by id.
* **Persistence:** IndexedDB project records (snapshot schema above) + one PNG blob per imageId; debounced autosave.
* **Tools:** Draw (brush hard/soft/air, eraser, effect brushes, texture/generative/custom brushes, dynamics,
  lasso freehand/rect/ellipse/poly, invert/clear/apply-to-mask/transform selection), Edit (adjust, rotate/flip/resize,
  crop), Layers, Elements (text, patterns, gradient), Settings, Place-image mode, Bake sheet, Help, Projects page.

## 3. Feature-by-feature status

Legend: **P-H** ported + host-verified (engine part) · **P** ported, compiled/run status = not verified ·
**C** ported with a documented change · **—** not ported (listed in §5)

### Projects page
| Feature | Status | Notes |
|---|---|---|
| Project list with thumbnails, New, open, rename, delete | P | folder per project: `project.json` + `images/<id>.png` + `thumb.jpg` |
| Project record / snapshot schema | P | identical JSON fields (`id,name,updatedAt,createdAt,snapshot,imageIds`) |
| Debounced autosave, save on pause/back | P | images written once (immutable ids), JSON written atomically |
| Splash, Help sheet, Settings (theme, delete all) | P / C | splash is a plain brand screen (no animation) |

### Editor shell and view
| Feature | Status | Notes |
|---|---|---|
| Top bar: back, project name (tap to rename), save-state dot, undo, redo | P | |
| Empty state ("Start creating": Blank Canvas / Choose Photo) | P | |
| Pinch zoom, two-finger pan + rotate, double-tap reset, Reset button, zoom clamp 0.5–8× | P | |
| Canvas background Checker / White / Black | P | |
| Themes Dark / Light / OLED with the original colour tokens | P | theme switch rebuilds the UI |
| Original icon set | P | all 48 `ICONS` SVGs converted to vector drawables by `tools/svg2vector.py` (no conversion warnings) |
| Keyboard undo/redo (Ctrl+Z, Ctrl+Shift+Z, Ctrl+Y) | P | external keyboards only |
| Before/After compare | — | exists in the original code but has **no entry point** in the UI (dead code); not ported |

### Layers
| Feature | Status | Notes |
|---|---|---|
| Add empty layer, delete (not the last), duplicate, rename, visibility | P | |
| 19 blend modes | P-H (math) / P (UI) | exact shader formulas |
| Reorder | C | ▲/▼ buttons instead of drag handles |
| Layer thumbnails in the list | — | |
| Mask layer (kind `mask`, inserted at the bottom, blue 55 % fill from the selection) | P | |

### Edit ▸ Adjust / Transform
| Feature | Status | Notes |
|---|---|---|
| 18 adjustment sliders + per-slider reset + reset all, live preview | P-H (engine) / P (UI) | identity detection mirrors `isIdentityAdjust` |
| Blur (9-tap, bilinear taps, radius scaled with preview) | P-H | |
| Rotate 90° L/R, flip H/V, resize with aspect lock, crop box (8 handles, min 20 px) | P-H (pixel ops) / P (UI) | all operate on the selected layer, like the original |
| Bake into layer pixels (selected / all) | C | a **hidden** layer is baked too; the original wiped hidden layers to transparent (data-loss quirk) |

### Draw
| Feature | Status | Notes |
|---|---|---|
| Brush with hard / soft / air tips (same gradient stops and spacing rules), size, opacity, colour | P | colour via an HSV picker + hex field |
| Eraser (stroke punched out with destination-out) | P | |
| Effect brushes (12: posterize, pixelate, blur, grain, vignette, invert, hue, saturation, brightness, contrast, temperature, exposure) with strength | P-H (filter) / P | |
| Selection clipping of strokes and fills | P | |
| Lasso: freehand, rect, ellipse, polygon (close within 24 px), additive; Clear, Invert, Apply to Mask; part of undo/redo | P-H (invert) / P | selection is shown as a blue tint instead of marching ants |
| Strokes | C | each stroke is baked into the layer when the finger lifts (the original also supports deferred baking) |
| Texture brushes, texture flow (repeat / generative), custom brushes from image, brush dynamics (spacing / scatter / jitter), transform selection | — | |

### Elements
| Feature | Status | Notes |
|---|---|---|
| Text layer: content, font, size, colour, rotation; re-rasterised on change | P / C | families: Space Grotesk, News Cycle, Changa One (need bundled TTFs, else system sans), plus serif / monospace / sans-serif |
| On-canvas text transform handles (offset/scale) | — | stored fields are kept in the data model |
| 10 preset patterns (same tile generators, seeded noise), tint, scale, opacity, fill layer | P | |
| Gradient fill (from/to, linear/radial, angle) | P | |
| Upload pattern / define pattern from canvas | — | |
| Add Image → place mode (move / scale / rotate / flip, confirm / cancel) | C | corner-handle scale + two-finger move/scale/rotate + buttons, instead of the 9-point box |
| Share-to-Zetaphii and "open with" for images | new (compat) | mobile counterpart of paste / drag-and-drop import |

### Settings, bake and export
| Feature | Status | Notes |
|---|---|---|
| Theme, canvas bg, history steps, default canvas, brush defaults, autosave interval, thumb size/quality, free memory, delete all | P | |
| New Blank Canvas sheet with 1:1, 16:9, 9:16, 2K² presets | P | |
| Bake & Save Image: PNG / JPG / WEBP + quality, native resolution, `project-WxH.ext` name | C | saved through the system "Create document" dialog (no storage permission needed) instead of a browser download |

## 4. Deliberate technical deviations
1. **CPU C++ compositor instead of WebGL.** The shaders were ported to C++ (verified numerically) rather than run through
   GLES: it is testable off-device, needs no GL context management, and the brief asks for GPU only when justified.
2. **Preview resolution cap** (2048 px, 1024 px while dragging) replaces the GPU `MAX_TEXTURE_SIZE` cap; export is native size.
3. **Bitmap memory management** (`ImageStore` spill-to-disk) is new — needed for a 4 GB phone; the browser had none.
4. **No AndroidX / third-party dependencies** so offline and phone-only builds have nothing to download.

## 5. Remaining limitations / not ported
Texture and generative brushes, custom brushes, brush dynamics, selection transform, on-canvas text transform,
custom patterns, layer thumbnails, drag-to-reorder, marching-ants outline, original web fonts (bundle manually),
splash animation, all untested behaviours listed in §1. A phone-only build of the NDK part under AndroidIDE is unverified.

## 6. Suggested first on-device checklist
Launch → New → Blank Canvas → draw → undo/redo → add image → adjust sliders (watch frame rate) → lasso + invert →
rotate/crop → add text → bake & save PNG → leave and reopen the project. Report any crash with `adb logcat -s AndroidRuntime`.
