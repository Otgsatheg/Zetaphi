#!/usr/bin/env python3
"""Static consistency checks that can run WITHOUT an Android toolchain.
They do NOT replace compiling the Kotlin code (see README): they catch the cross-file mistakes that
are easy to make by hand — JNI name/arity drift, enum/index drift between Kotlin and C++, missing icons,
malformed XML, unbalanced brackets, unresolved project imports."""
import re, sys, os, glob
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KT = glob.glob(os.path.join(ROOT, 'app/src/main/java/**/*.kt'), recursive=True)
RES = os.path.join(ROOT, 'app/src/main/res')
CPP = os.path.join(ROOT, 'app/src/main/cpp')
fails = []
def ok(msg): print('PASS', msg)
def bad(msg): print('FAIL', msg); fails.append(msg)
def read(p): return open(p, encoding='utf8').read()

def strip_kotlin(src):
    """Remove comments and string/char literals so bracket counting is reliable."""
    out = []; i = 0; n = len(src)
    while i < n:
        c = src[i]
        if src.startswith('//', i):
            while i < n and src[i] != '\n': i += 1
        elif src.startswith('/*', i):
            depth = 1; i += 2
            while i < n and depth:
                if src.startswith('/*', i): depth += 1; i += 2
                elif src.startswith('*/', i): depth -= 1; i += 2
                else: i += 1
        elif src.startswith('"""', i):
            i += 3
            while i < n and not src.startswith('"""', i): i += 1
            i += 3
        elif c == '"':
            i += 1
            while i < n and src[i] != '"':
                if src[i] == '\\': i += 1
                elif src.startswith('${', i):  # template expression: keep braces balanced by skipping it
                    depth = 1; i += 2
                    while i < n and depth:
                        if src[i] == '{': depth += 1
                        elif src[i] == '}': depth -= 1
                        i += 1
                    continue
                i += 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and src[i] != "'":
                if src[i] == '\\': i += 1
                i += 1
            i += 1
        else:
            out.append(c); i += 1
    return ''.join(out)

# 1. bracket balance per Kotlin file
for f in sorted(KT):
    s = strip_kotlin(read(f)); stack = []; good = True
    pairs = {')': '(', ']': '[', '}': '{'}
    for ch in s:
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop() != pairs[ch]: good = False; break
    if good and not stack: ok(f'brackets balanced: {os.path.relpath(f, ROOT)}')
    else: bad(f'brackets unbalanced: {os.path.relpath(f, ROOT)}')

# 2. JNI: every Kotlin `external fun` has a matching C++ export with the same arity
ne = read(os.path.join(ROOT, 'app/src/main/java/app/zetaphii/editor/NativeEngine.kt'))
kt_ext = {}
for m in re.finditer(r'external fun (\w+)\(([^)]*)\)\s*:\s*(\w+)', ne):
    params = [p for p in m.group(2).split(',') if p.strip()]
    kt_ext[m.group(1)] = (len(params), m.group(3))
cpp = read(os.path.join(CPP, 'jni_bridge.cpp'))
cpp_fn = {}
for m in re.finditer(r'JNI_FN\((\w+)\)\(([^)]*)\)', cpp, re.S):
    params = [p.strip() for p in m.group(2).replace('\n', ' ').split(',') if p.strip()]
    cpp_fn[m.group(1)] = len(params) - 2   # minus JNIEnv*, jclass
if set(kt_ext) == set(cpp_fn): ok(f'JNI: {len(kt_ext)} Kotlin external funs <-> {len(cpp_fn)} C++ exports (names match)')
else: bad(f'JNI name mismatch: kotlin-only={set(kt_ext)-set(cpp_fn)} cpp-only={set(cpp_fn)-set(kt_ext)}')
for k, (n, rt) in kt_ext.items():
    if k in cpp_fn and cpp_fn[k] != n: bad(f'JNI arity mismatch in {k}: kotlin={n} cpp={cpp_fn[k]}')
ok('JNI arities checked')
if 'Java_app_zetaphii_editor_NativeEngine_##name' in cpp: ok('JNI symbol prefix matches package app.zetaphii.editor.NativeEngine')
else: bad('JNI symbol prefix mismatch')

# 3. LayerFloat enum (C++) <-> Kotlin index table
h = read(os.path.join(CPP, 'native_engine.h'))
enum = dict((m.group(1), int(m.group(2))) for m in re.finditer(r'LF_(\w+)\s*=\s*(\d+)', h))
core = read(os.path.join(ROOT, 'app/src/main/java/app/zetaphii/editor/EditorCore.kt'))
table = dict(re.findall(r'"(\w+)" to (\d+)', core.split('object NativeEngine_LF')[1]))
table = {k.upper(): int(v) for k, v in table.items()}
table['VISIBLE'] = int(re.search(r'const val VISIBLE = (\d+)', core).group(1))
table['BLEND'] = int(re.search(r'const val BLEND = (\d+)', core).group(1))
if table == enum: ok(f'LayerFloat indices identical in C++ and Kotlin ({len(enum)} fields)')
else: bad(f'LayerFloat mismatch: {set(table.items()) ^ set(enum.items())}')
if int(re.search(r'kLayerFloats = (\d+)', h).group(1)) == int(re.search(r'LAYER_FLOATS = (\d+)', ne).group(1)) == len(enum): ok('LAYER_FLOATS consistent (20)')
else: bad('LAYER_FLOATS mismatch')

# 4. Params keys all mapped to a native slot; EffectKey order
model = read(os.path.join(ROOT, 'app/src/main/java/app/zetaphii/model/Model.kt'))
pkeys = re.findall(r'ParamDef\("(\w+)"', model)
missing = [k for k in pkeys if k.upper() not in enum]
if not missing and len(pkeys) == 18: ok('all 18 PARAM_DEFS keys have a native slot')
else: bad(f'PARAM keys without native slot: {missing} (count={len(pkeys)})')
fx_cpp = [m.lower() for m in re.findall(r'FX_(\w+)', h.split('enum EffectKey')[1].split('};')[0]) if m != 'NONE']
fx_kt = re.search(r'EFFECT_KEYS: List<String> = listOf\((.*?)\)', ne, re.S).group(1)
fx_kt = re.findall(r'"(\w+)"', fx_kt)
if fx_cpp == fx_kt: ok('EffectKey order identical in C++ and Kotlin')
else: bad(f'EffectKey mismatch {fx_cpp} vs {fx_kt}')

# 5. drawable names used in code exist
drawables = {os.path.basename(p)[:-4] for p in glob.glob(os.path.join(RES, 'drawable/*.xml'))}
used = set()
for f in KT:
    for m in re.finditer(r'(?:iconButton|iconView|iconRes)\(\s*"(\w+)"', read(f)): used.add(m.group(1))
    for m in re.finditer(r'Triple\("\w+", "\w+", "(\w+)"\)', read(f)): used.add(m.group(1))
    for m in re.finditer(r'if \((?:l\.visible|locked)\) "(\w+)" else "(\w+)"', read(f)): used.update(m.groups())
snake = lambda n: 'ic_' + re.sub(r'([A-Z])', lambda m: '_' + m.group(1).lower(), n)
miss = sorted(n for n in used if snake(n) not in drawables)
if not miss: ok(f'all {len(used)} icon names used in code exist as drawables')
else: bad(f'missing icon drawables: {miss}')

# 6. XML well-formedness
xml_bad = []
for p in glob.glob(os.path.join(ROOT, 'app/src/main/**/*.xml'), recursive=True):
    try: ET.parse(p)
    except ET.ParseError as e: xml_bad.append((p, str(e)))
if not xml_bad: ok('all XML (manifest + resources) well-formed')
else: bad(f'malformed XML: {xml_bad}')

# 7. project-internal imports resolve to declared top-level names
decl = set()
for f in KT:
    s = read(f); pkg = re.search(r'^package ([\w.]+)', s, re.M).group(1)
    for m in re.finditer(r'^(?:class|object|interface|enum class|data class|fun|var|val|const val)\s+(?:<[^>]*>\s*)?(?:\w+\.)?(\w+)', s, re.M): decl.add(f'{pkg}.{m.group(1)}')
unres = []
for f in KT:
    for m in re.finditer(r'^import (app\.zetaphii\.[\w.]+)$', read(f), re.M):
        if m.group(1) not in decl: unres.append((os.path.basename(f), m.group(1)))
if not unres: ok('all app.zetaphii imports resolve to a declaration')
else: bad(f'unresolved project imports: {unres}')

# 8. manifest sanity
man = read(os.path.join(ROOT, 'app/src/main/AndroidManifest.xml'))
if 'android:name=".ZetaApp"' in man and 'android:name=".MainActivity"' in man: ok('manifest references ZetaApp and MainActivity')
for cls in ('ZetaApp', 'MainActivity'):
    if not any(re.search(rf'class {cls}\b', read(f)) for f in KT): bad(f'manifest class {cls} not found')

print('\nSUMMARY:', 'ALL PASS' if not fails else f'{len(fails)} FAILED')
sys.exit(1 if fails else 0)
