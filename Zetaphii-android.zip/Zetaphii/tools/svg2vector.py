#!/usr/bin/env python3
"""Converts the original Zetaphii SVG icon set (src/01-icons.ts + inline SVGs in index.html)
into Android VectorDrawables (white strokes; tinted at runtime). Usage: svg2vector.py <orig_dir> <res/drawable>"""
import re, sys, os, html
import xml.etree.ElementTree as ET

def snake(n): return re.sub(r'([A-Z])', lambda m: '_' + m.group(1).lower(), n)

def num(v, d=0.0):
    try: return float(v)
    except Exception: return d

def fmt(x):
    s = ('%.4f' % x).rstrip('0').rstrip('.')
    return s if s else '0'

def shape_to_path(el):
    t = el.tag.split('}')[-1]
    a = el.attrib
    if t == 'path': return a.get('d')
    if t == 'line':
        return 'M%s %s L%s %s' % (fmt(num(a.get('x1'))), fmt(num(a.get('y1'))), fmt(num(a.get('x2'))), fmt(num(a.get('y2'))))
    if t == 'circle':
        cx, cy, r = num(a.get('cx')), num(a.get('cy')), num(a.get('r'))
        return 'M%s %s a%s %s 0 1 0 %s 0 a%s %s 0 1 0 %s 0 Z' % (fmt(cx - r), fmt(cy), fmt(r), fmt(r), fmt(2 * r), fmt(r), fmt(r), fmt(-2 * r))
    if t == 'ellipse':
        cx, cy, rx, ry = num(a.get('cx')), num(a.get('cy')), num(a.get('rx')), num(a.get('ry'))
        return 'M%s %s a%s %s 0 1 0 %s 0 a%s %s 0 1 0 %s 0 Z' % (fmt(cx - rx), fmt(cy), fmt(rx), fmt(ry), fmt(2 * rx), fmt(rx), fmt(ry), fmt(-2 * rx))
    if t == 'rect':
        x, y, w, h = num(a.get('x')), num(a.get('y')), num(a.get('width')), num(a.get('height'))
        rx = num(a.get('rx'), num(a.get('ry'))); ry = num(a.get('ry'), rx)
        rx = min(rx, w / 2); ry = min(ry, h / 2)
        if rx <= 0:
            return 'M%s %s h%s v%s h%s Z' % (fmt(x), fmt(y), fmt(w), fmt(h), fmt(-w))
        return ('M%s %s h%s a%s %s 0 0 1 %s %s v%s a%s %s 0 0 1 %s %s h%s a%s %s 0 0 1 %s %s v%s a%s %s 0 0 1 %s %s Z' %
                (fmt(x + rx), fmt(y), fmt(w - 2 * rx), fmt(rx), fmt(ry), fmt(rx), fmt(ry), fmt(h - 2 * ry),
                 fmt(rx), fmt(ry), fmt(-rx), fmt(ry), fmt(-(w - 2 * rx)), fmt(rx), fmt(ry), fmt(-rx), fmt(-ry),
                 fmt(-(h - 2 * ry)), fmt(rx), fmt(ry), fmt(rx), fmt(-ry)))
    if t in ('polyline', 'polygon'):
        pts = [float(v) for v in re.split(r'[ ,]+', a.get('points', '').strip()) if v]
        if len(pts) < 4: return None
        d = 'M%s %s' % (fmt(pts[0]), fmt(pts[1]))
        for i in range(2, len(pts) - 1, 2): d += ' L%s %s' % (fmt(pts[i]), fmt(pts[i + 1]))
        return d + (' Z' if t == 'polygon' else '')
    return None

def convert(svg_text, name, warn):
    svg_text = re.sub(r'\sxmlns(:\w+)?="[^"]*"', '', svg_text)
    try:
        root = ET.fromstring(svg_text)
    except ET.ParseError as e:
        warn.append(f'{name}: parse error {e}'); return None
    vb = (root.attrib.get('viewBox') or '0 0 24 24').split()
    vw, vh = float(vb[2]), float(vb[3])
    base = dict(root.attrib)
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
           '    android:width="24dp" android:height="24dp"',
           f'    android:viewportWidth="{fmt(vw)}" android:viewportHeight="{fmt(vh)}">']
    def emit(el, inherited):
        t = el.tag.split('}')[-1]
        attrs = dict(inherited); attrs.update(el.attrib)
        if t in ('g', 'svg'):
            for ch in el: emit(ch, {k: v for k, v in attrs.items() if k in ('fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'opacity', 'fill-opacity', 'stroke-opacity')})
            return
        d = shape_to_path(el)
        if not d:
            if t not in ('title', 'desc', 'defs'): warn.append(f'{name}: unsupported <{t}>')
            return
        for bad in ('transform', 'stroke-dasharray', 'clip-path', 'mask', 'filter'):
            if bad in attrs: warn.append(f'{name}: ignored attribute {bad}')
        fill = attrs.get('fill', 'black' if t != 'line' else 'none')
        stroke = attrs.get('stroke', 'none')
        op = num(attrs.get('opacity'), 1.0)
        line = ['    <path', f'        android:pathData="{html.escape(d, quote=True)}"']
        if fill not in ('none', 'transparent'):
            line.append('        android:fillColor="#FFFFFFFF"')
            fo = op * num(attrs.get('fill-opacity'), 1.0)
            if fo < 1: line.append(f'        android:fillAlpha="{fmt(fo)}"')
        if stroke not in ('none', 'transparent'):
            line.append('        android:strokeColor="#FFFFFFFF"')
            line.append(f'        android:strokeWidth="{fmt(num(attrs.get("stroke-width"), 1.0))}"')
            line.append(f'        android:strokeLineCap="{attrs.get("stroke-linecap", "butt")}"')
            line.append(f'        android:strokeLineJoin="{attrs.get("stroke-linejoin", "miter")}"')
            so = op * num(attrs.get('stroke-opacity'), 1.0)
            if so < 1: line.append(f'        android:strokeAlpha="{fmt(so)}"')
        out.append('\n'.join(line) + ' />')
    root_inherit = {k: v for k, v in base.items() if k in ('fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'opacity')}
    for ch in root: emit(ch, root_inherit)
    out.append('</vector>')
    return '\n'.join(out)

def main(orig, res):
    os.makedirs(res, exist_ok=True)
    warn = []; names = []
    s = open(os.path.join(orig, 'src', '01-icons.ts'), encoding='utf8').read()
    for m in re.finditer(r"^\s*['\"]?([A-Za-z0-9_]+)['\"]?\s*:\s*'(<svg.*?</svg>)'\s*,?\s*$", s, re.M | re.S):
        name, svg = m.group(1), m.group(2).replace("\\'", "'")
        x = convert(svg, name, warn)
        if x:
            open(os.path.join(res, f'ic_{snake(name)}.xml'), 'w').write(x); names.append(name)
    print(f'{len(names)} icons converted from ICONS')
    # inline SVGs in index.html that carry a data-/id context: name them by order for reference
    h = open(os.path.join(orig, 'index.html'), encoding='utf8').read()
    inline = re.findall(r'<svg.*?</svg>', h, re.S)
    print(f'{len(inline)} inline <svg> blocks found in index.html')
    for w in warn: print('WARN', w)
    return names

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
