# Zetaphii — native Android edition (Kotlin + C++)

Zetaphii is a layer-based image editor. This project is the **technology migration** of the original
HTML/CSS/TypeScript + WebGL app (`xzeta-app-improved-v5.zip`) to a native Android app:

| Layer | Technology | What lives there |
|---|---|---|
| Application | **Kotlin**, plain Android SDK (no AndroidX, no third-party libraries) | screens, panels, sheets, gestures, projects/autosave, settings, import/export, layer model, history |
| Pixel engine | **C++17** via NDK + CMake + JNI (`libzetaphii_native.so`) | the ported ADJUST / BLUR / BLEND shaders, layer compositing, resize / rotate / flip / crop, selection-mask ops, stroke baking, effect-brush filters |

The identity is preserved: same name, colour tokens (dark / light / OLED), icon set (converted
1:1 from the original SVGs), tools, terminology and project format. It is **not** a WebView wrapper.

> **Read this first — honest status.**
> The build tools needed to compile an APK (Android SDK, Gradle, Kotlin compiler) were **not available**
> in the environment where this code was written, so **the APK has never been built and the Kotlin code
> has never been compiled or run on a device.** What *was* verified is listed in
> [`MIGRATION_REPORT.md`](MIGRATION_REPORT.md) (the C++ engine is tested against an independent
> reference of the original shaders; cross-file consistency is checked statically). Expect to fix a few
> compile errors on the first build — see "If the first build fails".

## Project layout

```
Zetaphii/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
├── gradle/wrapper/gradle-wrapper.properties     (wrapper JAR not included — see below)
├── app/
│   ├── build.gradle.kts, proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── cpp/            CMakeLists.txt, native_engine.{h,cpp}, jni_bridge.cpp
│       ├── java/app/zetaphii/
│       │   ├── MainActivity.kt, ZetaApp.kt
│       │   ├── model/      Model.kt           layers, params (PARAM_DEFS), snapshots, settings
│       │   ├── editor/     EditorCore.kt      layer stack, selection, history, rendering driver, transforms, fills, text
│       │   │               NativeEngine.kt    JNI declarations
│       │   │               BrushEngine.kt     brush / effect brushes / lasso
│       │   │               ImageStore.kt, History.kt, Patterns.kt, TextRaster.kt, ImageLoader.kt
│       │   ├── storage/    Storage.kt         projects (JSON + PNG), settings, export codec
│       │   └── ui/         Ui.kt (theme + widgets), CanvasView.kt, EditorScreen.kt, ProjectsScreen.kt
│       └── res/            48 vector icons (generated from the original SVGs), theme, launcher icon
├── tests/native/           host-side engine tests (g++ + python/numpy)
├── tools/                  svg2vector.py (icon converter), verify_project.py (static checks)
├── .github/workflows/build-apk.yml
├── MIGRATION_REPORT.md
└── README.md
```

## Building the APK

Requirements: JDK 17, Android SDK platform 34, Android NDK (any recent, e.g. r25–r27) and CMake 3.22.1
(both installable from Android Studio ▸ SDK Manager ▸ SDK Tools). `minSdk 26`, `targetSdk 34`,
ABIs `arm64-v8a` (Galaxy A05 and all current phones) and `armeabi-v7a`.

### A) Android Studio (recommended for the first build)
1. File ▸ Open ▸ select the `Zetaphii` folder. Accept the Gradle sync; let it download the NDK / CMake if asked.
2. Build ▸ Build APK(s) (or Run on a connected device).
   The APK lands in `app/build/outputs/apk/debug/app-debug.apk`.

### B) Command line
```sh
cd Zetaphii
gradle wrapper --gradle-version 8.2     # one-off: generates gradlew + gradle-wrapper.jar
./gradlew :app:assembleDebug            # debug APK
./gradlew :app:assembleRelease          # release APK (signed with the debug key for testing)
```

### C) Phone-only workflows
* **GitHub Actions (most reliable phone-only path, untested by the author):** put the project in a GitHub
  repository from your phone (browser upload of the ZIP contents works), open *Actions ▸ Build APK ▸ Run
  workflow*, then download the `Zetaphii-debug-apk` artifact and install it. The workflow is
  `.github/workflows/build-apk.yml`.
* **AndroidIDE (on-device):** open the project folder in AndroidIDE and run its Gradle build task
  `:app:assembleDebug`. *Caveat:* the Kotlin/Gradle part is what AndroidIDE is built for, but whether your
  AndroidIDE version ships an NDK + CMake that can compile the `src/main/cpp` library is **not verified** —
  if its native build fails, use the GitHub Actions route (or build on any PC), then install the APK on the phone.

Install: copy the APK to the phone, open it, allow "install unknown apps" for your file manager.

### Optional: bundled fonts
The original loaded *Space Grotesk*, *News Cycle* and *Changa One* from Google Fonts. The app is offline and
the fonts could not be downloaded when this was written, so it falls back to the system sans-serif.
To get the original typography, download the (OFL-licensed) TTFs and place them in
`app/src/main/assets/fonts/` with exactly these names: `SpaceGrotesk-Regular.ttf`, `SpaceGrotesk-Bold.ttf`,
`NewsCycle-Regular.ttf`, `NewsCycle-Bold.ttf`, `ChangaOne-Regular.ttf`. No code change needed.

## Verifying the parts that can be verified without Android

```sh
sh tests/native/run_tests.sh
```
Builds the C++ engine for the host, runs 68 numeric checks against an independent numpy implementation of the
original GLSL shaders (all 19 blend modes, every adjustment, blur, geometry, masks, effect brushes), syntax-checks
the JNI bridge against stub headers, and runs `tools/verify_project.py` (JNI ↔ Kotlin signatures, enum/index
agreement between C++ and Kotlin, icon presence, XML well-formedness, bracket balance, import resolution).

## If the first build fails
The Kotlin sources were written without a compiler. Typical first-build issues are small (a missing import, a
type-inference hint, a deprecated-API warning promoted by your lint settings). The code uses only the Android SDK
and Kotlin stdlib, so errors will point directly at a file and line in `app/src/main/java/app/zetaphii/`.
If the **native** step fails, the error will name `native_engine.cpp` / `jni_bridge.cpp` (these compile cleanly with
`g++ -Wall -Wextra` on the host); also check that CMake 3.22.1 is installed (`app/build.gradle.kts` pins it).

## Memory notes for 4 GB phones
* Every edit creates a new immutable image; `ImageStore` keeps recent bitmaps in memory under a budget derived from
  the device (≈96–320 MB) and spills older ones to the cache directory (raw pixels), reloading on demand.
* Interactive preview is rendered at most 2048 px on the long side (1024 px while a slider is dragged); export
  renders at the full native size. Blur radius is scaled with the preview so the look matches the export.
* Imported photos are decoded with a power-of-two subsample so the longest side is ≤ 4096 px.
* The engine allocates three working buffers of canvas size during a composite (≈ 3 × W × H × 4 bytes).

See `MIGRATION_REPORT.md` for the full feature inventory, deviations from the original, and open limitations.
