#!/bin/sh
# Host-side verification of the C++ engine (needs g++, python3, numpy). Does not need Android.
set -e
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -Wall -Wextra -o /tmp/engine_cli engine_cli.cpp ../../app/src/main/cpp/native_engine.cpp -pthread
# JNI bridge: syntax check against stub headers (the real NDK headers are used in the Android build)
g++ -std=c++17 -fsyntax-only -Wall -Wextra -Istubs ../../app/src/main/cpp/jni_bridge.cpp
ENGINE_CLI=/tmp/engine_cli python3 test_engine.py
python3 ../../tools/verify_project.py
