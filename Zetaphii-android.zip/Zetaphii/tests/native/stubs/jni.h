// Minimal stand-in for <jni.h> (the sandbox JDK has no headers). ONLY for syntax-checking
// jni_bridge.cpp on a PC. Signatures mirror the real JNI C++ interface for the calls used.
#pragma once
#include <stdint.h>
typedef int32_t jint; typedef float jfloat; typedef uint8_t jboolean; typedef int32_t jsize;
class _jobject {}; typedef _jobject* jobject; typedef jobject jclass; typedef jobject jobjectArray;
typedef jobject jfloatArray; typedef jobject jintArray;
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNI_ABORT 2
#define JNIEXPORT
#define JNICALL
struct JNIEnv {
  jsize GetArrayLength(jobject);
  jobject GetObjectArrayElement(jobjectArray, jsize);
  void DeleteLocalRef(jobject);
  jfloat* GetFloatArrayElements(jfloatArray, jboolean*);
  void ReleaseFloatArrayElements(jfloatArray, jfloat*, jint);
  void SetIntArrayRegion(jintArray, jsize, jsize, const jint*);
};
