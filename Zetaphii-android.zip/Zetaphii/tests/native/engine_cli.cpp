// Host-side test driver for the native engine (NOT part of the Android build).
// usage: engine_cli <op> ... ; raw files are RGBA8 premultiplied, tightly packed.
//   composite W H out.raw n  (layer0.raw p0..p19) ... [blurScale]
//   rotate W H in.raw out.raw cw|ccw
//   flip W H in.raw out.raw h|v
//   crop W H in.raw out.raw x y cw ch
//   resize W H in.raw out.raw dw dh
//   mask-invert W H in.raw out.raw
//   fx W H in.raw out.raw x0 y0 bw bh key p
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "../../app/src/main/cpp/native_engine.h"
using namespace zeta;

static std::vector<uint8_t> readFile(const char* p, size_t n) {
  std::vector<uint8_t> v(n);
  FILE* f = fopen(p, "rb");
  if (!f || fread(v.data(), 1, n, f) != n) { fprintf(stderr, "read fail %s\n", p); exit(3); }
  fclose(f);
  return v;
}
static void writeFile(const char* p, const std::vector<uint8_t>& v) {
  FILE* f = fopen(p, "wb");
  fwrite(v.data(), 1, v.size(), f);
  fclose(f);
}

int main(int argc, char** argv) {
  if (argc < 2) return 2;
  std::string op = argv[1];
  if (op == "selftest") return selfTest();
  int W = atoi(argv[2]), H = atoi(argv[3]);
  if (op == "composite") {
    const char* outp = argv[4];
    int n = atoi(argv[5]);
    std::vector<std::vector<uint8_t>> bufs;
    std::vector<ConstSurface> ls;
    std::vector<float> params;
    int a = 6;
    for (int i = 0; i < n; ++i) {
      bufs.push_back(readFile(argv[a++], (size_t)W * H * 4));
      for (int k = 0; k < kLayerFloats; ++k) params.push_back((float)atof(argv[a++]));
    }
    float bs = (a < argc) ? (float)atof(argv[a]) : 1.f;
    for (auto& b : bufs) ls.push_back(ConstSurface{b.data(), W, H, W * 4});
    std::vector<uint8_t> out((size_t)W * H * 4);
    int rc = compositeLayers(ls.data(), params.data(), n, Surface{out.data(), W, H, W * 4}, bs);
    writeFile(outp, out);
    return rc;
  }
  auto in = readFile(argv[4], (size_t)W * H * 4);
  ConstSurface s{in.data(), W, H, W * 4};
  if (op == "rotate") {
    std::vector<uint8_t> out((size_t)W * H * 4);
    int rc = rotate90(s, Surface{out.data(), H, W, H * 4}, std::string(argv[6]) == "cw");
    writeFile(argv[5], out);
    return rc;
  }
  if (op == "flip") {
    std::vector<uint8_t> out((size_t)W * H * 4);
    int rc = flipSurface(s, Surface{out.data(), W, H, W * 4}, std::string(argv[6]) == "h");
    writeFile(argv[5], out);
    return rc;
  }
  if (op == "crop") {
    int x = atoi(argv[6]), y = atoi(argv[7]), cw = atoi(argv[8]), ch = atoi(argv[9]);
    std::vector<uint8_t> out((size_t)cw * ch * 4);
    int rc = cropSurface(s, Surface{out.data(), cw, ch, cw * 4}, x, y);
    writeFile(argv[5], out);
    return rc;
  }
  if (op == "resize") {
    int dw = atoi(argv[6]), dh = atoi(argv[7]);
    std::vector<uint8_t> out((size_t)dw * dh * 4);
    int rc = resizeSurface(s, Surface{out.data(), dw, dh, dw * 4});
    writeFile(argv[5], out);
    return rc;
  }
  if (op == "mask-invert") {
    std::vector<uint8_t> out = in;
    bool any = invertMask(Surface{out.data(), W, H, W * 4});
    writeFile(argv[5], out);
    return any ? 10 : 11;  // 10 = something selected, 11 = empty
  }
  if (op == "fx") {
    int x0 = atoi(argv[6]), y0 = atoi(argv[7]), bw = atoi(argv[8]), bh = atoi(argv[9]), key = atoi(argv[10]);
    float p = (float)atof(argv[11]);
    std::vector<uint8_t> out((size_t)bw * bh * 4);
    int rc = effectRegion(s, x0, y0, bw, bh, key, p, Surface{out.data(), bw, bh, bw * 4});
    writeFile(argv[5], out);
    return rc;
  }
  return 2;
}
