#!/usr/bin/env python3
"""Verifies the C++ engine against an independent numpy transcription of the ORIGINAL
GLSL shaders (ADJUST_FRAG_SRC / BLUR_FRAG_SRC / BLEND_FRAG_SRC) and Canvas helpers.
Run:  g++ -std=c++17 -O2 -o /tmp/engine_cli engine_cli.cpp ../../app/src/main/cpp/native_engine.cpp -pthread
      python3 test_engine.py"""
import subprocess, sys, os, tempfile
import numpy as np

CLI = os.environ.get("ENGINE_CLI", "/tmp/engine_cli")
rng = np.random.default_rng(1234)
FAIL = []

def run(*args):
    r = subprocess.run([CLI] + [str(a) for a in args], capture_output=True)
    return r.returncode

def premul(st):  # straight uint8 -> premult uint8 (same rounding as C++)
    a = st[..., 3:4].astype(np.int32)
    rgb = (st[..., :3].astype(np.int32) * a + 127) // 255
    out = np.concatenate([rgb, a], -1).astype(np.uint8)
    out[st[..., 3] == 255] = st[st[..., 3] == 255]
    return out

def unpremul(pm):
    a = pm[..., 3:4].astype(np.int32)
    safe = np.maximum(a, 1)
    rgb = np.minimum(255, (pm[..., :3].astype(np.int32) * 255 + safe // 2) // safe)
    rgb = np.where(a == 0, 0, rgb)
    rgb = np.where(a == 255, pm[..., :3], rgb)
    return np.concatenate([rgb, a], -1).astype(np.uint8)

def rand_straight(h, w, alpha_mode="mixed"):
    img = rng.integers(0, 256, (h, w, 4), dtype=np.uint8)
    if alpha_mode == "opaque":
        img[..., 3] = 255
    elif alpha_mode == "mixed":
        img[..., 3] = rng.choice([0, 40, 128, 200, 255], size=(h, w))
    return img

def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)

def mix(a, b, t): return a * (1 - t) + b * t

def sample_bilinear(buf, u, v):
    h, w = buf.shape[:2]
    tx = u * w - 0.5; ty = v * h - 0.5
    x0 = np.floor(tx); y0 = np.floor(ty); fx = (tx - x0)[..., None]; fy = (ty - y0)[..., None]
    x0 = x0.astype(int); y0 = y0.astype(int)
    cl = lambda a, n: np.clip(a, 0, n - 1)
    g = lambda yy, xx: buf[cl(yy, h), cl(xx, w)].astype(np.float64)
    top = mix(g(y0, x0), g(y0, x0 + 1), fx); bot = mix(g(y0 + 1, x0), g(y0 + 1, x0 + 1), fx)
    return mix(top, bot, fy) / 255.0

PARAM_KEYS = ["visible","blend","blur","brightness","contrast","saturation","vibrance","exposure","highlights",
              "shadows","temperature","tint","sharpness","opacity","posterize","pixelate","grain","vignette","invert","hue"]
def defaults():
    d = dict(visible=1, blend=0, blur=0, brightness=0, contrast=1, saturation=1, vibrance=0, exposure=0, highlights=0,
             shadows=0, temperature=0, tint=0, sharpness=0, opacity=1, posterize=0, pixelate=0, grain=0, vignette=0,
             invert=0, hue=0)
    return d
def plist(d): return [d[k] for k in PARAM_KEYS]

def hash12(px, py):
    # GLSL highp = IEEE float32: evaluate the hash in float32 like the GPU (and the C++ port) does.
    f32 = np.float32
    fr = lambda x: x - np.floor(x)
    px = px.astype(f32); py = py.astype(f32)
    a = fr(px * f32(0.1031)); b = fr(py * f32(0.1031)); c = a.copy()
    d = a * (b + f32(33.33)) + b * (c + f32(33.33)) + c * (a + f32(33.33))
    a = a + d; b = b + d; c = c + d
    return fr((a + b) * c).astype(np.float64)

def ref_adjust(st, p):
    h, w = st.shape[:2]
    src = st.astype(np.float64) / 255.0
    ys, xs = np.mgrid[0:h, 0:w]
    u = (xs + 0.5) / w; v = (ys + 0.5) / h
    s = src.copy()
    if p["pixelate"] >= 2:
        bx = p["pixelate"]; by = max(1.0, p["pixelate"] * h / w)
        gx = np.floor(u * bx); gy = np.floor(v * by)
        s = sample_bilinear(st, (gx + 0.5) / bx, (gy + 0.5) / by)
    c = s[..., :3].copy()
    c[..., 0] += p["temperature"] + p["tint"] * 0.5
    c[..., 1] -= p["tint"]
    c[..., 2] += -p["temperature"] + p["tint"] * 0.5
    c *= 2.0 ** p["exposure"]
    c += p["brightness"]
    c = (c - 0.5) * p["contrast"] + 0.5
    LUMA = np.array([0.299, 0.587, 0.114])
    luma = (np.clip(c, 0, 1) * LUMA).sum(-1)
    hm = smooth(0.25, 1.0, luma); sm = 1 - smooth(0.0, 0.75, luma)
    c += (p["highlights"] * hm * 0.6)[..., None]
    c += (p["shadows"] * sm * 0.6)[..., None]
    sat = c.max(-1) - c.min(-1)
    lv = (c * LUMA).sum(-1)[..., None]
    c = mix(lv, c, (1 + p["vibrance"] * (1 - sat))[..., None])
    ls = (c * LUMA).sum(-1)[..., None]
    c = mix(ls, c, p["saturation"])
    if abs(p["sharpness"]) > 0.001:
        pad = np.pad(st[..., :3].astype(np.float64) / 255.0, ((1, 1), (1, 1), (0, 0)), mode="edge")
        n = (pad[1:-1, 2:] + pad[1:-1, :-2] + pad[2:, 1:-1] + pad[:-2, 1:-1]) * 0.25
        c += (s[..., :3] - n) * p["sharpness"]
    if abs(p["hue"]) > 0.001:
        a = np.radians(p["hue"]); k = np.full(3, 0.57735026919)
        cr = np.cross(k, c)
        c = c * np.cos(a) + cr * np.sin(a) + k * (c @ k)[..., None] * (1 - np.cos(a))
    inv = min(max(p["invert"], 0), 1)
    c = mix(c, 1 - c, inv)
    if p["posterize"] >= 2:
        lv2 = p["posterize"] - 1
        c = np.floor(c * lv2 + 0.5) / lv2
    if p["grain"] > 0.001:
        c += ((hash12(xs + 0.5, (h - 1 - ys) + 0.5) - 0.5) * p["grain"])[..., None]
    if p["vignette"] > 0.001:
        d = np.hypot(u - 0.5, v - 0.5)
        c *= (1 - p["vignette"] * smooth(0.35, 0.95, d))[..., None]
    c = np.clip(c, 0, 1)
    out = np.concatenate([c, (s[..., 3] * p["opacity"])[..., None]], -1)
    return np.floor(np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8)

def ref_blur(st, radius):
    h, w = st.shape[:2]
    W0 = 0.227027; WK = [0.1945946, 0.1216216, 0.0540540, 0.0162162]
    def axis(buf, dirx):
        ys, xs = np.mgrid[0:h, 0:w]
        acc = buf.astype(np.float64) * W0
        for t in range(1, 5):
            for sgn in (-1, 1):
                if dirx:
                    u = (xs + 0.5 + sgn * radius * t) / w; v = (ys + 0.5) / h
                else:
                    u = (xs + 0.5) / w; v = (ys + 0.5 + sgn * radius * t) / h
                acc += sample_bilinear(buf, u, v) * 255.0 * WK[t - 1]
        return np.floor(np.clip(acc / 255.0, 0, 1) * 255 + 0.5).astype(np.uint8)
    return axis(axis(st, True), False)

def lum(c): return (c * np.array([0.3, 0.59, 0.11])).sum(-1, keepdims=True)
def clip_color(c):
    l = lum(c); n = c.min(-1, keepdims=True); x = c.max(-1, keepdims=True)
    c = np.where(n < 0, l + (c - l) * (l / np.maximum(l - n, 0.0001)), c)
    c = np.where(x > 1, l + (c - l) * ((1 - l) / np.maximum(x - l, 0.0001)), c)
    return c
def set_lum(c, l): return clip_color(c + (l - lum(c)))
def sat_f(c): return c.max(-1, keepdims=True) - c.min(-1, keepdims=True)
def set_sat(c, s):
    cmax = c.max(-1, keepdims=True); cmin = c.min(-1, keepdims=True)
    return np.where(cmax > cmin, (c - cmin) * s / np.maximum(cmax - cmin, 1e-12), 0.0)

def blend_rgb(b, s, m):
    if m == 0: return s
    if m == 1: return b * s
    if m == 2: return b + s - b * s
    if m == 3: return np.where(b <= 0.5, 2 * b * s, 1 - 2 * (1 - b) * (1 - s))
    if m == 4:
        d = np.where(b <= 0.25, ((16 * b - 12) * b + 4) * b, np.sqrt(b))
        return np.where(s <= 0.5, b - (1 - 2 * s) * b * (1 - b), b + (2 * s - 1) * (d - b))
    if m == 5: return np.where(s <= 0.5, 2 * b * s, 1 - 2 * (1 - b) * (1 - s))
    if m == 6: return np.where(s <= 0, 0.0, 1 - np.minimum(1, (1 - b) / np.maximum(s, 1e-12)))
    if m == 7: return np.clip(b + s - 1, 0, 1)
    if m == 8: return np.where(s >= 1, 1.0, np.minimum(1, b / np.maximum(1 - s, 1e-12)))
    if m == 9: return np.clip(b + s, 0, 1)
    if m == 10: return np.abs(b - s)
    if m == 11: return b + s - 2 * b * s
    if m == 12: return np.where(b + s < 1, 0.0, 1.0)
    if m == 13: return np.clip(b / np.maximum(s, 0.003), 0, 1)
    if m == 14: return np.clip(b - s, 0, 1)
    if m == 15: return set_lum(set_sat(s, sat_f(b)), lum(b))
    if m == 16: return set_lum(set_sat(b, sat_f(s)), lum(b))
    if m == 17: return set_lum(s, lum(b))
    if m == 18: return set_lum(b, lum(s))
    return s

def ref_blend(backdrop, source, m):
    b = backdrop.astype(np.float64) / 255.0; s = source.astype(np.float64) / 255.0
    bl = blend_rgb(b[..., :3], s[..., :3], m)
    sa = s[..., 3:4]; ba = b[..., 3:4]
    out_a = sa + ba * (1 - sa)
    res = mix(b[..., :3], bl, sa)
    return np.floor(np.clip(np.concatenate([res, out_a], -1), 0, 1) * 255 + 0.5).astype(np.uint8)

def check(name, got, exp, tol, max_bad_frac=0.0):
    diff = np.abs(got.astype(int) - exp.astype(int))
    mx = int(diff.max()); bad = float((diff > tol).mean())
    ok = bad <= max_bad_frac
    print(("PASS " if ok else "FAIL ") + f"{name:44s} maxdiff={mx} frac>{tol}={bad:.5f}")
    if not ok: FAIL.append(name)

def composite(tmp, layers, params, blur_scale=1.0):
    h, w = layers[0].shape[:2]
    files = []
    for i, st in enumerate(layers):
        f = os.path.join(tmp, f"l{i}.raw"); premul(st).tofile(f); files.append(f)
    out = os.path.join(tmp, "out.raw")
    args = ["composite", w, h, out, len(layers)]
    for f, p in zip(files, params): args += [f] + plist(p)
    args += [blur_scale]
    rc = run(*args)
    assert rc == 0, f"composite rc={rc}"
    return np.fromfile(out, np.uint8).reshape(h, w, 4)

def main():
    H, W = 41, 57
    with tempfile.TemporaryDirectory() as tmp:
        base = rand_straight(H, W, "opaque")
        # 1. identity composite returns the layer unchanged
        got = composite(tmp, [base], [defaults()])
        check("identity single layer (opaque)", got, premul(base), 0)
        semi = rand_straight(H, W, "mixed")
        got = composite(tmp, [semi], [defaults()])
        exp = premul(unpremul(premul(semi)))
        check("identity single layer (semi-transparent)", got, exp, 1)

        # 2. adjust passes, one param at a time + a combined stress case
        cases = {
            "brightness": dict(brightness=0.3), "contrast": dict(contrast=1.7), "saturation": dict(saturation=0.2),
            "vibrance": dict(vibrance=0.8), "exposure": dict(exposure=1.5), "highlights": dict(highlights=-0.6),
            "shadows": dict(shadows=0.7), "temperature": dict(temperature=0.25), "tint": dict(tint=-0.3),
            "sharpness": dict(sharpness=0.8), "opacity": dict(opacity=0.45), "posterize": dict(posterize=6),
            "pixelate": dict(pixelate=12), "grain": dict(grain=0.2), "vignette": dict(vignette=0.7),
            "invert": dict(invert=1.0), "hue": dict(hue=75),
            "combined": dict(brightness=0.1, contrast=1.3, saturation=1.4, vibrance=0.3, exposure=0.4, highlights=0.2,
                             shadows=-0.2, temperature=0.1, tint=0.05, sharpness=0.5, opacity=0.8, posterize=12,
                             hue=-40, invert=0.3, grain=0.05, vignette=0.4),
        }
        src = rand_straight(H, W, "mixed")
        for name, over in cases.items():
            d = defaults(); d.update(over)
            got = composite(tmp, [src], [d])
            ref = ref_adjust(unpremul(premul(src)), d)
            check(f"adjust:{name}", got, premul(ref), 2, 0.001)

        # 3. blur (integer + fractional radius, with preview scaling)
        for r in (0.6, 2.0, 5.5):
            d = defaults(); d["blur"] = r
            got = composite(tmp, [src], [d])
            ref = ref_blur(unpremul(premul(src)), r)
            check(f"blur radius={r}", got, premul(ref), 2, 0.002)
        d = defaults(); d["blur"] = 4.0
        got = composite(tmp, [src], [d], 0.5)
        ref = ref_blur(unpremul(premul(src)), 2.0)
        check("blur radius=4 with blurScale 0.5", got, premul(ref), 2, 0.002)

        # 4. all 19 blend modes, translucent top layer
        top = rand_straight(H, W, "mixed")
        for m in range(19):
            dt = defaults(); dt["blend"] = m
            got = composite(tmp, [base, top], [defaults(), dt])
            ref = ref_blend(base, unpremul(premul(top)), m)
            check(f"blend mode {m:2d}", got, premul(ref), 2, 0.002)
        # 5. three layers, middle one adjusted + multiply, top screen with blur
        d1 = defaults(); d1.update(blend=1, saturation=0.5, opacity=0.7)
        d2 = defaults(); d2.update(blend=2, blur=1.5)
        l2 = rand_straight(H, W, "mixed"); l3 = rand_straight(H, W, "mixed")
        got = composite(tmp, [base, l2, l3], [defaults(), d1, d2])
        acc = base
        a2 = ref_adjust(unpremul(premul(l2)), d1)
        acc = ref_blend(acc, a2, 1)
        a3 = ref_blur(unpremul(premul(l3)), 1.5)
        acc = ref_blend(acc, a3, 2)
        check("3-layer chain (adjust+blur+blend)", got, premul(acc), 3, 0.005)
        # hidden layer ignored
        hid = defaults(); hid["visible"] = 0
        got = composite(tmp, [base, top], [defaults(), hid])
        check("hidden layer skipped", got, premul(base), 0)
        # empty -> transparent
        got = composite(tmp, [base], [hid])
        check("no visible layers -> transparent", got, np.zeros_like(got), 0)

        # 6. geometry
        pm = premul(rand_straight(H, W, "mixed")); f = os.path.join(tmp, "g.raw"); pm.tofile(f)
        o = os.path.join(tmp, "go.raw")
        run("rotate", W, H, f, o, "cw");  check("rotate 90 cw", np.fromfile(o, np.uint8).reshape(W, H, 4), np.rot90(pm, -1), 0)
        run("rotate", W, H, f, o, "ccw"); check("rotate 90 ccw", np.fromfile(o, np.uint8).reshape(W, H, 4), np.rot90(pm, 1), 0)
        run("flip", W, H, f, o, "h"); check("flip horizontal", np.fromfile(o, np.uint8).reshape(H, W, 4), pm[:, ::-1], 0)
        run("flip", W, H, f, o, "v"); check("flip vertical", np.fromfile(o, np.uint8).reshape(H, W, 4), pm[::-1], 0)
        run("crop", W, H, f, o, 5, 7, 20, 13); check("crop", np.fromfile(o, np.uint8).reshape(13, 20, 4), pm[7:20, 5:25], 0)
        rc = run("crop", W, H, f, o, 50, 7, 20, 13)
        print(("PASS " if rc != 0 else "FAIL ") + "crop out of range rejected"); 
        if rc == 0: FAIL.append("crop bounds")
        # resize: constant colour stays constant; down/up scale keep mean
        const = np.tile(np.array([90, 60, 30, 255], np.uint8), (H, W, 1)); const.tofile(f)
        run("resize", W, H, f, o, 23, 19); check("resize const downscale", np.fromfile(o, np.uint8).reshape(19, 23, 4), np.tile(const[0, 0], (19, 23, 1)), 0)
        run("resize", W, H, f, o, 200, 150); check("resize const upscale", np.fromfile(o, np.uint8).reshape(150, 200, 4), np.tile(const[0, 0], (150, 200, 1)), 0)
        noise = premul(rand_straight(64, 64, "opaque")); noise.tofile(f)
        run("resize", 64, 64, f, o, 16, 16)
        small = np.fromfile(o, np.uint8).reshape(16, 16, 4).astype(float)
        ref = noise.astype(float).reshape(16, 4, 16, 4, 4).mean((1, 3))
        check("resize 4x box average", small.astype(np.uint8), np.round(ref).astype(np.uint8), 1)
        run("resize", 64, 64, f, o, 64, 64); check("resize identity size", np.fromfile(o, np.uint8).reshape(64, 64, 4), noise, 0)

        # 7. selection mask invert
        m = np.zeros((10, 12, 4), np.uint8); m[2:5, 3:7] = 255; m.tofile(f)
        rc = run("mask-invert", 12, 10, f, o)
        got = np.fromfile(o, np.uint8).reshape(10, 12, 4)
        exp = np.where(m[..., 3:4] > 8, 0, 255).astype(np.uint8) * np.ones((1, 1, 4), np.uint8)
        check("mask invert", got, exp, 0)
        print(("PASS " if rc == 10 else "FAIL ") + "mask invert reports non-empty"); 
        if rc != 10: FAIL.append("mask invert rc")
        m[:] = 255; m.tofile(f); rc = run("mask-invert", 12, 10, f, o)
        print(("PASS " if rc == 11 else "FAIL ") + "mask invert of full selection -> empty")
        if rc != 11: FAIL.append("mask invert empty")

        # 8. effect brush region (per-pixel keys) vs transcription
        snap_st = rand_straight(30, 40, "mixed"); snap = premul(snap_st); snap.tofile(f)
        stu = unpremul(snap).astype(np.float64) / 255.0
        x0, y0, bw, bh = 6, 4, 20, 15
        keys = {0: ("temperature", 0.2), 1: ("exposure", 1.0), 2: ("brightness", -0.2), 3: ("contrast", 1.6),
                4: ("saturation", 0.3), 5: ("hue", 50.0), 6: ("invert", 1.0), 7: ("posterize", 5.0)}
        for k, (nm, pv) in keys.items():
            run("fx", 40, 30, f, o, x0, y0, bw, bh, k, pv)
            got = np.fromfile(o, np.uint8).reshape(bh, bw, 4)
            reg = stu[y0:y0 + bh, x0:x0 + bw, :3].copy()
            r, g, b = reg[..., 0], reg[..., 1], reg[..., 2]
            if nm == "temperature": r = r + pv; b = b - pv
            elif nm == "exposure": r, g, b = r * 2 ** pv, g * 2 ** pv, b * 2 ** pv
            elif nm == "brightness": r, g, b = r + pv, g + pv, b + pv
            elif nm == "contrast": r, g, b = [(c - 0.5) * pv + 0.5 for c in (r, g, b)]
            elif nm == "saturation":
                l = r * .299 + g * .587 + b * .114; r, g, b = [l + (c - l) * pv for c in (r, g, b)]
            elif nm == "hue":
                a = np.radians(pv); kk = np.full(3, 0.57735026919); c = np.stack([r, g, b], -1)
                c = c * np.cos(a) + np.cross(kk, c) * np.sin(a) + kk * (c @ kk)[..., None] * (1 - np.cos(a)); r, g, b = c[..., 0], c[..., 1], c[..., 2]
            elif nm == "invert": r, g, b = [c + (1 - c - c) * 1.0 for c in (r, g, b)]
            elif nm == "posterize": lv = max(1, pv - 1); r, g, b = [np.floor(c * lv + 0.5) / lv for c in (r, g, b)]
            rgb = np.floor(np.clip(np.stack([r, g, b], -1), 0, 1) * 255 + 0.5).astype(np.uint8)
            a = (stu[y0:y0 + bh, x0:x0 + bw].copy())
            alpha = unpremul(snap)[y0:y0 + bh, x0:x0 + bw, 3:4]
            exp = premul(np.concatenate([rgb, alpha], -1))
            check(f"effect brush:{nm}", got, exp, 2, 0.002)
        # blur region keeps alpha and is bounded by region
        run("fx", 40, 30, f, o, x0, y0, bw, bh, 11, 30.0)
        got = np.fromfile(o, np.uint8).reshape(bh, bw, 4)
        alpha_exp = unpremul(snap)[y0:y0 + bh, x0:x0 + bw, 3]
        check("effect brush:blur keeps alpha", unpremul(got)[..., 3], alpha_exp, 1)
    print("\nSUMMARY:", "ALL PASS" if not FAIL else f"{len(FAIL)} FAILED: {FAIL}")
    return 1 if FAIL else 0

if __name__ == "__main__":
    sys.exit(main())
